import { useState } from "react";
import { Link } from "react-router-dom";
import { BsChevronRight, BsChevronDown } from "react-icons/bs";
import {
  Printer,
  Wrench,
  Activity,
  Users,
  UserSearch,
  TrendingUp,
  UserCog,
  Briefcase,
  ReceiptText,
} from "lucide-react"; // or from "react-feather"
import {
  BuildingFill,
  CardText,
  Book,
  PersonBadgeFill,
  PersonCheckFill
} from "react-bootstrap-icons";
import "./SideBar.css";

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [adminCollapsed, setAdminCollapsed] = useState(false);
  const [mastersCollapsed, setMastersCollapsed] = useState(false);
  const [accountCollapsed, setAccountCollapsed] = useState(false);
  const [TransactionsCollapsed, setTransactionsCollapsed] = useState(false);
  const [purchaseCollapsed, setPurchaseCollapsed] = useState(false);
  const [salesCollapsed, setSalesCollapsed] = useState(false);
  const [unplannedCollapsed, setUnplannedCollapsed] = useState(false);
  const [reportCollapsed, setReportCollapsed] = useState(false);
  const [MastersCollapsed, setmastersCollapsed] = useState(false);
  const [PMSTransactions, setPMSTransactions] = useState(false);
  const [payslipCollapsed, setpayslipCollapsed] = useState(false);
  const [CRM, setCRM] = useState(false);

  const [selectedLink, setSelectedLink] = useState(false);
  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  const toggleESSCollapse = () => {
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const togglePMSTransactions = () => {
    setPMSTransactions(!PMSTransactions);
    setmastersCollapsed(true);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setReportCollapsed(false);
  };

  const toggleMastertsCollapse = () => {
    setmastersCollapsed(!MastersCollapsed);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const toggleAdminCollapse = () => {
    setAdminCollapsed(!adminCollapsed);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const toggleMastersCollapse = () => {
    setMastersCollapsed(!mastersCollapsed);
    setAdminCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const toggleAccountCollapse = () => {
    setAccountCollapsed(!accountCollapsed);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const toggleTransactionsCollapse = () => {
    setTransactionsCollapsed(!TransactionsCollapsed);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setPurchaseCollapsed(true);
    setSalesCollapsed(true);
    setUnplannedCollapsed(true);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const togglePurchaseCollapse = () => {
    setPurchaseCollapsed(!purchaseCollapsed);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const toggleSalesCollapse = () => {
    setSalesCollapsed(!salesCollapsed);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setUnplannedCollapsed(false);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const toggleUnplannedCollapse = () => {
    setUnplannedCollapsed(!unplannedCollapsed);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setReportCollapsed(false);
    setPMSTransactions(false);
  };

  const toggleReportCollapse = () => {
    setReportCollapsed(!reportCollapsed);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setPMSTransactions(false);
  };

  const togglePayslipCollapse = () => {
    setpayslipCollapsed(!payslipCollapsed);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setPMSTransactions(false);
  };

  const toggleCRM = () => {
    setpayslipCollapsed(false);
    setAdminCollapsed(false);
    setMastersCollapsed(false);
    setAccountCollapsed(false);
    setTransactionsCollapsed(false);
    setPurchaseCollapsed(false);
    setSalesCollapsed(false);
    setUnplannedCollapsed(false);
    setPMSTransactions(false);
  };

  const handleLinkClick = (linkName) => {
    setSelectedLink(linkName);
    sessionStorage.setItem("selectedPage", linkName);
  };

  // Fetch permissions from session storage
  const permissionsJSON = sessionStorage.getItem("permissions");
  const permissions = permissionsJSON ? JSON.parse(permissionsJSON) : [];
  const screenType = Array.isArray(permissions)
    ? permissions.map((permission) =>
      permission.screen_type.replace(/\s+/g, "")
    )
    : [];

  const hasAnyPermission = (screens = []) =>
    screens.some((screen) => screenType.includes(screen));

  const Admin = [
    "Company",
    "CompanyMapping",
    "Location",
    "Role",
    "UserRoleMapping",
    "UserRights",
    "User",
    "ValidationGrid",
  ];

  const Master = [
    "Attribute",
    "TemplateDesign",
    "BankAccount",
    "BarcodeGenerator",
    "BarcodeScanner",
    "Customer",
    "ClientInfo",
    "Department",
    "DesgiantionInfo",
    "Item",
    "Intermediary",
    "NumberSeries",
    "Product",
    "Tax",
    "SiteMaster",
    "SiteWarehouse",
    "Vendor",
    "Warehouse",
    "FinancialYearAccess",
  ];

  const Accounts = [
    "BaseAccount",
    "AccountName",
    "StandardAccount",
    "UserAccountGroup",
  ];

  const Transaction = [
    // Direct
    "Adjustment",
    "AssertAllocation",
    "AssetsReturn",
    "DeliveryChallan",
    "Journal",
    "OpeningItem",
    "Expenses",
    "PendingCustomer",
    "Quotation",
    "ReceivedGoods",
    "Stocktransfer",
    "TaxInvoice",
    "Payment",
    "CustomerReceipt",

    // Inventory
    "UnplannedIssued",
    "UnplannedReceipt",
    "UnplannedReturn",

    // Purchase
    "Purchase",
    "PurchaseOrder",
    "PurchaseReturn",

    // Sales
    "Sales",
    "SalesReturn",
  ];

  const Report = [
    "DCanalysis",
    "POanalysis",
    "QOanalysis",
    "TIanalysis",
    "GSTReport",
    "ReceivedGoodsRt",
    "OIAnalysis",
    "DataWiseStock",
    "SitewiseIncome",
    "IEanalysis",
    "SSmaterial",
    "MaterialUsage",
    "ExpensesTracking"
  ];

  return (
    <div className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="sidebar-menu mt-2" id="">
        <div className="sidebar-toggle" onClick={toggleSidebar}>
          {collapsed ? <BsChevronDown /> : <BsChevronRight />}
        </div>

        <div className=" mt-5">
          {screenType.includes("Dashboard") && (
            <Link to="/Dashboard" class="nav-link" title="Dashboard">
              <div class="menu-item">
                <i class="bi bi-speedometer2 me-2 fs-5"></i>
                <span className={collapsed ? "hidden" : ""}> Dashboard</span>
              </div>
            </Link>
          )}
        </div>

        {hasAnyPermission(Admin) && (
          <>
            <div
              className="menu-item"
              onClick={toggleAdminCollapse}
              title="Admin"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                fill="currentColor"
                class="bi bi-person-vcard me-2 Admin-font"
                viewBox="0 0 16 16"
              >
                <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5" />
                <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z" />
              </svg>
              <span className={collapsed ? "hidden" : ""}>Admin</span>
              <div class="admin-arrow">
                {adminCollapsed ? <BsChevronDown /> : <BsChevronRight />}
              </div>
            </div>
            <div className={`collapse ${adminCollapsed ? "show" : "hide"}`}>
              <div className=" ms-3">
                {screenType.includes("Company") && (
                  <Link to="/Company" className="nav-link" title="Company">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-buildings me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M14.763.075A.5.5 0 0 1 15 .5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V14h-1v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V10a.5.5 0 0 1 .342-.474L6 7.64V4.5a.5.5 0 0 1 .276-.447l8-4a.5.5 0 0 1 .487.022M6 8.694 1 10.36V15h5zM7 15h2v-1.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5V15h2V1.309l-7 3.5z" />
                        <path d="M2 11h1v1H2zm2 0h1v1H4zm-2 2h1v1H2zm2 0h1v1H4zm4-4h1v1H8zm2 0h1v1h-1zm-2 2h1v1H8zm2 0h1v1h-1zm2-2h1v1h-1zm0 2h1v1h-1zM8 7h1v1H8zm2 0h1v1h-1zm2 0h1v1h-1zM8 5h1v1H8zm2 0h1v1h-1zm2 0h1v1h-1zm0-2h1v1h-1z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="">
                        Company
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("CompanyMapping") && (
                  <Link
                    to="/CompanyMapping"
                    className="nav-link"
                    title="Company Mapping"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-clipboard-pulse me-3"
                        viewBox="0 0 16 16"
                      >
                        <path
                          fillRule="evenodd"
                          d="M10 1.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5zm-5 0A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5v1A1.5 1.5 0 0 1 9.5 4h-3A1.5 1.5 0 0 1 5 2.5zm-2 0h1v1H3a1 1 0 0 0-1 1V14a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V3.5a1 1 0 0 0-1-1h-1v-1h1a2 2 0 0 1 2 2V14a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V3.5a2 2 0 0 1 2-2m6.979 3.856a.5.5 0 0 0-.968.04L7.92 10.49l-.94-3.135a.5.5 0 0 0-.895-.133L4.232 10H3.5a.5.5 0 0 0 0 1h1a.5.5 0 0 0 .416-.223l1.41-2.115 1.195 3.982a.5.5 0 0 0 .968-.04L9.58 7.51l.94 3.135A.5.5 0 0 0 11 11h1.5a.5.5 0 0 0 0-1h-1.128z"
                        />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="">
                        Company Mapping
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className="ms-3">
                {screenType.includes("Location") && (
                  <Link to="/Location" className="nav-link" title="Location">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-geo-alt me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A32 32 0 0 1 8 14.58a32 32 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10" />
                        <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Location
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("Role") && (
                  <Link to="/Role" className="nav-link" title="Role">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-person-circle me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                        <path
                          fill-rule="evenodd"
                          d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"
                        />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="">
                        Role
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("UserRoleMapping") && (
                  <Link
                    to="/UserRoleMapping"
                    className="nav-link"
                    title="Role Mapping"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-person-fill-check me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                        <path d="M2 13c0 1 1 1 1 1h5.256A4.5 4.5 0 0 1 8 12.5a4.5 4.5 0 0 1 1.544-3.393Q8.844 9.002 8 9c-5 0-6 3-6 4" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        Role Mapping
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("UserRights") && (
                  <Link
                    to="/UserRights"
                    className="nav-link"
                    title="Role Rights"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-person-fill-gear me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0m-9 8c0 1 1 1 1 1h5.256A4.5 4.5 0 0 1 8 12.5a4.5 4.5 0 0 1 1.544-3.393Q8.844 9.002 8 9c-5 0-6 3-6 4m9.886-3.54c.18-.613 1.048-.613 1.229 0l.043.148a.64.64 0 0 0 .921.382l.136-.074c.561-.306 1.175.308.87.869l-.075.136a.64.64 0 0 0 .382.92l.149.045c.612.18.612 1.048 0 1.229l-.15.043a.64.64 0 0 0-.38.921l.074.136c.305.561-.309 1.175-.87.87l-.136-.075a.64.64 0 0 0-.92.382l-.045.149c-.18.612-1.048.612-1.229 0l-.043-.15a.64.64 0 0 0-.921-.38l-.136.074c-.561.305-1.175-.309-.87-.87l.075-.136a.64.64 0 0 0-.382-.92l-.148-.045c-.613-.18-.613-1.048 0-1.229l.148-.043a.64.64 0 0 0 .382-.921l-.074-.136c-.306-.561.308-1.175.869-.87l.136.075a.64.64 0 0 0 .92-.382zM14 12.5a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        Role Rights
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("User") && (
                  <Link to="/User" className="nav-link" title="User">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-people-fill me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="">
                        User
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("ValidationGrid") && (
                  <Link
                    to="/ValidationGrid"
                    className="nav-link"
                    title="Validation Grid"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-people-fill me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="">
                        Validation
                      </span>
                    </div>
                  </Link>
                )}
              </div>
            </div>
          </>
        )}

        {hasAnyPermission(Master) && (
          <>
            <div
              className="menu-item"
              onClick={toggleMastersCollapse}
              title="Masters"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                fill="currentColor"
                class="bi bi-lightning-fill me-2 masters-font"
                viewBox="0 0 16 16"
              >
                <path d="M5.52.359A.5.5 0 0 1 6 0h4a.5.5 0 0 1 .474.658L8.694 6H12.5a.5.5 0 0 1 .395.807l-7 9a.5.5 0 0 1-.873-.454L6.823 9.5H3.5a.5.5 0 0 1-.48-.641z" />
              </svg>
              <span className={collapsed ? "hidden" : ""}>Masters</span>
              <div class="master-arrow">
                {mastersCollapsed ? <BsChevronDown /> : <BsChevronRight />}
              </div>
            </div>
            <div className={`collapse ${mastersCollapsed ? "show" : ""}`}>
              <div className="ms-3">
                {screenType.includes("Attribute") && (
                  <Link to="/Attribute" className="nav-link" title="Attribute">
                    <div class="menu-item">
                      <CardText size={18} className="me-3 " />
                      <span className={collapsed ? "hidden" : ""} class="">
                        Attribute
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className="ms-3">
                {screenType.includes("TemplateDesign") && (
                  <Link
                    to="/TemplateDesign"
                    className="nav-link"
                    title="PrintTemplate"
                  >
                    <div className="menu-item">
                      <Printer size={18} className="me-3" />
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Print Templates
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("BankAccount") && (
                  <Link
                    to="/BankAccount"
                    className="nav-link"
                    title="Bank Account"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-person-rolodex me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M8 9.05a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                        <path d="M1 1a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h.5a.5.5 0 0 0 .5-.5.5.5 0 0 1 1 0 .5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5.5.5 0 0 1 1 0 .5.5 0 0 0 .5.5h.5a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H6.707L6 1.293A1 1 0 0 0 5.293 1zm0 1h4.293L6 2.707A1 1 0 0 0 6.707 3H15v10h-.085a1.5 1.5 0 0 0-2.4-.63C11.885 11.223 10.554 10 8 10c-2.555 0-3.886 1.224-4.514 2.37a1.5 1.5 0 0 0-2.4.63H1z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Bank Account
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("BarcodeGenerator") && (
                  <Link
                    to="/BarcodeGenerator"
                    title="Barcode Generator"
                    className="nav-link"
                    onClick={() => handleLinkClick("BarcodeGenerator")}
                  >
                    {" "}
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 256 256"
                        width="18"
                        height="18"
                        fill="currentColor"
                        className="me-3"
                        id="barcode"
                      >
                        <polyline
                          fill="none"
                          stroke="#FFFFFF"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                          points="184 48 224 48 224 88"
                        ></polyline>
                        <polyline
                          fill="none"
                          stroke="#FFFFFF"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                          points="72 208 32 208 32 168"
                        ></polyline>
                        <polyline
                          fill="none"
                          stroke="#FFFFFF"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                          points="224 168 224 208 184 208"
                        ></polyline>
                        <polyline
                          fill="none"
                          stroke="#FFFFFF"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                          points="32 88 32 48 72 48"
                        ></polyline>
                        <line
                          x1="80"
                          x2="80"
                          y1="88"
                          y2="168"
                          fill="none"
                          stroke="#FFFFFF"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                        ></line>
                        <line
                          x1="176"
                          x2="176"
                          y1="88"
                          y2="168"
                          fill="none"
                          stroke="#FFFFFF"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                        ></line>
                        <line
                          x1="144"
                          x2="144"
                          y1="88"
                          y2="168"
                          fill="none"
                          stroke="#FFFFFF"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                        ></line>
                        <line
                          x1="112"
                          x2="112"
                          y1="88"
                          y2="168"
                          fill="none"
                          stroke="#FFFFFF"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                        ></line>
                      </svg>

                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Barcode Generator
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("BarcodeScanner") && (
                  <Link
                    to="/BarcodeScanner"
                    className="nav-link"
                    title="Barcode Scanner"
                    onClick={() => handleLinkClick("BarcodeScanner")}
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 64 64"
                        width="18"
                        height="18"
                        fill="currentColor"
                        className="me-3"
                        id="barcode-scanner"
                      >
                        <path d="M60,3H58.051a4.842,4.842,0,0,0-3.908-2c-.121,0-.243,0-.344.013L24.63,2.729A5.019,5.019,0,0,0,20,7.715v11.57a5.023,5.023,0,0,0,4.646,4.987l2.921.172-1,2.556H21.934a8.028,8.028,0,0,0-5.715,2.367L14.586,31H2a1,1,0,0,0-1,1V53a1,1,0,0,0,1,1H13.586l1.284,1.284a9.2,9.2,0,0,0,5.342,2.628A2.961,2.961,0,0,0,20,59v1a3,3,0,0,0,3,3H40a3,3,0,0,0,3-3V59a2.977,2.977,0,0,0-.75-1.964,4.428,4.428,0,0,0,.761-6.316,4.471,4.471,0,0,0,1.722-7.337,4.437,4.437,0,0,0,1.278-6.663A4.482,4.482,0,0,0,47,28.762V25.587l6.79.4c.117.009.235.013.353.013a4.842,4.842,0,0,0,3.908-2H60a3,3,0,0,0,3-3V6A3,3,0,0,0,60,3ZM29.664,24.568l10.8.635L39.39,28H34.969A4.952,4.952,0,0,0,32,27H28.7ZM14.707,52.293A1,1,0,0,0,14,52H3V33H15a1,1,0,0,0,.707-.293l1.926-1.926A6.044,6.044,0,0,1,21.934,29H32a3,3,0,0,1,3,3v9a2,2,0,0,1-4,0V34a1,1,0,0,0-1-1H26a1,1,0,0,0-1,1,8.009,8.009,0,0,1-8,8H15v2h2a9.959,9.959,0,0,0,7-2.879V56H21.427a7.229,7.229,0,0,1-5.143-2.13ZM42,53.5A2.5,2.5,0,0,1,39.5,56h-7a2.5,2.5,0,0,1,0-5h7A2.5,2.5,0,0,1,42,53.5Zm-14,0a4.474,4.474,0,0,0,.762,2.5H26V39.033c0-.239,0-.479.012-.719A9.9,9.9,0,0,0,26.95,35H29v6a3.988,3.988,0,0,0,1.649,3.221,4.368,4.368,0,0,0,.34,5.059A4.492,4.492,0,0,0,28,53.5ZM40,58a1,1,0,0,1,1,1v1a1,1,0,0,1-1,1H23a1,1,0,0,1-1-1V59a1,1,0,0,1,1-1Zm1.5-9h-7a2.49,2.49,0,0,1-1.954-4.046A4.012,4.012,0,0,0,33,45a3.962,3.962,0,0,0,2.618-1H41.5a2.5,2.5,0,0,1,0,5Zm1-7H36.858A3.939,3.939,0,0,0,37,41V37h5.5a2.5,2.5,0,0,1,0,5Zm2-7H37V32a4.95,4.95,0,0,0-.424-2H44.5a2.5,2.5,0,0,1,0,5Zm.5-6.949A4.342,4.342,0,0,0,44.5,28H41.533l1.029-2.674L45,25.47Zm12-6.908a2.865,2.865,0,0,1-3.065,2.849h-.019L24.778,22.277A3.012,3.012,0,0,1,22,19.285V7.715a3.009,3.009,0,0,1,2.763-2.991L53.935,3.008C54,3,54.073,3,54.143,3A2.861,2.861,0,0,1,57,5.857ZM61,21a1,1,0,0,1-1,1H58.913A4.844,4.844,0,0,0,59,21.143V5.857A4.844,4.844,0,0,0,58.913,5H60a1,1,0,0,1,1,1Z"></path>
                        <path d="M51,7H28a1,1,0,0,0-1,1v4a1,1,0,0,0,1,1H51a1,1,0,0,0,1-1V8A1,1,0,0,0,51,7Zm-1,4H29V9H50Z"></path>
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Barcode Scanner
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("Customer") && (
                  <Link to="/Customer" className="nav-link" title="Customer">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-person-standing me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M8 3a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3M6 6.75v8.5a.75.75 0 0 0 1.5 0V10.5a.5.5 0 0 1 1 0v4.75a.75.75 0 0 0 1.5 0v-8.5a.25.25 0 1 1 .5 0v2.5a.75.75 0 0 0 1.5 0V6.5a3 3 0 0 0-3-3H7a3 3 0 0 0-3 3v2.75a.75.75 0 0 0 1.5 0v-2.5a.25.25 0 0 1 .5 0" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Customer
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              {/* <div className="ms-3">
                {screenType.includes("ClientInfo") && (
                  <Link
                    to="/ClientInfo"
                    className="nav-link"
                    title="ClientInfo"
                  >
                    <div className="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        className="bi bi-person-circle me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                        <path
                          fillRule="evenodd"
                          d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 5.52 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"
                        />
                      </svg>
                      <span className={collapsed ? "hidden" : "ms-1"}>
                        Client Info
                      </span>
                    </div>
                  </Link>
                )}
              </div> */}
              <div className=" ms-3">
                {screenType.includes("Department") && (
                  <Link
                    to="/Department"
                    className="nav-link"
                    title="Department"
                    onClick={() => handleLinkClick("Department")}
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-clipboard-pulse me-3"
                        viewBox="0 0 16 16"
                      >
                        <path
                          fillRule="evenodd"
                          d="M10 1.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5zm-5 0A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5v1A1.5 1.5 0 0 1 9.5 4h-3A1.5 1.5 0 0 1 5 2.5zm-2 0h1v1H3a1 1 0 0 0-1 1V14a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V3.5a1 1 0 0 0-1-1h-1v-1h1a2 2 0 0 1 2 2V14a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V3.5a2 2 0 0 1 2-2m6.979 3.856a.5.5 0 0 0-.968.04L7.92 10.49l-.94-3.135a.5.5 0 0 0-.895-.133L4.232 10H3.5a.5.5 0 0 0 0 1h1a.5.5 0 0 0 .416-.223l1.41-2.115 1.195 3.982a.5.5 0 0 0 .968-.04L9.58 7.51l.94 3.135A.5.5 0 0 0 11 11h1.5a.5.5 0 0 0 0-1h-1.128z"
                        />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Department
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("DesgiantionInfo") && (
                  <Link
                    to="/DesgiantionInfo"
                    className="nav-link"
                    title=" Designation Info"
                    onClick={() => handleLinkClick("DesgiantionInfo")}
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        className="me-3"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zM12 14c3.87 0 7 1.28 7 3v1H5v-1c0-1.72 3.13-3 7-3z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Designation Info
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              {/*} <div className=" ms-3">
            {screenType.includes("EmployeeInfo") && (
              <Link to="/EmployeeInfo" className="nav-link" title="Employee Info">
                <div class="menu-item">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    fill="currentColor"
                    className="me-3"
                    viewBox="0 0 24 24"
                  >
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zM12 14c3.87 0 7 1.28 7 3v1H5v-1c0-1.72 3.13-3 7-3z" />
                  </svg>
                  <span className={collapsed ? "hidden" : ""}>
                    {" "}
                    Employee Info
                  </span>
                </div>
              </Link>
            )}
          </div> */}
              <div className=" ms-3">
                {screenType.includes("Item") && (
                  <Link to="/Item" className="nav-link" title="Item">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-box-seam me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5l2.404.961L10.404 2zm3.564 1.426L5.596 5 8 5.961 14.154 3.5zm3.25 1.7-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}> Item</span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("Intermediary") && (
                  <Link
                    to="/Intermediary"
                    className="nav-link"
                    title="Intermediary"
                  >
                    <div class="menu-item">
                      <Book size={18} className="me-3" />
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Intermediary
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("NumberSeries") && (
                  <Link
                    to="/NumberSeries"
                    className="nav-link"
                    title="Number Series"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-123 me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M2.873 11.297V4.142H1.699L0 5.379v1.137l1.64-1.18h.06v5.961zm3.213-5.09v-.063c0-.618.44-1.169 1.196-1.169.676 0 1.174.44 1.174 1.106 0 .624-.42 1.101-.807 1.526L4.99 10.553v.744h4.78v-.99H6.643v-.069L8.41 8.252c.65-.724 1.237-1.332 1.237-2.27C9.646 4.849 8.723 4 7.308 4c-1.573 0-2.36 1.064-2.36 2.15v.057zm6.559 1.883h.786c.823 0 1.374.481 1.379 1.179.01.707-.55 1.216-1.421 1.21-.77-.005-1.326-.419-1.379-.953h-1.095c.042 1.053.938 1.918 2.464 1.918 1.478 0 2.642-.839 2.62-2.144-.02-1.143-.922-1.651-1.551-1.714v-.063c.535-.09 1.347-.66 1.326-1.678-.026-1.053-.933-1.855-2.359-1.845-1.5.005-2.317.88-2.348 1.898h1.116c.032-.498.498-.944 1.206-.944.703 0 1.206.435 1.206 1.07.005.64-.504 1.106-1.2 1.106h-.75z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Number Series
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("Product") && (
                  <Link to="/Product" className="nav-link" title="Product">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        viewBox="0 0 576 512"
                      >
                        <path d="M64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64zM272 192l224 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-224 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zM256 304c0-8.8 7.2-16 16-16l224 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-224 0c-8.8 0-16-7.2-16-16zM164 152l0 13.9c7.5 1.2 14.6 2.9 21.1 4.7c10.7 2.8 17 13.8 14.2 24.5s-13.8 17-24.5 14.2c-11-2.9-21.6-5-31.2-5.2c-7.9-.1-16 1.8-21.5 5c-4.8 2.8-6.2 5.6-6.2 9.3c0 1.8 .1 3.5 5.3 6.7c6.3 3.8 15.5 6.7 28.3 10.5l.7 .2c11.2 3.4 25.6 7.7 37.1 15c12.9 8.1 24.3 21.3 24.6 41.6c.3 20.9-10.5 36.1-24.8 45c-7.2 4.5-15.2 7.3-23.2 9l0 13.8c0 11-9 20-20 20s-20-9-20-20l0-14.6c-10.3-2.2-20-5.5-28.2-8.4c0 0 0 0 0 0s0 0 0 0c-2.1-.7-4.1-1.4-6.1-2.1c-10.5-3.5-16.1-14.8-12.6-25.3s14.8-16.1 25.3-12.6c2.5 .8 4.9 1.7 7.2 2.4c13.6 4.6 24 8.1 35.1 8.5c8.6 .3 16.5-1.6 21.4-4.7c4.1-2.5 6-5.5 5.9-10.5c0-2.9-.8-5-5.9-8.2c-6.3-4-15.4-6.9-28-10.7l-1.7-.5c-10.9-3.3-24.6-7.4-35.6-14c-12.7-7.7-24.6-20.5-24.7-40.7c-.1-21.1 11.8-35.7 25.8-43.9c6.9-4.1 14.5-6.8 22.2-8.5l0-14c0-11 9-20 20-20s20 9 20 20z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Product{" "}
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("SiteMaster") && (
                  <Link to="/SiteMaster" className="nav-link" title="Site Master">
                    <div class="menu-item">
                      {/* Site / Building Icon */}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        viewBox="0 0 576 512"
                      >
                        <path d="M256 0c17.7 0 32 14.3 32 32V64H448c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128C0 92.7 28.7 64 64 64H224V32c0-17.7 14.3-32 32-32zM96 160v64h64V160H96zm128 0v64h64V160H224zm128 0v64h64V160H352zM96 288v64h64V288H96zm128 0v64h64V288H224zm128 0v64h64V288H352z" />
                      </svg>

                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Site Master
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("SiteWarehouse") && (
                  <Link
                    to="/SiteWarehouse"
                    className="nav-link"
                    title="Site Warehouse Mapping"
                  >
                    <div class="menu-item">
                      {/* Warehouse Icon */}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        viewBox="0 0 640 512"
                      >
                        <path d="M504 352H136V240h368v112zm0 32v64H136V384h368zM320 0L0 160v32H640V160L320 0zm248 480H72c-13.3 0-24 10.7-24 24s10.7 24 24 24H568c13.3 0 24-10.7 24-24s-10.7-24-24-24z" />
                      </svg>

                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Site Warehouse Mapping
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("Tax") && (
                  <Link to="/Tax" className="nav-link" title="Tax">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-receipt me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M1.92.506a.5.5 0 0 1 .434.14L3 1.293l.646-.647a.5.5 0 0 1 .708 0L5 1.293l.646-.647a.5.5 0 0 1 .708 0L7 1.293l.646-.647a.5.5 0 0 1 .708 0L9 1.293l.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .801.13l.5 1A.5.5 0 0 1 15 2v12a.5.5 0 0 1-.053.224l-.5 1a.5.5 0 0 1-.8.13L13 14.707l-.646.647a.5.5 0 0 1-.708 0L11 14.707l-.646.647a.5.5 0 0 1-.708 0L9 14.707l-.646.647a.5.5 0 0 1-.708 0L7 14.707l-.646.647a.5.5 0 0 1-.708 0L5 14.707l-.646.647a.5.5 0 0 1-.708 0L3 14.707l-.646.647a.5.5 0 0 1-.801-.13l-.5-1A.5.5 0 0 1 1 14V2a.5.5 0 0 1 .053-.224l.5-1a.5.5 0 0 1 .367-.27m.217 1.338L2 2.118v11.764l.137.274.51-.51a.5.5 0 0 1 .707 0l.646.647.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.509.509.137-.274V2.118l-.137-.274-.51.51a.5.5 0 0 1-.707 0L12 1.707l-.646.647a.5.5 0 0 1-.708 0L10 1.707l-.646.647a.5.5 0 0 1-.708 0L8 1.707l-.646.647a.5.5 0 0 1-.708 0L6 1.707l-.646.647a.5.5 0 0 1-.708 0L4 1.707l-.646.647a.5.5 0 0 1-.708 0z" />
                        <path d="M3 4.5a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5m8-6a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}> Tax</span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("Vendor") && (
                  <Link to="/Vendor" className="nav-link" title="Vendor">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-person-fill me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}> Vendor</span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("Warehouse") && (
                  <Link to="/Warehouse" className="nav-link" title="Warehouse">
                    <div class="menu-item">
                      <BuildingFill size={18} className="me-3" />
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Warehouse
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("FinancialYearAccess") && (
                  <Link
                    to="/FinancialYearAccess"
                    className="nav-link"
                    title="Warehouse"
                  >
                    <div class="menu-item">
                      <BuildingFill size={18} className="me-3" />
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Financial Year Access
                      </span>
                    </div>
                  </Link>
                )}
              </div>
            </div>
          </>
        )}

        {hasAnyPermission(Accounts) && (
          <>
            <div
              className="menu-item"
              onClick={toggleAccountCollapse}
              title="Accounts"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                fill="currentColor"
                class="bi bi-layout-text-sidebar-reverse me-2 Accounts-font"
                viewBox="0 0 16 16"
              >
                <path d="M12.5 3a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1zm0 3a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1zm.5 3.5a.5.5 0 0 0-.5-.5h-5a.5.5 0 0 0 0 1h5a.5.5 0 0 0 .5-.5m-.5 2.5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1z" />
                <path d="M16 2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2zM4 1v14H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zm1 0h9a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5z" />
              </svg>
              <span className={collapsed ? "hidden" : ""}>Accounts</span>
              <div class="accounts-arrow">
                {accountCollapsed ? <BsChevronDown /> : <BsChevronRight />}
              </div>
            </div>
            <div className={`collapse ${accountCollapsed ? "show" : ""}`}>
              <div className="ms-3">
                {screenType.includes("BaseAccount") && (
                  <Link
                    to="/BaseAccount"
                    className="nav-link"
                    title="Base Account"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-file-text me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M6 4a.5.5 0 0 1 .5-.5h3A.5.5 0 0 1 10 4v1H6V4zM3 1h10a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM4 3v1h8V3H4zM5 6h6v1H5V6zM5 8h6v1H5V8zM5 10h6v1H5v-1z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Base Account{" "}
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("AccountName") && (
                  <Link
                    to="/AccountName"
                    className="nav-link"
                    title="Chart Of Accounts"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-person-rolodex me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M8 9.05a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                        <path d="M1 1a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h.5a.5.5 0 0 0 .5-.5.5.5 0 0 1 1 0 .5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5.5.5 0 0 1 1 0 .5.5 0 0 0 .5.5h.5a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H6.707L6 1.293A1 1 0 0 0 5.293 1zm0 1h4.293L6 2.707A1 1 0 0 0 6.707 3H15v10h-.085a1.5 1.5 0 0 0-2.4-.63C11.885 11.223 10.554 10 8 10c-2.555 0-3.886 1.224-4.514 2.37a1.5 1.5 0 0 0-2.4.63H1z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Chart Of Accounts{" "}
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("BaseAccount") && (
                  <Link
                    to="/StandardAccount"
                    className="nav-link"
                    title="Standard Account"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-file-text me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M6 4a.5.5 0 0 1 .5-.5h3A.5.5 0 0 1 10 4v1H6V4zM3 1h10a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM4 3v1h8V3H4zM5 6h6v1H5V6zM5 8h6v1H5V8zM5 10h6v1H5v-1z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Standard Account{" "}
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("UserAccountGroup") && (
                  <Link
                    to="/UserAccountGroup"
                    className="nav-link"
                    title="User Account Group"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-person-rolodex me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M8 9.05a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                        <path d="M1 1a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h.5a.5.5 0 0 0 .5-.5.5.5 0 0 1 1 0 .5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5.5.5 0 0 1 1 0 .5.5 0 0 0 .5.5h.5a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H6.707L6 1.293A1 1 0 0 0 5.293 1zm0 1h4.293L6 2.707A1 1 0 0 0 6.707 3H15v10h-.085a1.5 1.5 0 0 0-2.4-.63C11.885 11.223 10.554 10 8 10c-2.555 0-3.886 1.224-4.514 2.37a1.5 1.5 0 0 0-2.4.63H1z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        User Account Group
                      </span>
                    </div>
                  </Link>
                )}
              </div>
            </div>
          </>
        )}

        {hasAnyPermission(Transaction) && (
          <>
            <div
              className="menu-item"
              onClick={toggleTransactionsCollapse}
              title="Transactions"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                fill="currentColor"
                class="bi bi-cash-stack me-2 Trans-font"
                viewBox="0 0 16 16"
              >
                <path d="M1 3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1zm7 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4" />
                <path d="M0 5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1zm3 0a2 2 0 0 1-2 2v4a2 2 0 0 1 2 2h10a2 2 0 0 1 2-2V7a2 2 0 0 1-2-2z" />
              </svg>
              <span className={collapsed ? "hidden" : ""}>Transactions</span>
              <div class="transaction-arrow">
                {TransactionsCollapsed ? <BsChevronDown /> : <BsChevronRight />}
              </div>
            </div>
            <div className={`collapse ${TransactionsCollapsed ? "show" : ""}`}>
              <div className=" ms-3">
                {screenType.includes("Adjustment") && (
                  <Link
                    to="/Adjustment"
                    className="nav-link"
                    title="Adjustment"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-wrench-adjustable-circle me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M12.496 8a4.5 4.5 0 0 1-1.703 3.526L9.497 8.5l2.959-1.11q.04.3.04.61" />
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-1 0a7 7 0 1 0-13.202 3.249l1.988-1.657a4.5 4.5 0 0 1 7.537-4.623L7.497 6.5l1 2.5 1.333 3.11c-.56.251-1.18.39-1.833.39a4.5 4.5 0 0 1-1.592-.29L4.747 14.2A7 7 0 0 0 15 8m-8.295.139a.25.25 0 0 0-.288-.376l-1.5.5.159.474.808-.27-.595.894a.25.25 0 0 0 .287.376l.808-.27-.595.894a.25.25 0 0 0 .287.376l1.5-.5-.159-.474-.808.27.596-.894a.25.25 0 0 0-.288-.376l-.808.27z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Adjustment
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("DeliveryChallan") && (
                  <Link
                    to="/DeliveryChallan"
                    className="nav-link"
                    title="Delivery Challan"
                  >
                    <div class="menu-item">
                      <svg
                        viewBox="0 0 128 128"
                        width="18"
                        height="18"
                        fill="currentColor"
                        xmlns="http://www.w3.org/2000/svg"
                        class="me-3"
                      >
                        <path d="m105.544 37.128-14.773-14.774v-10.754a1.75 1.75 0 0 0 -1.75-1.75h-65.328a1.75 1.75 0 0 0 -1.75 1.75v93a1.75 1.75 0 0 0 1.75 1.75h9.863v10.05a1.75 1.75 0 0 0 1.75 1.75h69a1.75 1.75 0 0 0 1.75-1.75v-78.035a1.75 1.75 0 0 0 -.512-1.237zm-14.773-9.828 9.311 9.311h-9.311zm-65.328 75.55v-89.5h61.828v7.977h-51.964a1.75 1.75 0 0 0 -1.75 1.75v79.773zm11.613 11.8v-89.821h50.215v13.536a1.75 1.75 0 0 0 1.75 1.75h13.535v74.532z" />
                        <path d="m54.216 77.414h31.184a1.75 1.75 0 0 0 1.75-1.75v-31.183a1.75 1.75 0 0 0 -1.75-1.75h-31.184a1.75 1.75 0 0 0 -1.75 1.75v31.183a1.75 1.75 0 0 0 1.75 1.75zm17.839-31.183v5l-1.155-.92a1.749 1.749 0 0 0 -2.187 0l-1.153.923v-5zm-16.089 0h8.094v8.644a1.75 1.75 0 0 0 2.84 1.366l2.9-2.323 2.905 2.323a1.75 1.75 0 0 0 2.843-1.366v-8.644h8.094v27.683h-27.676z" />
                        <path d="m91.932 84.25h-44.25a1.75 1.75 0 0 0 0 3.5h44.25a1.75 1.75 0 0 0 0-3.5z" />
                        <path d="m91.932 93.586h-44.25a1.75 1.75 0 0 0 0 3.5h44.25a1.75 1.75 0 0 0 0-3.5z" />
                        <path d="m91.932 102.923h-44.25a1.75 1.75 0 0 0 0 3.5h44.25a1.75 1.75 0 0 0 0-3.5z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        {" "}
                        Delivery Challan
                      </span>
                    </div>
                  </Link>
                )}
              </div>

              <div className=" ms-3">
                {screenType.includes("OpeningBalance") && (
                  <Link
                    to="/OpeningBalance"
                    className="nav-link"
                    title="Opening Balance"
                  >
                    <div class="menu-item">
                      {/* Wallet / Balance Icon */}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        viewBox="0 0 576 512"
                      >
                        <path d="M64 64C28.7 64 0 92.7 0 128V384c0 35.3 28.7 64 64 64H512c35.3 0 64-28.7 64-64V160c0-35.3-28.7-64-64-64H480V80c0-26.5-21.5-48-48-48H64zm368 64H96V96H432v32zm80 96v64c0 17.7-14.3 32-32 32H416c-17.7 0-32-14.3-32-32V224c0-17.7 14.3-32 32-32h64c17.7 0 32 14.3 32 32zm-64 16a16 16 0 1 0 0 32 16 16 0 1 0 0-32z" />
                      </svg>

                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Opening Balance
                      </span>
                    </div>
                  </Link>
                )}
              </div>

              <div className=" ms-3">
                {screenType.includes("OpeningItem") && (
                  <Link
                    to="/OpeningItem"
                    className="nav-link"
                    title="Opening Item"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        className="icon me-3"
                      >
                        <path d="M3 6h5l2 3h11v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                        <path d="M3 6V4a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v1" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Opening Item
                      </span>
                    </div>
                  </Link>
                )}
              </div>

              <div className=" ms-3">
                {screenType.includes("Expenses") && (
                  <Link
                    to="/Expenses"
                    className="nav-link"
                    title="Expenses"
                  >
                    <div className="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="icon me-3"
                      >
                        <path d="M3 7a2 2 0 0 1 2-2h14a1 1 0 0 1 1 1v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z" />
                        <path d="M16 12h4" />
                        <path d="M16 12a1 1 0 1 0 0 .01" />
                      </svg>
                      <span className={`${collapsed ? "hidden" : ""} ms-1`}>
                        Expenses
                      </span>
                    </div>
                  </Link>
                )}
              </div>

              {hasAnyPermission([
                "UnplannedIssued",
                "UnplannedReceipt",
                "UnplannedReturn",
              ]) && (
                  <>
                    <div
                      className="menu-item"
                      onClick={toggleUnplannedCollapse}
                      title="Inventory"
                    >
                      <span className={collapsed ? "hidden" : ""}>Inventory</span>
                      <div class="inventory-arrow">
                        {unplannedCollapsed ? (
                          <BsChevronDown />
                        ) : (
                          <BsChevronRight />
                        )}
                      </div>
                    </div>
                    <div
                      className={`collapse ${unplannedCollapsed ? "show" : ""}`}
                    >
                      <div className=" ms-3">
                        {screenType.includes("UnplannedIssued") && (
                          <Link
                            to="/UnplannedIssued"
                            className="nav-link"
                            title="Inventory Issue"
                          >
                            <div class="menu-item">
                              <svg
                                class="svg-icon me-3"
                                viewBox="0 0 1024 1024"
                                version="1.1"
                                width="18"
                                height="18"
                                fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path d="M322 297h380v60H322zM605.726 685.223l-42.427 42.426 91.924 91.924L697.65 862 832 727.649l-42.426-42.426-61.924 61.924V522.649h-60v224.498zM322 407h380v60H322zM322 517h240v60H322z" />
                                <path d="M192 162v700h300v-60H252V222h520v305h60V162z" />
                              </svg>
                              <span
                                className={collapsed ? "hidden" : ""}
                                class="ms-1"
                              >
                                {" "}
                                Inventory Issue{" "}
                              </span>
                            </div>
                          </Link>
                        )}
                      </div>
                      <div className=" ms-3">
                        {screenType.includes("UnplannedReceipt") && (
                          <Link
                            to="/UnplannedReceipt"
                            className="nav-link"
                            title="Inventory Receipt"
                          >
                            <div class="menu-item">
                              <svg
                                class="svg-icon me-3"
                                viewBox="0 0 1024 1024"
                                version="1.1"
                                width="18"
                                height="18"
                                fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path d="M446.603636 873.053091a34.909091 34.909091 0 0 1 0 69.818182H189.556364c-85.387636 0-154.647273-69.003636-154.647273-154.181818V165.818182C34.909091 80.64 104.168727 11.636364 189.556364 11.636364H714.007273c85.387636 0 154.647273 69.003636 154.647272 154.181818v251.415273a34.909091 34.909091 0 1 1-69.818181 0V165.818182c0-46.545455-37.934545-84.363636-84.829091-84.363637H189.556364C142.661818 81.454545 104.727273 119.249455 104.727273 165.818182v622.871273c0 46.545455 37.934545 84.363636 84.829091 84.363636H446.603636z m-187.554909-598.155636a34.909091 34.909091 0 0 1 0-69.818182h383.162182a34.909091 34.909091 0 0 1 0 69.818182H259.025455z m0 190.836363a34.909091 34.909091 0 0 1 0-69.818182h383.162182a34.909091 34.909091 0 0 1 0 69.818182H259.025455z m0 190.766546a34.909091 34.909091 0 0 1 0-69.818182h143.685818a34.909091 34.909091 0 0 1 0 69.818182h-143.685818z m489.821091 351.115636c-141.730909 0-256.651636-114.501818-256.651636-255.790545s114.920727-255.790545 256.651636-255.790546c141.730909 0 256.651636 114.501818 256.651637 255.767273 0 141.312-114.920727 255.813818-256.651637 255.813818z m0-60.509091c108.357818 0 196.142545-87.458909 196.142546-195.281454s-87.784727-195.281455-196.142546-195.281455c-108.357818 0-196.142545 87.458909-196.142545 195.258182 0 107.845818 87.784727 195.304727 196.142545 195.304727z m-46.08-155.694545l133.608727-133.026909a30.254545 30.254545 0 0 1 42.705455 42.891636l-154.530909 153.832727a30.254545 30.254545 0 0 1-42.24 0.418909l-85.364364-81.524363a30.254545 30.254545 0 0 1 41.797818-43.752728l64 61.137455z" />
                              </svg>
                              <span
                                className={collapsed ? "hidden" : ""}
                                class="ms-1"
                              >
                                {" "}
                                Inventory Receipt
                              </span>
                            </div>
                          </Link>
                        )}
                      </div>
                      <div className=" ms-3">
                        {screenType.includes("UnplannedReturn") && (
                          <Link
                            to="/UnplannedReturn"
                            className="nav-link"
                            title="Inventory Return"
                          >
                            <div class="menu-item">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 24 24"
                                class="me-3"
                                width="18"
                                height="18"
                                fill="currentColor"
                              >
                                <rect
                                  x="4"
                                  y="7"
                                  width="16"
                                  height="10"
                                  stroke="white"
                                  strokeWidth="2"
                                  fill="none"
                                />
                                <path
                                  d="M10 10 L6 14 L10 18"
                                  stroke="white"
                                  strokeWidth="2"
                                  fill="none"
                                />
                                <line
                                  x1="6"
                                  y1="14"
                                  x2="18"
                                  y2="14"
                                  stroke="white"
                                  strokeWidth="2"
                                />
                              </svg>
                              <span
                                className={collapsed ? "hidden" : ""}
                                class="ms-1"
                              >
                                {" "}
                                Inventory Return{" "}
                              </span>
                            </div>
                          </Link>
                        )}
                      </div>
                    </div>
                  </>
                )}

              <div className=" ms-3">
                {screenType.includes("Journal") && (
                  <Link to="/Journal" className="nav-link" title="Journal">
                    {" "}
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-journal-bookmark-fill me-3"
                        viewBox="0 0 16 16"
                      >
                        <path
                          fillRule="evenodd"
                          d="M6 1h6v7a.5.5 0 0 1-.757.429L9 7.083 6.757 8.43A.5.5 0 0 1 6 8z"
                        />
                        <path d="M3 0h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-1h1v1a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v1H1V2a2 2 0 0 1 2-2" />
                        <path d="M1 5v-.5a.5.5 0 0 1 1 0V5h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1zm0 3v-.5a.5.5 0 0 1 1 0V8h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1zm0 3v-.5a.5.5 0 0 1 1 0v.5h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        {" "}
                        Journal
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              {/* <div className=" ms-3">
            {screenType.includes("OpeningBalance") && (
              <Link to="/OpeningBalance" className="nav-link">
                <div class="menu-item">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    fill="currentColor"
                    class="bi bi-credit-card me-3"
                    viewBox="0 0 16 16"
                  >
                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v1h14V4a1 1 0 0 0-1-1zm13 4H1v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1z" />
                    <path d="M2 10a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1z" />
                  </svg>
                  <span className={collapsed ? "hidden" : ""} class="ms-1">
                    Opening Balance
                  </span>
                </div>
              </Link>
            )}
          </div>*/}


              {hasAnyPermission([
                "Purchase",
                "PurchaseOrder",
                "PurchaseReturn",
              ]) && (
                  <>
                    <div
                      className="menu-item"
                      onClick={togglePurchaseCollapse}
                      title="Purchase"
                    >
                      <span className={collapsed ? "hidden" : ""}>Purchase</span>
                      <div class="purchase-arrow">
                        {purchaseCollapsed ? (
                          <BsChevronDown />
                        ) : (
                          <BsChevronRight />
                        )}
                      </div>
                    </div>
                    <div
                      className={`collapse ${purchaseCollapsed ? "show" : ""}`}
                    >
                      <div className=" ms-3">
                        {screenType.includes("Purchase") && (
                          <Link
                            to="/Purchase"
                            className="nav-link"
                            title="Purchase Entry"
                            onClick={() => handleLinkClick("Purchase")}
                          >
                            <div class="menu-item">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="18"
                                height="18"
                                fill="currentColor"
                                class="bi bi-cart-fill me-3"
                                viewBox="0 0 16 16"
                              >
                                <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                              </svg>
                              <span
                                className={collapsed ? "hidden" : ""}
                                class="ms-1"
                              >
                                {" "}
                                Purchase Entry{" "}
                              </span>
                            </div>
                          </Link>
                        )}
                      </div>
                      <div className=" ms-3">
                        {screenType.includes("PurchaseOrder") && (
                          <Link
                            to="/PurchaseOrder"
                            className="nav-link"
                            title="Purchase Order"
                          >
                            <div class="menu-item">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="18"
                                height="18"
                                fill="currentColor"
                                class="me-3"
                                viewBox="0 0 512 330.845"
                              >
                                <path d="M95.992 0c35.923 22.768 68.373 33.54 96.223 30.995 4.865 98.382-31.466 156.48-95.852 180.727C34.188 189.028-2.587 133.427.142 29.502 32.834 31.213 64.91 24.144 95.992 0zM76.731 103.923a73.156 73.156 0 016.88 6.658c6.723-10.822 13.89-20.757 21.461-29.895 21.401-25.849 11.702-20.867 41.389-20.867l-4.124 4.581c-12.676 14.086-16.952 21.417-27.343 36.429a425.653 425.653 0 00-27.95 46.499l-2.571 4.96-2.363-5.052c-4.359-9.359-9.581-17.95-15.808-25.625-6.228-7.676-11.667-12.684-20.112-18.479 3.87-12.702 22.288-6.201 30.541.791zm301.485 1.74l-35.138-.243V57.97a25.356 25.356 0 00-7.529-18.079 25.353 25.353 0 00-18.079-7.53H213.806c-.435 4.496-1.122 9.147-1.833 13.884H317.47c3.218 0 6.159 1.334 8.278 3.449 2.116 2.12 3.45 5.061 3.45 8.276v217.288H290.06a6.93 6.93 0 00-6.94 6.944 6.925 6.925 0 006.94 6.938h46.077a6.926 6.926 0 006.941-6.938v-7.885h28.044c3.177-72.232 106.9-82.195 117.451 0h22.782c5.868-70.433-28.909-97.805-81.803-103.996-3.805-16.53-11.062-31.874-19.26-47.037-9.747-18.025-12.016-17.297-32.076-17.621zM147.08 275.222a6.929 6.929 0 016.944 6.939 6.93 6.93 0 01-6.944 6.941H73.343c-7.022 0-13.413-3.06-18.082-7.882-4.623-4.821-7.527-11.411-7.527-18.392v-48.35a138.893 138.893 0 0013.881 7.815v40.535c0 3.334 1.375 6.51 3.609 8.824 2.119 2.197 4.98 3.606 8.077 3.606h73.779v-.036zm70.59-38.416c-25.963 0-47.019 21.059-47.019 47.019 0 25.961 21.056 47.02 47.019 47.02 25.961 0 47.017-21.059 47.017-47.02-.038-25.96-21.056-47.019-47.017-47.019zm0 28.942c-9.96 0-18.08 8.08-18.08 18.077 0 9.961 8.08 18.082 18.08 18.082 9.959 0 18.079-8.081 18.079-18.082-.042-9.997-8.12-18.077-18.079-18.077zm212.039-35.86c-25.959 0-47.016 21.059-47.016 47.018 0 25.96 21.057 47.021 47.016 47.021 25.963 0 47.02-21.061 47.02-47.021 0-25.959-21.057-47.018-47.02-47.018zm-18.077 47.018c0 9.961 8.076 18.079 18.077 18.079 10.001 0 18.079-8.077 18.079-18.079 0-9.999-8.078-18.076-18.079-18.076-9.978 0-18.077 8.095-18.077 18.076zm-30.038-151.174l-21.182-.392v45.06h44.866c-5.534-16.073-13.724-30.807-23.684-44.668zM96.049 14.47c30.429 19.287 59.636 30.128 83.227 27.971 4.118 83.335-28.373 134.27-82.908 154.808-52.671-19.224-85.542-68.035-83.23-156.073C43.7 42.778 71.71 33.379 96.049 14.47z" />
                              </svg>
                              <span
                                className={collapsed ? "hidden" : ""}
                                class="ms-1"
                              >
                                {" "}
                                Purchase Order
                              </span>
                            </div>
                          </Link>
                        )}
                      </div>
                      <div className=" ms-3">
                        {screenType.includes("PurchaseReturn") && (
                          <Link
                            to="/PurchaseReturn"
                            className="nav-link"
                            title="Purchase Return"
                          >
                            <div class="menu-item">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="18"
                                height="18"
                                fill="currentColor"
                                class="bi bi-cash-coin me-3"
                                viewBox="0 0 16 16"
                              >
                                <path
                                  fill-rule="evenodd"
                                  d="M11 15a4 4 0 1 0 0-8 4 4 0 0 0 0 8m5-4a5 5 0 1 1-10 0 5 5 0 0 1 10 0"
                                />
                                <path d="M9.438 11.944c.047.596.518 1.06 1.363 1.116v.44h.375v-.443c.875-.061 1.386-.529 1.386-1.207 0-.618-.39-.936-1.09-1.1l-.296-.07v-1.2c.376.043.614.248.671.532h.658c-.047-.575-.54-1.024-1.329-1.073V8.5h-.375v.45c-.747.073-1.255.522-1.255 1.158 0 .562.378.92 1.007 1.066l.248.061v1.272c-.384-.058-.639-.27-.696-.563h-.668zm1.36-1.354c-.369-.085-.569-.26-.569-.522 0-.294.216-.514.572-.578v1.1zm.432.746c.449.104.655.272.655.569 0 .339-.257.571-.709.614v-1.195z" />
                                <path d="M1 0a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h4.083q.088-.517.258-1H3a2 2 0 0 0-2-2V3a2 2 0 0 0 2-2h10a2 2 0 0 0 2 2v3.528c.38.34.717.728 1 1.154V1a1 1 0 0 0-1-1z" />
                                <path d="M9.998 5.083 10 5a2 2 0 1 0-3.132 1.65 6 6 0 0 1 3.13-1.567" />
                              </svg>
                              <span
                                className={collapsed ? "hidden" : ""}
                                class="ms-1"
                              >
                                {" "}
                                Purchase Return
                              </span>
                            </div>
                          </Link>
                        )}
                      </div>
                    </div>
                  </>
                )}

              {/* <div className=" ms-3">
                {screenType.includes("PendingCustomer") && (
                  <Link
                    to="/PendingCustomer"
                    className="nav-link"
                    title="Pending Customer"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        className=" me-3"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <circle cx="12" cy="8" r="4"></circle>
                        <path d="M16 20H8a4 4 0 0 1 4-4h0a4 4 0 0 1 4 4z"></path>

                        <circle cx="18" cy="6" r="4"></circle>
                        <path d="M18 4v2l1 1"></path>
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Pending Customer
                      </span>
                    </div>
                  </Link>
                )}
              </div> */}
              <div className=" ms-3">
                {screenType.includes("ReceivedGoods") && (
                  <Link
                    to="/ReceivedGoods"
                    className="nav-link"
                    title="Received Goods"
                  >
                    <div class="menu-item">
                      <svg
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        viewBox="0 0 1024 1024"
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M247.0912 996.1472 100.5568 996.1472c-39.936 0-72.4992-32.5632-72.4992-72.4992L28.0576 81.92c0-39.936 32.5632-72.4992 72.4992-72.4992l766.0544 0c39.936 0 72.4992 32.5632 72.4992 72.4992l0 210.5344c0 12.3904-10.0352 22.528-22.528 22.528s-22.528-10.0352-22.528-22.528L894.0544 81.92c0-15.1552-12.288-27.5456-27.5456-27.5456L100.5568 54.3744c-15.1552 0-27.5456 12.288-27.5456 27.5456L73.0112 923.648c0 15.1552 12.288 27.5456 27.5456 27.5456l146.5344 0c12.3904 0 22.528 10.0352 22.528 22.528S259.4816 996.1472 247.0912 996.1472z" />
                        <path d="M745.2672 192.1024 174.6944 192.1024c-12.3904 0-22.528-10.0352-22.528-22.528s10.0352-22.528 22.528-22.528l570.5728 0c12.3904 0 22.528 10.0352 22.528 22.528S757.6576 192.1024 745.2672 192.1024z" />
                        <path d="M437.6576 429.6704 174.6944 429.6704c-12.3904 0-22.528-10.0352-22.528-22.528s10.0352-22.528 22.528-22.528l262.9632 0c12.3904 0 22.528 10.0352 22.528 22.528S450.1504 429.6704 437.6576 429.6704z" />
                        <path d="M620.6464 310.8864 174.6944 310.8864c-12.3904 0-22.528-10.0352-22.528-22.528s10.0352-22.528 22.528-22.528l445.952 0c12.3904 0 22.528 10.0352 22.528 22.528S633.1392 310.8864 620.6464 310.8864z" />
                        <path d="M399.6672 1009.8688c-6.2464 0-12.288-2.56-16.5888-7.2704-5.2224-5.7344-7.168-13.7216-5.12-21.2992l40.8576-146.6368c1.024-3.6864 3.072-7.168 5.7344-9.8304l408.9856-408.9856c14.1312-14.0288 36.9664-14.0288 51.0976 0l97.792 97.792c6.8608 6.8608 10.5472 15.872 10.5472 25.4976s-3.7888 18.7392-10.5472 25.4976L928.8704 618.496c-4.1984 4.1984-9.9328 6.5536-15.872 6.5536s-11.6736-2.3552-15.872-6.5536l-66.048-66.048c-8.8064-8.8064-8.8064-23.04 0-31.8464s23.04-8.8064 31.8464 0l50.176 50.176 31.4368-31.4368L859.136 454.0416 460.6976 852.48 431.104 958.6688 546.7136 936.96l231.7312-231.7312c5.0176-5.4272 50.7904-52.6336 107.2128-56.7296 12.3904-0.9216 23.1424 8.3968 24.064 20.7872 0.9216 12.3904-8.3968 23.1424-20.7872 24.064-40.3456 2.9696-77.4144 42.2912-77.824 42.7008-0.2048 0.2048-0.4096 0.512-0.7168 0.7168L573.5424 973.7216c-3.1744 3.1744-7.2704 5.3248-11.776 6.2464l-158.0032 29.5936C402.432 1009.7664 401.1008 1009.8688 399.6672 1009.8688z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        Received Goods
                      </span>
                    </div>
                  </Link>
                )}
              </div>

              <div className=" ms-3">
                {screenType.includes("VendorPayment") && (
                  <Link
                    to="/VendorPayment"
                    className="nav-link"
                    title="Vendor Payment"
                  >
                    <div className="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="icon me-3"
                      >
                        <rect x="2" y="5" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="2" y1="10" x2="22" y2="10"></line>
                        <path d="M16 15h2"></path>
                        <path d="M12 15h2"></path>
                      </svg>
                      <span className={`${collapsed ? "hidden" : ""} ms-1`}>
                        Vendor Payment
                      </span>
                    </div>
                  </Link>
                )}
              </div>

              {hasAnyPermission(["Sales", "SalesReturn"]) && (
                <>
                  <div
                    className="menu-item"
                    onClick={toggleSalesCollapse}
                    title="Sales"
                  >
                    <span className={collapsed ? "hidden" : ""}>Sales</span>
                    <div class="sales-arrow">
                      {salesCollapsed ? <BsChevronDown /> : <BsChevronRight />}
                    </div>
                  </div>
                  <div className={`collapse ${salesCollapsed ? "show" : ""}`}>
                    <div className=" ms-3">
                      {screenType.includes("Sales") && (
                        <Link
                          to="/Sales"
                          className="nav-link"
                          title="Sales Entry"
                          onClick={() => handleLinkClick("Sales")}
                        >
                          {" "}
                          <div class="menu-item">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="18"
                              height="18"
                              fill="currentColor"
                              class="bi bi-bar-chart-line-fill me-3"
                              viewBox="0 0 16 16"
                            >
                              <path d="M11 2a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v12h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1v-3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3h1V7a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v7h1z" />
                            </svg>
                            <span
                              className={collapsed ? "hidden" : ""}
                              class="ms-1"
                            >
                              {" "}
                              Sales Entry
                            </span>
                          </div>
                        </Link>
                      )}
                    </div>
                    <div className=" ms-3">
                      {screenType.includes("SalesReturn") && (
                        <Link
                          to="/SalesReturn"
                          className="nav-link"
                          title="Sales Return"
                        >
                          {" "}
                          <div class="menu-item">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="18"
                              height="18"
                              fill="currentColor"
                              class="bi bi-cash-coin me-3"
                              viewBox="0 0 16 16"
                            >
                              <path
                                fill-rule="evenodd"
                                d="M11 15a4 4 0 1 0 0-8 4 4 0 0 0 0 8m5-4a5 5 0 1 1-10 0 5 5 0 0 1 10 0"
                              />
                              <path d="M9.438 11.944c.047.596.518 1.06 1.363 1.116v.44h.375v-.443c.875-.061 1.386-.529 1.386-1.207 0-.618-.39-.936-1.09-1.1l-.296-.07v-1.2c.376.043.614.248.671.532h.658c-.047-.575-.54-1.024-1.329-1.073V8.5h-.375v.45c-.747.073-1.255.522-1.255 1.158 0 .562.378.92 1.007 1.066l.248.061v1.272c-.384-.058-.639-.27-.696-.563h-.668zm1.36-1.354c-.369-.085-.569-.26-.569-.522 0-.294.216-.514.572-.578v1.1zm.432.746c.449.104.655.272.655.569 0 .339-.257.571-.709.614v-1.195z" />
                              <path d="M1 0a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h4.083q.088-.517.258-1H3a2 2 0 0 0-2-2V3a2 2 0 0 0 2-2h10a2 2 0 0 0 2 2v3.528c.38.34.717.728 1 1.154V1a1 1 0 0 0-1-1z" />
                              <path d="M9.998 5.083 10 5a2 2 0 1 0-3.132 1.65 6 6 0 0 1 3.13-1.567" />
                            </svg>
                            <span
                              className={collapsed ? "hidden" : ""}
                              class="ms-1"
                            >
                              {" "}
                              Sales Return
                            </span>
                          </div>
                        </Link>
                      )}
                    </div>
                  </div>
                </>
              )}

              <div className=" ms-3">
                {screenType.includes("Stocktransfer") && (
                  <Link
                    to="/Stocktransfer"
                    className="nav-link"
                    title="Stock Transfer"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-truck me-3"
                        viewBox="0 0 16 16"
                      >
                        <path d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5zm1.294 7.456A2 2 0 0 1 4.732 11h5.536a2 2 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456M12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2m9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        {" "}
                        Stock Transfer
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("TaxInvoice") && (
                  <Link to="/TaxInvoice" className="nav-link" title="Invoice">
                    <div class="menu-item">
                      <svg
                        viewBox="0 0 1024 1024"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M855.04 1006.592H181.76c-14.336 0-25.6-11.264-25.6-25.6V173.056c0-14.336 11.264-25.6 25.6-25.6h178.176c12.288-76.288 78.848-134.656 158.72-134.656s145.92 58.368 158.208 134.656H855.04c14.336 0 25.6 11.264 25.6 25.6v807.936c0 14.336-11.264 25.6-25.6 25.6z m-647.68-51.2H829.44V198.656h-176.128c-14.336 0-25.6-11.264-25.6-25.6 0-59.904-49.152-109.056-109.056-109.056-60.416 0-109.568 49.152-109.568 109.056 0 14.336-11.264 25.6-25.6 25.6H207.36v756.736z" />
                        <path d="M518.656 139.264c18.432 0 33.792 15.36 33.792 33.792s-15.36 33.792-33.792 33.792-33.792-15.36-33.792-33.792 14.848-33.792 33.792-33.792zM471.04 617.472c-6.656 0-13.312-2.56-17.92-7.68L316.928 473.6c-10.24-10.24-10.24-26.112 0-36.352s26.112-10.24 36.352 0l117.76 118.272 212.992-213.504c10.24-10.24 26.112-10.24 36.352 0s10.24 26.112 0 36.352l-230.912 231.424c-5.12 5.12-11.776 7.68-18.432 7.68zM686.592 773.12H348.16c-14.336 0-25.6-11.264-25.6-25.6s11.264-25.6 25.6-25.6h338.432c14.336 0 25.6 11.264 25.6 25.6s-11.264 25.6-25.6 25.6z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        Invoice
                      </span>
                    </div>
                  </Link>
                )}
              </div>

              <div className=" ms-3">
                {screenType.includes("Quotation") && (
                  <Link to="/Quotation" className="nav-link" title="Quotation">
                    <div class="menu-item">
                      <svg
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        viewBox="0 0 1024 1024"
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M247.0912 996.1472 100.5568 996.1472c-39.936 0-72.4992-32.5632-72.4992-72.4992L28.0576 81.92c0-39.936 32.5632-72.4992 72.4992-72.4992l766.0544 0c39.936 0 72.4992 32.5632 72.4992 72.4992l0 210.5344c0 12.3904-10.0352 22.528-22.528 22.528s-22.528-10.0352-22.528-22.528L894.0544 81.92c0-15.1552-12.288-27.5456-27.5456-27.5456L100.5568 54.3744c-15.1552 0-27.5456 12.288-27.5456 27.5456L73.0112 923.648c0 15.1552 12.288 27.5456 27.5456 27.5456l146.5344 0c12.3904 0 22.528 10.0352 22.528 22.528S259.4816 996.1472 247.0912 996.1472z" />
                        <path d="M745.2672 192.1024 174.6944 192.1024c-12.3904 0-22.528-10.0352-22.528-22.528s10.0352-22.528 22.528-22.528l570.5728 0c12.3904 0 22.528 10.0352 22.528 22.528S757.6576 192.1024 745.2672 192.1024z" />
                        <path d="M437.6576 429.6704 174.6944 429.6704c-12.3904 0-22.528-10.0352-22.528-22.528s10.0352-22.528 22.528-22.528l262.9632 0c12.3904 0 22.528 10.0352 22.528 22.528S450.1504 429.6704 437.6576 429.6704z" />
                        <path d="M620.6464 310.8864 174.6944 310.8864c-12.3904 0-22.528-10.0352-22.528-22.528s10.0352-22.528 22.528-22.528l445.952 0c12.3904 0 22.528 10.0352 22.528 22.528S633.1392 310.8864 620.6464 310.8864z" />
                        <path d="M399.6672 1009.8688c-6.2464 0-12.288-2.56-16.5888-7.2704-5.2224-5.7344-7.168-13.7216-5.12-21.2992l40.8576-146.6368c1.024-3.6864 3.072-7.168 5.7344-9.8304l408.9856-408.9856c14.1312-14.0288 36.9664-14.0288 51.0976 0l97.792 97.792c6.8608 6.8608 10.5472 15.872 10.5472 25.4976s-3.7888 18.7392-10.5472 25.4976L928.8704 618.496c-4.1984 4.1984-9.9328 6.5536-15.872 6.5536s-11.6736-2.3552-15.872-6.5536l-66.048-66.048c-8.8064-8.8064-8.8064-23.04 0-31.8464s23.04-8.8064 31.8464 0l50.176 50.176 31.4368-31.4368L859.136 454.0416 460.6976 852.48 431.104 958.6688 546.7136 936.96l231.7312-231.7312c5.0176-5.4272 50.7904-52.6336 107.2128-56.7296 12.3904-0.9216 23.1424 8.3968 24.064 20.7872 0.9216 12.3904-8.3968 23.1424-20.7872 24.064-40.3456 2.9696-77.4144 42.2912-77.824 42.7008-0.2048 0.2048-0.4096 0.512-0.7168 0.7168L573.5424 973.7216c-3.1744 3.1744-7.2704 5.3248-11.776 6.2464l-158.0032 29.5936C402.432 1009.7664 401.1008 1009.8688 399.6672 1009.8688z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-1">
                        {" "}
                        Quotation{" "}
                      </span>
                    </div>
                  </Link>
                )}
              </div>

              {/* <div className=" ms-3">
                {screenType.includes("Payment") && (
                  <Link to="/Payment" className="nav-link" title="Payment">
                    <div class="menu-item">
                      <svg
                        viewBox="0 0 1024 1024"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M855.04 1006.592H181.76c-14.336 0-25.6-11.264-25.6-25.6V173.056c0-14.336 11.264-25.6 25.6-25.6h178.176c12.288-76.288 78.848-134.656 158.72-134.656s145.92 58.368 158.208 134.656H855.04c14.336 0 25.6 11.264 25.6 25.6v807.936c0 14.336-11.264 25.6-25.6 25.6z m-647.68-51.2H829.44V198.656h-176.128c-14.336 0-25.6-11.264-25.6-25.6 0-59.904-49.152-109.056-109.056-109.056-60.416 0-109.568 49.152-109.568 109.056 0 14.336-11.264 25.6-25.6 25.6H207.36v756.736z" />
                        <path d="M518.656 139.264c18.432 0 33.792 15.36 33.792 33.792s-15.36 33.792-33.792 33.792-33.792-15.36-33.792-33.792 14.848-33.792 33.792-33.792zM471.04 617.472c-6.656 0-13.312-2.56-17.92-7.68L316.928 473.6c-10.24-10.24-10.24-26.112 0-36.352s26.112-10.24 36.352 0l117.76 118.272 212.992-213.504c10.24-10.24 26.112-10.24 36.352 0s10.24 26.112 0 36.352l-230.912 231.424c-5.12 5.12-11.776 7.68-18.432 7.68zM686.592 773.12H348.16c-14.336 0-25.6-11.264-25.6-25.6s11.264-25.6 25.6-25.6h338.432c14.336 0 25.6 11.264 25.6 25.6s-11.264 25.6-25.6 25.6z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        Payment
                      </span>
                    </div>
                  </Link>
                )}
              </div> */}

              <div className=" ms-3">
                {screenType.includes("CustomerReceipt") && (
                  <Link to="/CustomerReceipt" className="nav-link" title="CustomerReceipt">
                    <div className="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="icon me-3"
                      >
                        <path d="M6 2l2 2 2-2 2 2 2-2 2 2 2-2v18l-2-2-2 2-2-2-2 2-2-2-2 2V2z" />
                        <path d="M8 7h8" />
                        <path d="M8 11h8" />
                        <path d="M8 15h5" />
                      </svg>
                      <span className={`${collapsed ? "hidden" : ""} ms-2`}>
                        Customer Receipt
                      </span>
                    </div>
                  </Link>
                )}
              </div>

            </div>
          </>
        )}

        {hasAnyPermission(Report) && (
          <>
            <div
              className="menu-item"
              onClick={toggleReportCollapse}
              title="Report"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                fill="currentColor"
                class="bi bi-clipboard-data me-2 Report-font"
                viewBox="0 0 16 16"
              >
                <path d="M4 11a1 1 0 1 1 2 0v1a1 1 0 1 1-2 0zm6-4a1 1 0 1 1 2 0v5a1 1 0 1 1-2 0zM7 9a1 1 0 0 1 2 0v3a1 1 0 1 1-2 0z" />
                <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1z" />
                <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0z" />
              </svg>
              <span className={collapsed ? "hidden" : ""}>Report</span>
              <div class="report-arrow">
                {reportCollapsed ? <BsChevronDown /> : <BsChevronRight />}
              </div>
            </div>
            <div className={`collapse ${reportCollapsed ? "show" : ""}`}>
              <div className="ms-3">
                {screenType.includes("DCanalysis") && (
                  <Link
                    to="/DCanalysis"
                    className="nav-link"
                    title="Delivery Challan Analysis"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor "
                        className="me-3"
                        viewBox="0 0 640 512"
                      >
                        <path d="M624 368h-16V243.2c0-12.7-7.5-24.2-19-29.2L488 150.3V96c0-35.3-28.7-64-64-64H64C28.7 32 0 60.7 0 96v320c0 35.3 28.7 64 64 64h16c0 35.3 28.7 64 64 64s64-28.7 64-64h192c0 35.3 28.7 64 64 64s64-28.7 64-64h16c35.3 0 64-28.7 64-64v-32c0-8.8-7.2-16-16-16zM512 304h-64v-64h51.2L512 274.2V304zM128 464c-26.5 0-48-21.5-48-48s21.5-48 48-48 48 21.5 48 48-21.5 48-48 48zm320 0c-26.5 0-48-21.5-48-48s21.5-48 48-48 48 21.5 48 48-21.5 48-48 48zM416 96h48v64h-48V96zM64 192V96h288v96H64z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        Delivery Challan Analysis
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("POanalysis") && (
                  <Link
                    to="/POanalysis"
                    className="nav-link"
                    title="Purchase Order Analysis"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 512 512"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                      >
                        <path d="M64 64c0-17.7-14.3-32-32-32S0 46.3 0 64L0 400c0 44.2 35.8 80 80 80l400 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L80 416c-8.8 0-16-7.2-16-16L64 64zm406.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L320 210.7l-57.4-57.4c-12.5-12.5-32.8-12.5-45.3 0l-112 112c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L240 221.3l57.4 57.4c12.5 12.5 32.8 12.5 45.3 0l128-128z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        {" "}
                        Purchase Order Analysis{" "}
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className="ms-3">
                {screenType.includes("QOanalysis") && (
                  <Link
                    to="/QOanalysis"
                    className="nav-link"
                    title="Quotation Analysis"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                        viewBox="0 0 576 512"
                      >
                        <path d="M64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64zM272 192l224 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-224 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zM256 304c0-8.8 7.2-16 16-16l224 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-224 0c-8.8 0-16-7.2-16-16zM164 152l0 13.9c7.5 1.2 14.6 2.9 21.1 4.7c10.7 2.8 17 13.8 14.2 24.5s-13.8 17-24.5 14.2c-11-2.9-21.6-5-31.2-5.2c-7.9-.1-16 1.8-21.5 5c-4.8 2.8-6.2 5.6-6.2 9.3c0 1.8 .1 3.5 5.3 6.7c6.3 3.8 15.5 6.7 28.3 10.5l.7 .2c11.2 3.4 25.6 7.7 37.1 15c12.9 8.1 24.3 21.3 24.6 41.6c.3 20.9-10.5 36.1-24.8 45c-7.2 4.5-15.2 7.3-23.2 9l0 13.8c0 11-9 20-20 20s-20-9-20-20l0-14.6c-10.3-2.2-20-5.5-28.2-8.4c0 0 0 0 0 0s0 0 0 0c-2.1-.7-4.1-1.4-6.1-2.1c-10.5-3.5-16.1-14.8-12.6-25.3s14.8-16.1 25.3-12.6c2.5 .8 4.9 1.7 7.2 2.4c13.6 4.6 24 8.1 35.1 8.5c8.6 .3 16.5-1.6 21.4-4.7c4.1-2.5 6-5.5 5.9-10.5c0-2.9-.8-5-5.9-8.2c-6.3-4-15.4-6.9-28-10.7l-1.7-.5c-10.9-3.3-24.6-7.4-35.6-14c-12.7-7.7-24.6-20.5-24.7-40.7c-.1-21.1 11.8-35.7 25.8-43.9c6.9-4.1 14.5-6.8 22.2-8.5l0-14c0-11 9-20 20-20s20 9 20 20z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        Quotation Analysis
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className="ms-3">
                {screenType.includes("TIanalysis") && (
                  <Link
                    to="/TIanalysis"
                    className="nav-link"
                    title="Invoice Analysis"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 512 512"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="me-3"
                      >
                        <path d="M24 32c13.3 0 24 10.7 24 24l0 352c0 13.3 10.7 24 24 24l416 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L72 480c-39.8 0-72-32.2-72-72L0 56C0 42.7 10.7 32 24 32zM128 136c0-13.3 10.7-24 24-24l208 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-208 0c-13.3 0-24-10.7-24-24zm24 72l144 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-144 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm0 96l272 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-272 0c-13.3 0-24-10.7-24-24s10.7-24 24-24z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        Invoice Analysis
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className="ms-3">
                {screenType.includes("GSTReport") && (
                  <Link to="/GSTReport" className="nav-link" title="GST Report">
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 64 64"
                        width="18"
                        height="18"
                        fill="none"
                        stroke="black"
                        stroke-width="2"
                        class="me-3"
                      >
                        <rect
                          x="8"
                          y="8"
                          width="48"
                          height="56"
                          rx="4"
                          fill="white"
                        />
                        <path d="M40 8h16v16H40z" fill="white" stroke="black" />
                        <line x1="16" y1="28" x2="48" y2="28" />
                        <rect
                          x="20"
                          y="38"
                          width="6"
                          height="12"
                          fill="white"
                        />
                        <rect
                          x="30"
                          y="34"
                          width="6"
                          height="16"
                          fill="white"
                        />
                        <rect x="40" y="42" width="6" height="8" fill="white" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        GST Report
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className="ms-3">
                {screenType.includes("ReceivedGoodsRt") && (
                  <Link
                    to="/ReceivedGoodsRt"
                    className="nav-link"
                    title="GST Report"
                  >
                    <div class="menu-item">
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 64 64"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        class="me-3"
                      >
                        <rect
                          x="8"
                          y="8"
                          width="48"
                          height="48"
                          rx="4"
                          stroke="white"
                          stroke-width="2"
                        />
                        <path
                          d="M16 32H48M16 24H48M16 40H48M32 16V48"
                          stroke="white"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                        <circle
                          cx="48"
                          cy="48"
                          r="8"
                          stroke="black"
                          stroke-width="2"
                        />
                        <path
                          d="M44 48L47 51L52 45"
                          stroke="white"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        Received Goods Analysis
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className="ms-3">
                {screenType.includes("OIAnalysis") && (
                  <Link
                    to="/OIAnalysis"
                    className="nav-link"
                    title="Opening Item Analysis"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 64 64"
                        width="18"
                        height="18"
                        fill="none"
                        stroke="white"
                        stroke-width="2"
                        class="me-3"
                      >
                        <circle cx="32" cy="32" r="30" fill="none" />
                        <path
                          d="M16 24h12l4-4h16v28H16z"
                          fill="none"
                          stroke="white"
                        />
                        <path d="M32 32L32 14A18 18 0 0 1 50 32z" fill="none" />
                        <circle cx="32" cy="32" r="5" fill="none" />
                        <line x1="16" y1="38" x2="48" y2="38" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""} class="ms-2">
                        Opening Item Analysis
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("DataWiseStock") && (
                  <Link
                    to="/DataWiseStock"
                    className="nav-link"
                    title="Data Wise Item Stock"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        className="me-4"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zM12 14c3.87 0 7 1.28 7 3v1H5v-1c0-1.72 3.13-3 7-3z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Date Wise Item Stock
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("SitewiseIncome") && (
                  <Link
                    to="/SitewiseIncome"
                    className="nav-link"
                    title="SitewiseIncome"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        className="me-4"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zM12 14c3.87 0 7 1.28 7 3v1H5v-1c0-1.72 3.13-3 7-3z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        {" "}
                        Site-wise Income & Expense Analysis Report
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("IEanalysis") && (
                  <Link
                    to="/IEanalysis"
                    className="nav-link"
                    title="Income Expense Analysis Report"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="26"
                        height="26"
                        fill="currentColor"
                        className="me-3"
                        viewBox="0 0 24 24"
                      >
                        <path d="M3 3h2v18H3V3zm16 7h2v11h-2V10zM11 13h2v8h-2v-8zm-4-4h2v12H7V9zm8-6h2v18h-2V3z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        Income & Expense Analysis Report
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("SSmaterial") && (
                  <Link
                    to="/SSmaterial"
                    className="nav-link"
                    title="Supervisor & Site Material Report"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="26"
                        height="26"
                        fill="currentColor"
                        className="me-3"
                        viewBox="0 0 24 24"
                      >
                        <path d="M10 4a4 4 0 100 8 4 4 0 000-8zm0 10c-3.33 0-6 1.34-6 4v2h12v-2c0-2.66-2.67-4-6-4zm8-3h-2V9h-2V7h2V5h2v2h2v2h-2v2z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        Supervisor & Site Material Report
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("MaterialUsage") && (
                  <Link
                    to="/MaterialUsage"
                    className="nav-link"
                    title="Material Usage Details – Site Wise Report"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="26"
                        height="26"
                        fill="currentColor"
                        className="me-4"
                        viewBox="0 0 24 24"
                      >
                        <path d="M21 16V8l-9-5-9 5v8l9 5 9-5zm-9 3.84L5 16.11V9.89l7 3.89 7-3.89v6.22l-7 3.73zm0-8.13L5.74 8 12 4.53 18.26 8 12 11.71z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        Material Usage Details – Site Wise Report
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("ExpensesTracking") && (
                  <Link
                    to="/ExpensesTracking"
                    className="nav-link"
                    title="Expenses Tracking"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="26"
                        height="26"
                        fill="currentColor"
                        className="me-3"
                        viewBox="0 0 24 24"
                      >
                        <path d="M21 7H3V5a2 2 0 012-2h14a2 2 0 012 2v2zm0 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V9h18zm-4 3a2 2 0 100 4 2 2 0 000-4z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        Expenses Tracking
                      </span>
                    </div>
                  </Link>
                )}
              </div>
              <div className=" ms-3">
                {screenType.includes("ExpenseSummary") && (
                  <Link
                    to="/ExpenseSummary"
                    className="nav-link"
                    title="Expense Summary – Site Wise"
                  >
                    <div class="menu-item">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="26"
                        height="26"
                        fill="currentColor"
                        className="me-4"
                        viewBox="0 0 24 24"
                      >
                        <path d="M11 2v20c-5.05-.5-9-4.76-9-10s3.95-9.5 9-10zm2 0c5.05.5 9 4.76 9 10s-3.95 9.5-9 10V2zm2 10h5c-.22-2.76-2.24-5.01-5-5.74V12z" />
                      </svg>
                      <span className={collapsed ? "hidden" : ""}>
                        Expense Summary – Site Wise
                      </span>
                    </div>
                  </Link>
                )}
              </div>
            </div>
          </>
        )}

      </div>

      <div
        className="sidebar-footer position-fixed text-center bg-dark pt-2 fw-bold pb-1"
        style={{ paddingRight: "85px", paddingLeft: "70px" }}
      >
        <h3 className="">YJK Technologies</h3>
        <h3 className="">Version 1.0.0</h3>
      </div>
    </div>
  );
};

export default Sidebar;