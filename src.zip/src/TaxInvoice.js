import React, { useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import "ag-grid-enterprise";
import "./apps.css";
import "./input.css";
import * as XLSX from 'xlsx';
import "bootstrap/dist/css/bootstrap.min.css";
import 'ag-grid-autocomplete-editor/dist/main.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import "./mobile.css";
import Select from 'react-select'
import './mobile.css'
import labels from './Labels';
import { ToastContainer, toast } from 'react-toastify';
import TaxInvoicePopup from './TaxInvoicePopup';
import { showConfirmationToast } from './ToastConfirmation';
import TaxInvoiceCustomerPopup from './SalesVendorPopup';
import { useLocation } from 'react-router-dom';
import DeletedTaxInvoicePopup from './DeletedTaxInvoicePopup';
import { useNavigate } from 'react-router-dom';
import LZString from "lz-string";
import LoadingScreen from './Loading';
const config = require('./Apiconfig');


function TaxInvoice() {

    const [rowData, setRowData] = useState([]);
    const [rowDataTerms, setrowDataTerms] = useState([{ serialNumber: 1, Terms_conditions: '' }]);
    const [bill_date, setbill_date] = useState("");
    const [TotalBill, setTotalBill] = useState('');
    const [totalamt, setTotalAmt] = useState(0)
    const [TotalTax, setTotalTax] = useState(0)
    const [round_difference, setRoundDifference] = useState(0)
    const [new_running_no, setNew_running_no] = useState("");
    const [error, setError] = useState("");
    const [deleteError, setDeleteError] = useState("");
    const [clickedRowIndex, setClickedRowIndex] = useState(null)
    const [buttonsVisible, setButtonsVisible] = useState(true);
    const [showExcelButton, setShowExcelButton] = useState(false);
    const [showUpdateButton, setShowUpdateButton] = useState(false);
    const [delButtonVisible, setDelButtonVisible] = useState(false);
    const [printButtonVisible, setPrintButtonVisible] = useState(false);
    const [productDrop, setProductDrop] = useState([]);
    const [product, setProduct] = useState("");
    const [selectedProduct, setSelectedProduct] = useState("");
    const [dynamicOptions, setDynamicOptions] = useState([]);
    const [selectedDynamicOption, setSelectedDynamicOption] = useState(null);
    const [paydrop, setPaydrop] = useState([]);
    const [salesdrop, setSalesdrop] = useState([]);
    const [invoicedrop, setInvoicedrop] = useState([]);
    const [payType, setPayType] = useState("");
    const [salesType, setSalesType] = useState("");
    const [invoicetype, setInvoiceType] = useState("");
    const [selectedPay, setSelectedPay] = useState(null);
    const [selectedSales, setSelectedSales] = useState(null);
    const [selectedInvoice, setselectedInvoice] = useState(null);
    const [activeTable, setActiveTable] = useState('myTable');
    const [rowDataTax, setRowDataTax] = useState([]);
    const [advanceAmount, setAdvanceAmount] = useState(0);
    const [balanceAmount, setBalanceAmount] = useState(0);
    const [isDeleteVisible, setIsDeleteVisible] = useState(true);
    const [showDropdown, setShowDropdown] = useState(true);
    const [showAsterisk, setShowAsterisk] = useState(false);
    const [Type, setType] = useState("");
    const [isChecked, setIsChecked] = useState(false);
    const [loading, setLoading] = useState(false);
    const [additionalData, setAdditionalData] = useState({
        modified_by: '',
        created_by: '',
        modified_date: '',
        created_date: ''
    });
    const [screensDrop, setScreensDrop] = useState([]);
    const [Screens, setScreens] = useState('');
    const [selectedscreens, setSelectedscreens] = useState(null);
    const [pendingStatusDrop, setPendingStatusDrop] = useState([]);
    const [pendingStatus, setPendingStatus] = useState('');
    const [selectedPendingStatus, setSelectedPendingStatus] = useState(null);
    const [templateName, setTemplateName] = useState('');
    const [printOption, setPrintOption] = useState("");
    const [printCopies, setPrintCopies] = useState(1);
    const Location_Code = sessionStorage.getItem("selectedLocationCode");

    const location = useLocation();
    const savedPath = sessionStorage.getItem('currentPath');
    const navigate = useNavigate();

    //code added by Pavun purpose of set user permisssion
    const permissions = JSON.parse(sessionStorage.getItem('permissions')) || {};
    const purchasePermission = permissions
        .filter(permission => permission.screen_type === 'TaxInvoice')
        .map(permission => permission.permission_type.toLowerCase());

    useEffect(() => {
        const currentPath = location.pathname;
        console.log(`Current path: ${currentPath}`);
        if (savedPath !== '/TaxInvoice') {
            sessionStorage.getItem('TaxInvoiceScreenSelection');
        }
    }, [location]);

    useEffect(() => {
        const savedScreen = sessionStorage.getItem('TaxInvoiceScreenSelection');
        if (savedScreen) {
            setSelectedscreens({ value: savedScreen, label: savedScreen === 'Add' ? 'Add' : 'Delete' });
            setScreens(savedScreen);
        } else {
            setSelectedscreens({ value: 'Add', label: 'Add' });
            setScreens('Add');
        }
    }, []);

    useEffect(() => {
        fetch(`${config.apiBaseUrl}/getEvent`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                company_code: sessionStorage.getItem("selectedCompanyCode"),

            }),
        })

            .then((response) => response.json())
            .then((data) => setScreensDrop(data))
            .catch((error) => console.error("Error fetching purchase types:", error));
    }, []);

    useEffect(() => {
        fetch(`${config.apiBaseUrl}/getPendingStatus`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                company_code: sessionStorage.getItem("selectedCompanyCode"),

            }),
        })

            .then((response) => response.json())
            .then((data) => {
                setPendingStatusDrop(data);
                const defaultInvoice = data.find((item) => item.attributedetails_name === "Yes") || data[0];
                if (defaultInvoice) {
                    setSelectedPendingStatus({
                        value: defaultInvoice.attributedetails_name,
                        label: defaultInvoice.attributedetails_name,
                    });
                    setPendingStatus(defaultInvoice.attributedetails_name);
                }
            })
            .catch((error) => console.error("Error fetching invoice types:", error));

    }, []);



    const handleChangeScreens = (selected) => {
        setSelectedscreens(selected);
        const screenValue = selected?.value === 'Add' ? 'Add' : 'Delete';
        setScreens(screenValue);
        sessionStorage.setItem('TaxInvoiceScreenSelection', screenValue);
    };

    const filteredOptionScreens = screensDrop.map((option) => ({
        value: option.attributedetails_name,
        label: option.attributedetails_name,
    }));

    const filteredOptionStatus = pendingStatusDrop.map((option) => ({
        value: option.attributedetails_name,
        label: option.attributedetails_name,
    }));

    const handleChangeStatus = (selected) => {
        setSelectedPendingStatus(selected);
        setPendingStatus(selected ? selected.value : '');
    };

    const handleToggleTable = (table) => {
        setActiveTable(table);
    };

    const onCellValueChangedBillTo = (params) => {
        if (params.data.fieldName === "Customer Code") {
            if (!params.data.billTo) {
                setHeaderRowData((prevData) =>
                    prevData.map((row) => ({
                        ...row,
                        billTo: row.fieldName === "Customer Code" ? row.billTo : "", // Retain only Customer Code field's value
                    }))
                );
            } else {
                handleCustomerDetailsBillTo(params.data.billTo);
            }
        }
    };



    useEffect(() => {
        // Function to fetch data from the backend API
        const fetchData = async () => {
            try {
                const response = await
                    fetch(`${config.apiBaseUrl}/TermsTI`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                            company_code: sessionStorage.getItem("selectedCompanyCode"),

                        }),
                    })
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const result = await response.json();
                const updatedData = await Promise.all(
                    result.map(async (item) => ({
                        ...item,
                        Terms_conditions: item.attributedetails_name
                    }))
                );
                setrowDataTerms(updatedData);
            } catch (error) {
                // setError(error.message);  // Handle errors
            }


        };

        fetchData();  // Call the fetchData function
    }, []);

    const onCellValueChangedShipTo = (params) => {
        if (params.data.fieldName === "Customer Code") {
            if (!params.data.shipTo) {
                setHeaderRowData((prevData) =>
                    prevData.map((row) => ({
                        ...row,
                        shipTo: row.fieldName === "Customer Code" ? row.shipTo : "", // Retain only Customer Code field's value
                    }))
                );
            } else {
                handleCustomerDetailsShipTo(params.data.shipTo);
            }
        }
    };

    const columnHeader = [
        { headerName: 'Field', field: 'fieldName', maxWidth: 240, editable: false },
        {
            headerName: 'Bill To',
            field: 'billTo',
            onCellValueChanged: onCellValueChangedBillTo,
            editable: true,
            cellRenderer: (params) => {
                const cellWidth = params.column.getActualWidth();
                const isWideEnough = cellWidth > 150;
                const showSearchIcon = params.data.fieldName === "Customer Code" && isWideEnough;

                return (
                    <div className="position-relative d-flex align-items-center" style={{ minHeight: '100%' }}>
                        <div className="flex-grow-1">
                            {params.editing ? (
                                <input
                                    type="text"
                                    className="form-control"
                                    value={params.value || ''}
                                    onChange={(e) => params.setValue(e.target.value)}
                                    style={{ width: '100%' }}
                                />
                            ) : (
                                params.value
                            )}
                        </div>

                        {showSearchIcon && (
                            <span
                                className="icon searchIcon"
                                style={{
                                    position: 'absolute',
                                    right: '10px',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                }}
                                onClick={handleBillToCustomer}
                            >
                                <i className="fa fa-search"></i>
                            </span>
                        )}
                    </div>
                );
            },
        },
        {
            headerName: 'Ship To',
            field: 'shipTo',
            onCellValueChanged: onCellValueChangedShipTo,
            editable: true,
            cellRenderer: (params) => {
                const cellWidth = params.column.getActualWidth();
                const isWideEnough = cellWidth > 150;
                const showSearchIcon = params.data.fieldName === "Customer Code" && isWideEnough;

                return (
                    <div className="position-relative d-flex align-items-center" style={{ minHeight: '100%' }}>
                        <div className="flex-grow-1">
                            {params.editing ? (
                                <input
                                    type="text"
                                    className="form-control"
                                    value={params.value || ''}
                                    onChange={(e) => params.setValue(e.target.value)}
                                    style={{ width: '100%' }}
                                />
                            ) : (
                                params.value
                            )}
                        </div>

                        {showSearchIcon && (
                            <span
                                className="icon searchIcon"
                                style={{
                                    position: 'absolute',
                                    right: '10px',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                }}
                                onClick={handleShipToCustomer}
                            >
                                <i className="fa fa-search"></i>
                            </span>
                        )}
                    </div>
                );
            },
        }
    ];

    const DateEditor = forwardRef((props, ref) => {
        const [value, setValue] = useState(props.value || "");

        useImperativeHandle(ref, () => ({
            getValue: () => value,
        }));

        return (
            <input
                type="date"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                autoFocus
            />
        );
    });

    const columnNotes = [
        { headerName: 'Field', field: 'fieldName', editable: false },
        {
            headerName: "Notes",
            field: "notes",
            editable: true,
            cellEditorSelector: (params) => {
                if (params.data.fieldName === "PO Date") {
                    return { component: DateEditor };
                }
                return { component: "agTextCellEditor" };
            },
        },
    ];

    const columnPINotes = [
        { headerName: 'Field', field: 'fieldName', editable: false },
        {
            headerName: "Notes",
            field: "PInotes",
            editable: true,
        },
    ];

    const handleBillToCustomer = () => {
        setOpen1(true);
    };

    const handleShipToCustomer = () => {
        setOpen2(true);
    };

    const [headerRowData, setHeaderRowData] = useState([
        { fieldName: 'Customer Code', billTo: '', shipTo: '' },
        { fieldName: 'Customer Name', billTo: '', shipTo: '' },
        { fieldName: 'Address 1', billTo: '', shipTo: '' },
        { fieldName: 'Address 2', billTo: '', shipTo: '' },
        { fieldName: 'Address 3', billTo: '', shipTo: '' },
        { fieldName: 'Address 4', billTo: '', shipTo: '' },
        { fieldName: 'State', billTo: '', shipTo: '' },
        { fieldName: 'Country', billTo: '', shipTo: '' },
        { fieldName: 'Mobile No', billTo: '', shipTo: '' },
        { fieldName: 'GST No', billTo: '', shipTo: '' },
        { fieldName: 'Contact Person', billTo: '', shipTo: '' },
    ]);

    const [notesRowData, setNotesRowData] = useState([
        { fieldName: 'PO No', notes: '', },
        { fieldName: 'PO Date', notes: '', },
        { fieldName: 'Document Type', notes: '', },
        { fieldName: 'Supplier Ref', notes: '', },
        { fieldName: 'E-Way Bill No', notes: '', },
        { fieldName: 'Delivered Through', notes: '', },
    ]);

    const [PINotesRowData, setPINotesRowData] = useState([
        { fieldName: 'Delivery Note', PInotes: '', },
        { fieldName: 'Dispatched Through', PInotes: '', },
        { fieldName: 'Destination', PInotes: '', },
    ]);

    const handleCustomerBillTo = async (data) => {
        if (data && data.length > 0) {
            const [{ CustomerCode, CustomerName, Address1, Address2, Address3, Address4, State, Country, MobileNo, ContactPerson, GSTNo }] = data;

            setHeaderRowData((prevRowData) =>
                prevRowData.map((row) => {
                    switch (row.fieldName) {
                        case 'Customer Code': return { ...row, billTo: CustomerCode };
                        case 'Customer Name': return { ...row, billTo: CustomerName };
                        case 'Address 1': return { ...row, billTo: Address1 };
                        case 'Address 2': return { ...row, billTo: Address2 };
                        case 'Address 3': return { ...row, billTo: Address3 };
                        case 'Address 4': return { ...row, billTo: Address4 };
                        case 'State': return { ...row, billTo: State };
                        case 'Country': return { ...row, billTo: Country };
                        case 'Mobile No': return { ...row, billTo: MobileNo };
                        case 'GST No': return { ...row, billTo: GSTNo };
                        case 'Contact Person': return { ...row, billTo: ContactPerson };
                        default: return row;
                    }
                })
            );

        } else {
            console.error('Data is empty or undefined');
        }
    };

    const handleCustomerShipTo = async (data) => {
        if (data && data.length > 0) {
            const [{ CustomerCode, CustomerName, Address1, Address2, Address3, Address4, State, Country, MobileNo, ContactPerson, GSTNo }] = data;

            setHeaderRowData((prevRowData) =>
                prevRowData.map((row) => {
                    switch (row.fieldName) {
                        case 'Customer Code': return { ...row, shipTo: CustomerCode };
                        case 'Customer Name': return { ...row, shipTo: CustomerName };
                        case 'Address 1': return { ...row, shipTo: Address1 };
                        case 'Address 2': return { ...row, shipTo: Address2 };
                        case 'Address 3': return { ...row, shipTo: Address3 };
                        case 'Address 4': return { ...row, shipTo: Address4 };
                        case 'State': return { ...row, shipTo: State };
                        case 'Country': return { ...row, shipTo: Country };
                        case 'Mobile No': return { ...row, shipTo: MobileNo };
                        case 'GST No': return { ...row, shipTo: GSTNo };
                        case 'Contact Person': return { ...row, shipTo: ContactPerson };
                        default: return row;
                    }
                })
            );

        } else {
            console.error('Data is empty or undefined');
        }
    };

    const handleCustomerDetailsBillTo = async (customerCode) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getCustomerDetails`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    customer_code: customerCode,
                    company_code: sessionStorage.getItem("selectedCompanyCode"),
                }),
            });

            if (response.ok) {
                const searchData = await response.json();

                if (searchData.length === 0) {
                    toast.warning("Customer code is not available!");
                    return;
                }

                const [{ customer_code, customer_name, customer_addr_1, customer_addr_2, customer_addr_3, customer_addr_4, customer_state,
                    customer_country, customer_mobile_no, contact_person, customer_gst_no }] = searchData;

                setHeaderRowData((prevRowData) =>
                    prevRowData.map((row) => {
                        switch (row.fieldName) {
                            case 'Customer Code': return { ...row, billTo: customer_code };
                            case 'Customer Name': return { ...row, billTo: customer_name };
                            case 'Address 1': return { ...row, billTo: customer_addr_1 };
                            case 'Address 2': return { ...row, billTo: customer_addr_2 };
                            case 'Address 3': return { ...row, billTo: customer_addr_3 };
                            case 'Address 4': return { ...row, billTo: customer_addr_4 };
                            case 'State': return { ...row, billTo: customer_state };
                            case 'Country': return { ...row, billTo: customer_country };
                            case 'Mobile No': return { ...row, billTo: customer_mobile_no };
                            case 'GST No': return { ...row, billTo: customer_gst_no };
                            case 'Contact Person': return { ...row, billTo: contact_person };
                            default: return row;
                        }
                    })
                );
            }
            else if (response.status === 404) {
                toast.warning("Data not found", {
                    // onClose: () => {
                    //     setHeaderRowData((prevRowData) =>
                    //         prevRowData.map((row) => ({
                    //             ...row,
                    //             billTo: "",
                    //         }))
                    //     );
                    // },
                });
            } else {
                console.log("Bad request");
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
            toast.error("An error occurred while fetching customer details.", { position: toast.POSITION.TOP_RIGHT });
        } finally {
            setLoading(false);
        }

    };


    const handleCustomerDetailsShipTo = async (customerCode) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getCustomerDetails`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    customer_code: customerCode,
                    company_code: sessionStorage.getItem("selectedCompanyCode"),
                }),
            });

            if (response.ok) {
                const searchData = await response.json();
                console.log(searchData);

                const [{ customer_code, customer_name, customer_addr_1, customer_addr_2, customer_addr_3, customer_addr_4, customer_state,
                    customer_country, customer_mobile_no, contact_person, customer_gst_no }] = searchData

                setHeaderRowData((prevRowData) =>
                    prevRowData.map((row) => {
                        switch (row.fieldName) {
                            case 'Customer Code': return { ...row, shipTo: customer_code };
                            case 'Customer Name': return { ...row, shipTo: customer_name };
                            case 'Address 1': return { ...row, shipTo: customer_addr_1 };
                            case 'Address 2': return { ...row, shipTo: customer_addr_2 };
                            case 'Address 3': return { ...row, shipTo: customer_addr_3 };
                            case 'Address 4': return { ...row, shipTo: customer_addr_4 };
                            case 'State': return { ...row, shipTo: customer_state };
                            case 'Country': return { ...row, shipTo: customer_country };
                            case 'Mobile No': return { ...row, shipTo: customer_mobile_no };
                            case 'GST No': return { ...row, shipTo: customer_gst_no };
                            case 'Contact Person': return { ...row, shipTo: contact_person };
                            default: return row;
                        }
                    })
                );

            } else if (response.status === 404) {
                toast.warning("Data not found", {
                    // onClose: () => {
                    //     setHeaderRowData((prevRowData) =>
                    //         prevRowData.map((row) => ({
                    //             ...row,
                    //             shipTo: "",
                    //         }))
                    //     );
                    // },
                });
            } else {
                console.log("Bad request");
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }

    };

    const handleSwiftButtonClick = () => {
        const updatedRowData = headerRowData.map(row => ({
            ...row,
            shipTo: row.billTo
        }));
        setHeaderRowData(updatedRowData);
    };

    const [financialYearStart, setFinancialYearStart] = useState('');
    const [financialYearEnd, setFinancialYearEnd] = useState('');

    const handlePurchase = () => {
        setOpen(true);
    };

    const fetchCodes = (selectedValue) => {
        if (!invoicetype) {
            toast.warning("Please select the Invoice type and again select the filter");
            return;
        }
        fetch(`${config.apiBaseUrl}/getcodetest`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                company_code: sessionStorage.getItem("selectedCompanyCode"),
                filter: selectedValue,
            }),
        })
            .then((response) => response.json())
            .then((data) => {
                const formattedData = data.map((item) => ({
                    value: item.code,
                    label: `${item.code} - ${item.name}`,
                }));
                setDynamicOptions(formattedData);
            })
            .catch((error) => {
                console.error('Error fetching product codes:', error);
                // setError(true);
            });


    };

    const handleItemCode = async (selectedOption) => {
        const code = selectedOption ? selectedOption.value : null;
        const filter = selectedProduct ? selectedProduct.value : null;
        if (!salesType) {
            toast.warning("Please select the sales type.");
            return;
        }
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getCodeSalesDatatest`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    code: code,  // Selected code (product)
                    sales_type: salesType,  // Sales type (can be from a state or variable)
                    filter: filter,  // Selected filter (from the second dropdown)
                    company_code: sessionStorage.getItem("selectedCompanyCode"),  // Company code
                }),
            });

            if (response.ok) {
                const searchData = await response.json();

                const lastSerialNumber = rowData.length > 0 ? rowData[rowData.length - 1].serialNumber : 0;
                const updatedSerialNo = lastSerialNumber + 1;

                const newRows = searchData.map((matchedItem) => ({
                    serialNumber: updatedSerialNo,
                    productItemCode: matchedItem.Code,
                    productItemName: matchedItem.name,
                    productDescription: matchedItem.HeaderDescription,
                    HSNCode: matchedItem.hsn,
                    type: selectedProduct ? selectedProduct.value : '',
                    unitPrice: matchedItem.price,
                    taxType: matchedItem.tax_type,
                    taxDetail: matchedItem.combined_tax_details,
                    taxPercentage: matchedItem.combined_tax_percent,
                    keyField: `${updatedSerialNo}-${matchedItem.Code}-${Date.now()}`,
                }));

                setRowData((prevRowData) => [...prevRowData, ...newRows]);  // Update state with fetched rows
            } else if (response.status === 404) {
                toast.warning('Data not found');
            } else {
                console.log("Bad request");
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }

    };

    useEffect(() => {
        fetch(`${config.apiBaseUrl}/salestype`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                company_code: sessionStorage.getItem("selectedCompanyCode"),

            }),
        })

            .then((response) => response.json())
            .then((data) => {
                setSalesdrop(data);
                const defaultInvoice = data.find((item) => item.attributedetails_name === "LocalSales") || data[0];
                if (defaultInvoice) {
                    setSelectedSales({
                        value: defaultInvoice.attributedetails_name,
                        label: defaultInvoice.attributedetails_name,
                    });
                    setSalesType(defaultInvoice.attributedetails_name);
                }
            })
            .catch((error) => console.error("Error fetching sales types:", error));

        fetch(`${config.apiBaseUrl}/paytype`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                company_code: sessionStorage.getItem("selectedCompanyCode"),

            }),
        })
            .then((response) => response.json())
            .then((data) => {
                setPaydrop(data);
                const defaultInvoice = data.find((item) => item.attributedetails_name === "Credit") || data[0];
                if (defaultInvoice) {
                    setSelectedPay({
                        value: defaultInvoice.attributedetails_name,
                        label: defaultInvoice.attributedetails_name,
                    });
                    setPayType(defaultInvoice.attributedetails_name);
                }
            })
            .catch((error) => console.error("Error fetching payment types:", error));


        fetch(`${config.apiBaseUrl}/getInvocieType`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                company_code: sessionStorage.getItem("selectedCompanyCode"),

            }),
        })
            .then((response) => response.json())
            .then((data) => {
                setInvoicedrop(data);
                const defaultInvoice = data.find((item) => item.attributedetails_name === "Tax Invoice") || data[0];
                if (defaultInvoice) {
                    setselectedInvoice({
                        value: defaultInvoice.attributedetails_name,
                        label: defaultInvoice.attributedetails_name,
                    });
                    setInvoiceType(defaultInvoice.attributedetails_name);
                    setType(defaultInvoice.attributedetails_name);
                }
            })
            .catch((error) => console.error("Error fetching invoice types:", error));

    }, []);

    useEffect(() => {
        fetch(`${config.apiBaseUrl}/getItem`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                company_code: sessionStorage.getItem("selectedCompanyCode"),

            }),
        })

            .then((data) => data.json())
            .then((data) => {
                setProductDrop(data);
                const defaultProduct = data.find((item) => item.attributedetails_name === "Product") || data[0];
                if (defaultProduct) {
                    setSelectedProduct({
                        value: defaultProduct.attributedetails_name,
                        label: defaultProduct.attributedetails_name,
                    });
                    setProduct(defaultProduct.attributedetails_name);
                    if (defaultProduct.attributedetails_name === "Product" && invoicetype) {
                        fetchCodes(defaultProduct.attributedetails_name);
                    }
                }
            })
            .catch((error) => console.error("Error fetching products:", error));
    }, [invoicetype]);

    const filteredOptionProduct = productDrop.map((option) => ({
        value: option.attributedetails_name,
        label: option.attributedetails_name,
    }));

    const handleChangecode = (selectedOption) => {
        setSelectedProduct(selectedOption);
        setProduct(selectedOption ? selectedOption.value : '');
        setError(false);
        fetchCodes(selectedOption.value);
    };

    const filteredOptionPay = paydrop.map((option) => ({
        value: option.attributedetails_name,
        label: option.attributedetails_name,
    }));

    const filteredOptionSales = salesdrop.map((option) => ({
        value: option.attributedetails_name,
        label: option.attributedetails_name,
    }));

    const filteredOptionInvoice = invoicedrop.map((option) => ({
        value: option.attributedetails_name,
        label: option.attributedetails_name,
    }));


    const handleChangePay = (selectedOption) => {
        setSelectedPay(selectedOption);
        setPayType(selectedOption ? selectedOption.value : '');
    };

    const handleChangeSales = (selectedOption) => {
        setSelectedSales(selectedOption);
        setSalesType(selectedOption ? selectedOption.value : '');
    };

    const handleChangeInvoice = (selectedOption) => {
        setselectedInvoice(selectedOption);
        setInvoiceType(selectedOption ? selectedOption.value : '');
        setType(selectedOption ? selectedOption.value : '');
    };

    //Item Name Popup
    const [open, setOpen] = React.useState(false);
    const [open1, setOpen1] = React.useState(false);
    const [open2, setOpen2] = React.useState(false);


    const handleClose = () => {
        setOpen(false);
        setOpen1(false);
        setOpen2(false);
        setOpen3(false);
    };


    //CODE FOR TOTAL WEIGHT, TOTAL TAX AND TOTAL AMOUNT CALCULATION
    const TaxInvoiceItemAmountCalculation = async (params) => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/taxinvoiceitemamt`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    company_code: sessionStorage.getItem("selectedCompanyCode"),
                    type: params.data.type,
                    Item_SNO: params.data.serialNumber,
                    Item_code: params.data.productItemCode,
                    bill_qty: params.data.qty,
                    Item_amt: params.data.unitPrice,
                    tax_type_header: params.data.taxType,
                    tax_name_details: params.data.taxDetail,
                    tax_percentage: params.data.taxPercentage,
                    keyfield: params.data.keyField,
                    invoice_type: invoicetype,
                })
            });

            if (response.ok) {
                const searchData = await response.json();

                const updatedRowData = rowData.map(row => {
                    if (row.productItemCode === params.data.productItemCode &&
                        row.serialNumber === params.data.serialNumber) {
                        const matchedItem = searchData.find(item => {
                            console.log("Item ID being checked:", item.id);  // Printing item.id being checked
                            return item.id === row.id;
                        });
                        if (matchedItem) {
                            return {
                                ...row,
                                taxAmount: matchedItem.TotalTaxAmount,
                                totalAmount: matchedItem.TotalItemAmount
                            };
                        }
                    }
                    return row;
                });
                setRowData(updatedRowData);

                let updatedRowDataTaxCopy = [...rowDataTax];

                searchData.forEach(item => {
                    updatedRowDataTaxCopy = updatedRowDataTaxCopy.filter(row =>
                        !(row.ItemSNO === item.ItemSNO && row.TaxSNO === item.TaxSNO)
                    );

                    const newRow = {
                        ItemSNO: item.ItemSNO,
                        TaxSNO: item.TaxSNO,
                        Item_code: item.Item_code,
                        taxDetail: item.TaxType,
                        TaxPercentage: item.TaxPercentage ?? 0,
                        TaxAmount: item.TaxAmount,
                        keyfield: item.keyfield,
                    };

                    updatedRowDataTaxCopy.push(newRow);
                });
                updatedRowDataTaxCopy.sort((a, b) => a.ItemSNO - b.ItemSNO);

                setRowDataTax(updatedRowDataTaxCopy);



                const hasQty = updatedRowData.some(row => row.qty >= 0);

                if (hasQty) {
                    const totalItemAmounts = updatedRowData.map(row => row.totalAmount || 0).join(',');
                    const totalTaxAmounts = updatedRowData.map(row => row.taxAmount || 0).join(',');

                    const formattedTotalItemAmounts = totalItemAmounts.endsWith(',') ? totalItemAmounts.slice(0, -1) : totalItemAmounts;
                    const formattedTotalTaxAmounts = totalTaxAmounts.endsWith(',') ? totalTaxAmounts.slice(0, -1) : totalTaxAmounts;

                    await TotalAmountCalculation(formattedTotalTaxAmounts, formattedTotalItemAmounts)
                    console.log("TotalAmountCalculation executed successfully");
                } else {
                    console.log("No rows with purchaseQty greater than 0 found");
                }
                console.log("Data fetched successfully");
            } else if (response.status === 404) {
                console.log("Data not found");
            } else {
                const errorResponse = await response.json();
                console.error(errorResponse.error);
                toast.error(errorResponse.message);
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
            toast.error(error.message);

        }
    };


    const TotalAmountCalculation = async (formattedTotalTaxAmounts, formattedTotalItemAmounts) => {
        if (parseFloat(formattedTotalTaxAmounts) >= 0 && parseFloat(formattedTotalItemAmounts) >= 0) {
            try {
                const response = await fetch(`${config.apiBaseUrl}/taxinvoicetotamt`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({ Tax_amount: formattedTotalTaxAmounts, company_code: sessionStorage.getItem("selectedCompanyCode"), Putchase_amount: formattedTotalItemAmounts }),
                });
                if (response.ok) {
                    const data = await response.json();
                    console.table(data)
                    const [{ rounded_amount, round_difference, TotalPurchase, TotalTax }] = data;
                    setTotalBill(formatToTwoDecimalPoints(rounded_amount));
                    setRoundDifference(formatToTwoDecimalPoints(round_difference));
                    setTotalAmt(formatToTwoDecimalPoints(TotalPurchase));
                    setTotalTax(formatToTwoDecimalPoints(TotalTax));
                } else {
                    const errorMessage = await response.text();
                    console.error(`Server responded with error: ${errorMessage}`);
                }
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        }
    };

    const BalanceAmountCalculation = async () => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/taxInvoiceBalanceAmountCalculation`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ TotalAmount: TotalBill, AdvanceAmount: advanceAmount }),
            });
            if (response.ok) {
                const data = await response.json();
                const [{ Balance_Amount }] = data;
                setBalanceAmount(formatToTwoDecimalPoints(Balance_Amount))
            } else {
                const errorMessage = await response.text();
                console.error(`Server responded with error: ${errorMessage}`);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    // useEffect(() => {
    //     BalanceAmountCalculation();
    // }, [TotalBill, advanceAmount]);

    //CODE ITEM CODE TO ADD NEW ROW FUNCTION
    const handleCellValueChanged = (params) => {
        const { colDef, rowIndex, newValue } = params;
        const lastRowIndex = rowData.length - 1;

        if (colDef.field === 'purchaseQty') {
            const quantity = parseFloat(newValue);

            if (quantity > 0 && rowIndex === lastRowIndex) {
                const serialNumber = rowData.length + 1;
                const newRowData = {
                    serialNumber,
                    itemName: null,
                    unitWeight: null,
                    warehouse: null,
                    purchaseQty: 0,
                    totalWeight: null,
                    purchaseAmt: null,
                    taxAmt: null,
                    totalAmt: null,
                };
                setRowData(prevRowData => [...prevRowData, newRowData]);
            }
        }
    };

    const handleDelete = (params) => {
        const serialNumberToDelete = params.data.serialNumber;

        const updatedRowData = rowData.filter(row => Number(row.serialNumber) !== Number(serialNumberToDelete));
        const updatedRowDataTax = rowDataTax.filter(row => Number(row.ItemSNO) !== Number(serialNumberToDelete));

        setRowData(updatedRowData);
        setRowDataTax(updatedRowDataTax);

        const updatedRowDataWithNewSerials = updatedRowData.map((row, index) => ({
            ...row,
            serialNumber: index + 1
        }));
        setRowData(updatedRowDataWithNewSerials);

        const updatedRowDataTaxWithNewSerials = updatedRowDataTax.map((taxRow) => {
            const correspondingRow = updatedRowDataWithNewSerials.find(
                (dataRow) => dataRow.keyField === taxRow.keyfield
            );

            return correspondingRow
                ? { ...taxRow, ItemSNO: correspondingRow.serialNumber.toString() }
                : taxRow;
        });
        setRowDataTax(updatedRowDataTaxWithNewSerials);

        let totalItemAmounts, totalTaxAmounts;

        if (updatedRowData.length === 0) {
            totalItemAmounts = '0.00';
            totalTaxAmounts = '0.00';
        } else {
            totalItemAmounts = updatedRowData.map(row => row.totalAmount || '0.00').join(',');
            totalTaxAmounts = updatedRowData.map(row => row.taxAmount || '0.00').join(',');
        }

        const formattedTotalItemAmounts = totalItemAmounts.endsWith(',') ? totalItemAmounts.slice(0, -1) : totalItemAmounts;
        const formattedTotalTaxAmounts = totalTaxAmounts.endsWith(',') ? totalTaxAmounts.slice(0, -1) : totalTaxAmounts;

        TotalAmountCalculation(formattedTotalTaxAmounts, formattedTotalItemAmounts);
    };

    const DeleteTerms = (params) => {
        const { data } = params;
        setrowDataTerms((prevRows) => {
            const updatedRows = prevRows.filter((row) => row !== data);
            if (updatedRows.length === 0) {
                return [
                    {
                        serialNumber: 1,
                        Terms_conditions: "",
                    },
                ];
            }
            return updatedRows.map((row, index) => ({
                ...row,
                serialNumber: index + 1,
            }));
        });
    };

    function qtyValueSetter(params) {
        const newValue = parseFloat(params.newValue);

        if (isNaN(newValue) || params.newValue.toString().trim() === '' || params.newValue.toString().match(/[^0-9.]/)) {
            toast.warning("Please enter a valid numeric quantity.");
            return false;
        }

        if (newValue < 0) {
            toast.warning("Quantity cannot be negative.");
            return false;
        }

        params.data.qty = newValue;
        return true;
    }


    const columnDefs = [
        {
            headerName: 'S.No',
            field: 'serialNumber',
            maxWidth: 80,
            sortable: false,
            editable: false
        },
        {
            headerName: '',
            field: 'delete',
            editable: true,
            maxWidth: 50,
            tooltipValueGetter: (p) =>
                "Delete",
            onCellClicked: handleDelete,
            cellRenderer: function (params) {
                return <FontAwesomeIcon icon="fa-solid fa-trash" style={{ cursor: 'pointer' }} />
            },
            sortable: false,
            // hide: !isDeleteVisible,
        },
        {
            headerName: 'Product / Item Code',
            field: 'productItemCode',
            editable: false,
            filter: true,
            sortable: false
        },
        {
            headerName: 'Product / Item Name',
            field: 'productItemName',
            editable: true,
            filter: true,
            sortable: false
        },
        {
            headerName: 'Product Description',
            field: 'productDescription',
            editable: true,
            filter: true,
            sortable: false,
            wrapText: true,
            // minWidth: 400,
            // maxWidth: 400,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
        },
        {
            headerName: 'HSN Code',
            field: 'HSNCode',
            editable: false,
            filter: true
        },
        {
            headerName: 'Qty',
            field: 'qty',
            editable: true,
            filter: true,
            sortable: false,
            valueSetter: qtyValueSetter,
        },
        {
            headerName: 'Unit Price',
            field: 'unitPrice',
            editable: true,
            filter: true,
            sortable: false
        },
        {
            headerName: 'Type',
            field: 'type',
            editable: false,
            filter: true,
            hide: true
        },
        {
            headerName: 'Tax Type',
            field: 'taxType',
            editable: true,
            filter: true,
            hide: true,
            sortable: false
        },
        {
            headerName: 'Tax Detail',
            field: 'taxDetail',
            editable: true,
            filter: true,
            hide: true,
            sortable: false
        },
        {
            headerName: 'Tax Percentage',
            field: 'taxPercentage',
            editable: true,
            filter: true,
            hide: true,
            sortable: false
        },
        {
            headerName: 'Tax Amount',
            field: 'taxAmount',
            editable: false,
            hide: false
        },
        {
            headerName: 'Total',
            field: 'totalAmount',
            editable: false,
            filter: true,
            sortable: false,
        },
        {
            headerName: 'KeyField',
            field: 'keyField',
            editable: false,
            // maxWidth: 150,
            filter: true,
            sortable: false,
            hide: true,
        }
    ];

    //DEFINE TAX DETAIL COLUMNS
    const columnDefsTax = [
        {
            headerName: 'S.No',
            field: 'ItemSNO',
            maxWidth: 250,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Tax S.No',
            field: 'TaxSNO',
            maxWidth: 120,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Product / Item Code',
            field: 'Item_code',
            // minWidth: 315,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Tax Type',
            field: 'taxDetail',
            // minWidth: 201,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Tax %',
            field: 'TaxPercentage',
            // minWidth: 201,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Tax Amount',
            field: 'TaxAmount',
            // minWidth: 301,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Keyfield',
            field: 'keyfield',
            // minWidth: 301,
            sortable: false,
            editable: false,
            hide: true,
        }
    ];

    const columnDefsTermsConditions = [
        {
            headerName: 'S.No',
            field: 'serialNumber',
            maxWidth: 70,
            valueGetter: (params) => params.node.rowIndex + 1,
            sortable: false,
            minHeight: 50,
            maxHeight: 50,
        },
        {
            headerName: '',
            field: 'delete',
            editable: false,
            maxWidth: 25,
            tooltipValueGetter: () => "Delete",
            onCellClicked: DeleteTerms,
            cellRenderer: function () {
                return <FontAwesomeIcon icon="fa-solid fa-trash" style={{ cursor: 'pointer', marginRight: "12px" }} />;
            },
            cellStyle: { display: 'flex', justifyContent: 'center', alignItems: 'center' },
            sortable: false,
            minHeight: 50,
            maxHeight: 50,
        },
        {
            headerName: 'Terms & Conditions',
            field: 'Terms_conditions',
            // minWidth: 1000,
            // maxWidth: 1000,
            minHeight: 50,
            maxHeight: 50,
            sortable: false,
            editable: true,
            onCellValueChanged: (params) => handleValueChanged(params),
        },
    ];

    const handleValueChanged = (params) => {
        const { data, colDef } = params;
        // Ensure the field is Terms_conditions and the value is not empty
        if (colDef.field === "Terms_conditions" && data.Terms_conditions?.trim() !== "") {
            const isLastRow = rowDataTerms[rowDataTerms.length - 1] === data;
            if (isLastRow) {
                // Add a new row with an incremented serial number
                const newRow = {
                    serialNumber: rowDataTerms.length + 1,
                    Terms_conditions: "", // Ensure the correct field name is used
                };
                setrowDataTerms((prevRows) => [...prevRows, newRow]);
            }
        }
    };


    //CODE TO SAVE PURCHASE HEADER 
    const handleSaveButtonClick = async () => {

        if (!bill_date || !payType || !salesType) {
            setError(" ");
            toast.warning("Error: Missing required fields");
            return;
        }
        setLoading(true)
        try {

            const billToData = headerRowData.reduce((acc, row) => {
                acc[row.fieldName] = row.billTo;
                return acc;
            }, {});

            const Notes = notesRowData.reduce((acc, row) => {
                acc[row.fieldName] = row.notes;
                return acc;
            }, {});

            const PINotes = PINotesRowData.reduce((acc, row) => {
                acc[row.fieldName] = row.PInotes;
                return acc;
            }, {});

            const shipToData = headerRowData.reduce((acc, row) => {
                acc[row.fieldName] = row.shipTo;
                return acc;
            }, {});

            const Header = {
                company_code: sessionStorage.getItem('selectedCompanyCode'),
                pay_type: payType,
                sales_type: salesType,
                invoice_type: invoicetype,
                bill_date: bill_date,
                sale_amt: totalamt,
                Performa_bill_no: new_running_no,
                tax_amount: TotalTax,
                bill_amt: TotalBill,
                roff_amt: round_difference,
                customer_code: billToData['Customer Code'],
                billTo_customer_name: billToData['Customer Name'],
                billTo_customer_addr_1: billToData['Address 1'],
                billTo_customer_addr_2: billToData['Address 2'],
                billTo_customer_addr_3: billToData['Address 3'],
                billTo_customer_addr_4: billToData['Address 4'],
                billTo_customer_state: billToData['State'],
                billTo_customer_country: billToData['Country'],
                billTo_customer_mobile_no: billToData['Mobile No'],
                billTo_customer_gst_no: billToData['GST No'],
                billTo_contact_person: billToData['Contact Person'],
                shipTo_customer_code: shipToData['Customer Code'],
                shipTo_customer_name: shipToData['Customer Name'],
                shipTo_customer_addr_1: shipToData['Address 1'],
                shipTo_customer_addr_2: shipToData['Address 2'],
                shipTo_customer_addr_3: shipToData['Address 3'],
                shipTo_customer_addr_4: shipToData['Address 4'],
                shipTo_customer_state: shipToData['State'],
                shipTo_customer_country: shipToData['Country'],
                shipTo_customer_mobile_no: shipToData['Mobile No'],
                ShipTo_customer_gst_no: shipToData['GST No'],
                shipTo_contact_person: shipToData['Contact Person'],
                advance_amount: advanceAmount,
                bal_amt: balanceAmount,
                Location_Code,
                created_by: sessionStorage.getItem('selectedUserCode'),
                pending: pendingStatus,
                ...(selectedInvoice?.label === "Proforma Invoice"
                    ? {
                        delivery_note: PINotes["Delivery Note"] ? PINotes["Delivery Note"] : null,
                        dispatched_through: PINotes["Dispatched Through"] ? PINotes["Dispatched Through"] : null,
                        destination: PINotes["Destination"] ? PINotes["Destination"] : null,
                    }
                    : {
                        po_no: Notes["PO No"] ? Notes["PO No"] : null,
                        Eway_bill_no: Notes["E-Way Bill No"] ? Notes["E-Way Bill No"] : null,
                        supplier_ref: Notes["Supplier Ref"] ? Notes["Supplier Ref"] : null,
                        po_date: Notes["PO Date"] ? Notes["PO Date"] : null,
                        document_type: Notes["Document Type"] ? Notes["Document Type"] : null,
                        delivered_through: Notes["Delivered Through"] ? Notes["Delivered Through"] : null,
                    }),
            };

            const response = await fetch(`${config.apiBaseUrl}/addtaxInvoicehdr`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(Header),
            });

            if (response.ok) {
                const searchData = await response.json();
                console.log(searchData);
                const [{ bill_no }] = searchData;
                setNew_running_no(bill_no);

                toast.success("Data inserted Successfully")

                await saveTaxInvoiceDetails(bill_no);
                await SaveTaxDetails(bill_no);
                await saveTIDetailsTerms(bill_no);
                setShowExcelButton(true);
                setDelButtonVisible(true);
                setPrintButtonVisible(true);
            } else {
                const errorResponse = await response.json();
                console.error(errorResponse.message);
                toast.error(errorResponse.message);
            }
        } catch (error) {
            console.error("Error inserting data:", error);
            toast.error('Error inserting data: ' + error.message);
        } finally {
            setLoading(false);
        }

    };

    //CODE TO SAVE TAX INVOICE DETAILS
    const saveTaxInvoiceDetails = async (bill_no) => {
        try {

            for (const row of rowData) {
                const Details = {
                    company_code: sessionStorage.getItem('selectedCompanyCode'),
                    created_by: sessionStorage.getItem('selectedUserCode'),
                    customer_code: headerRowData[0].billTo,
                    customer_name: headerRowData[1].billTo,
                    bill_no: bill_no,
                    sales_type: salesType,
                    invoice_type: invoicetype,
                    bill_date: bill_date,
                    pay_type: payType,
                    bill_date: bill_date,
                    SNo: row.serialNumber,
                    code: row.productItemCode,
                    name: row.productItemName,
                    Description: row.productDescription,
                    bill_qty: row.qty,
                    bill_rate: row.totalAmount,
                    unit_price: row.unitPrice,
                    tax_amt: row.taxAmount,
                    hsn_code: row.HSNCode,
                    type: row.type,
                    Location_Code
                };

                const response = await fetch(`${config.apiBaseUrl}/addTaxInvoicedetail_list`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(Details),
                });

                if (response.ok) {
                    console.log("Tax Invoice Detail Data inserted successfully");
                } else {
                    const errorResponse = await response.json();
                    console.error(errorResponse.message);
                    toast.error(errorResponse.message);
                }
            }
        } catch (error) {
            console.error("Error inserting data:", error);
        }
    };


    const SaveTaxDetails = async (bill_no) => {
        try {
            const savedRows = new Set();

            for (const row of rowData) {
                const matchingTaxRows = rowDataTax.filter(taxRow => taxRow.Item_code === row.productItemCode);

                for (const taxRow of matchingTaxRows) {
                    const uniqueKey = `${bill_no}-${taxRow.ItemSNO}-${taxRow.TaxSNO}`;

                    if (savedRows.has(uniqueKey)) {
                        continue;
                    }

                    const Details = {
                        company_code: sessionStorage.getItem("selectedCompanyCode"),
                        item_code: row.productItemCode,
                        item_name: row.productItemName,
                        pay_type: payType,
                        invoice_type: invoicetype,
                        bill_date: bill_date,
                        bill_no: bill_no,
                        ItemSNo: taxRow.ItemSNO,
                        TaxSNo: taxRow.TaxSNO,
                        tax_type: row.taxType,
                        tax_name_details: taxRow.taxDetail,
                        tax_amt: taxRow.TaxAmount,
                        tax_per: taxRow.TaxPercentage,
                        Location_Code,
                        created_by: sessionStorage.getItem('selectedUserCode')
                    };

                    const response = await fetch(`${config.apiBaseUrl}/addTaxInvoiceTaxdetail`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify(Details),
                    });

                    if (response.ok) {
                        console.log("Tax Invoice Detail Data inserted successfully");
                        savedRows.add(uniqueKey);
                    } else {
                        const errorResponse = await response.json();
                        console.error(errorResponse.error);
                        toast.warning(errorResponse.message);
                    }
                }
            }
        } catch (error) {
            console.error("Error inserting data:", error);
            toast.error('Error inserting data: ' + error.message);
        }
    };

    const saveTIDetailsTerms = async (bill_no) => {

        try {
            // Filter rows where Terms_conditions is non-empty
            const validRows = rowDataTerms.filter(row => row.Terms_conditions.trim() !== '');
            if (validRows.length === 0) {
                toast.warning('No valid Terms & Conditions to save.');
                return;
            }
            for (const row of validRows) {
                const Details = {
                    created_by: sessionStorage.getItem('selectedUserCode'),
                    company_code: sessionStorage.getItem('selectedCompanyCode'),
                    invoice_type: invoicetype,
                    bill_no: bill_no,
                    Location_Code,
                    Terms_conditions: row.Terms_conditions
                };

                const response = await fetch(`${config.apiBaseUrl}/TITermsandConditions`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(Details),
                });

                if (response.ok) {
                    console.log("Dc Detail Data inserted successfully");
                } else {
                    const errorResponse = await response.json();
                    console.error(errorResponse.message); // Log error message
                    toast.warning(errorResponse.message);
                }
            }
        } catch (error) {
            console.error("Error saving data:", error);
            toast.error('Error saving data: ' + error.message);
        }
    };


    const handleUpdateButtonClick = async () => {
        if (!new_running_no || !bill_date || !payType || !salesType) {
            setError(" ");
            toast.warning("Error: Missing required fields");
            return;
        }
        setLoading(true)
        try {
            const billToData = headerRowData.reduce((acc, row) => {
                acc[row.fieldName] = row.billTo;
                return acc;
            }, {});

            const Notes = notesRowData.reduce((acc, row) => {
                acc[row.fieldName] = row.notes;
                return acc;
            }, {});

            const PINotes = PINotesRowData.reduce((acc, row) => {
                acc[row.fieldName] = row.PInotes;
                return acc;
            }, {});

            const shipToData = headerRowData.reduce((acc, row) => {
                acc[row.fieldName] = row.shipTo;
                return acc;
            }, {});

            // const customer_code = headerRowData[0].billTo;
            // const billTo_customer_name = headerRowData[1].billTo;
            // const billTo_customer_addr_1 = headerRowData[2].billTo;
            // const billTo_customer_addr_2 = headerRowData[3].billTo;
            // const billTo_customer_addr_3 = headerRowData[4].billTo;
            // const billTo_customer_addr_4 = headerRowData[5].billTo;
            // const billTo_customer_state = headerRowData[6].billTo;
            // const billTo_customer_country = headerRowData[7].billTo;
            // const billTo_customer_mobile_no = headerRowData[8].billTo;
            // const billTo_contact_person = headerRowData[9].billTo;

            // const shipTo_customer_code = headerRowData[0].shipTo;
            // const shipTo_customer_name = headerRowData[1].shipTo;
            // const shipTo_customer_addr_1 = headerRowData[2].shipTo;
            // const shipTo_customer_addr_2 = headerRowData[3].shipTo;
            // const shipTo_customer_addr_3 = headerRowData[4].shipTo;
            // const shipTo_customer_addr_4 = headerRowData[5].shipTo;
            // const shipTo_customer_state = headerRowData[6].shipTo;
            // const shipTo_customer_country = headerRowData[7].shipTo;
            // const shipTo_customer_mobile_no = headerRowData[8].shipTo;
            // const shipTo_contact_person = headerRowData[9].shipTo;

            const Header = {
                company_code: sessionStorage.getItem('selectedCompanyCode'),
                bill_no: new_running_no,
                invoice_type: invoicetype,
                pay_type: payType,
                sales_type: salesType,
                bill_date: bill_date,
                sale_amt: totalamt,
                tax_amount: TotalTax,
                bill_amt: TotalBill,
                roff_amt: round_difference,
                customer_code: billToData['Customer Code'],
                billTo_customer_name: billToData['Customer Name'],
                billTo_customer_addr_1: billToData['Address 1'],
                billTo_customer_addr_2: billToData['Address 2'],
                billTo_customer_addr_3: billToData['Address 3'],
                billTo_customer_addr_4: billToData['Address 4'],
                billTo_customer_state: billToData['State'],
                billTo_customer_country: billToData['Country'],
                billTo_customer_mobile_no: billToData['Mobile No'],
                billTo_customer_gst_no: billToData['GST No'],
                billTo_contact_person: billToData['Contact Person'],
                shipTo_customer_code: shipToData['Customer Code'],
                shipTo_customer_name: shipToData['Customer Name'],
                shipTo_customer_addr_1: shipToData['Address 1'],
                shipTo_customer_addr_2: shipToData['Address 2'],
                shipTo_customer_addr_3: shipToData['Address 3'],
                shipTo_customer_addr_4: shipToData['Address 4'],
                shipTo_customer_state: shipToData['State'],
                shipTo_customer_country: shipToData['Country'],
                shipTo_customer_mobile_no: shipToData['Mobile No'],
                ShipTo_customer_gst_no: shipToData['GST No'],
                shipTo_contact_person: shipToData['Contact Person'],
                advance_amount: advanceAmount,
                bal_amt: balanceAmount,
                Location_Code,
                modified_by: sessionStorage.getItem('selectedUserCode'),
                ...(selectedInvoice?.label === "Proforma Invoice"
                    ? {
                        delivery_note: PINotes["Delivery Note"] ? PINotes["Delivery Note"] : null,
                        dispatched_through: PINotes["Dispatched Through"] ? PINotes["Dispatched Through"] : null,
                        destination: PINotes["Destination"] ? PINotes["Destination"] : null,
                    }
                    : {
                        po_no: Notes["PO No"] ? Notes["PO No"] : null,
                        Eway_bill_no: Notes["E-Way Bill No"] ? Notes["E-Way Bill No"] : null,
                        supplier_ref: Notes["Supplier Ref"] ? Notes["Supplier Ref"] : null,
                        po_date: Notes["PO Date"] ? Notes["PO Date"] : null,
                        document_type: Notes["Document Type"] ? Notes["Document Type"] : null,
                        delivered_through: Notes["Delivered Through"] ? Notes["Delivered Through"] : null,
                    }),
            };

            const response = await fetch(`${config.apiBaseUrl}/TaxInvoiceUpdate`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(Header),
            });

            if (response.ok) {


                await saveTaxInvoiceDetails(new_running_no);
                await SaveTaxDetails(new_running_no);
                await saveTIDetailsTerms(new_running_no);
                setShowExcelButton(true);
                setDelButtonVisible(true);
                setPrintButtonVisible(true);
                setButtonsVisible(false);
                toast.success("Tax Invoice Data updated Successfully")

            } else {
                const errorResponse = await response.json();
                console.error(errorResponse.message);
                toast.error('Error inserting data' + errorResponse.message);
            }
        } catch (error) {
            console.error("Error inserting data:", error);
            toast.error('Error inserting data: ' + error.message);
        } finally {
            setLoading(false);
        }

    };

    //CODE TO SAVE TAX INVOICE DETAILS
    // const UpdTaxInvoiceDetails = async (bill_no) => {
    //     try {

    //         for (const row of rowData) {
    //             const Details = {
    //                 company_code: sessionStorage.getItem('selectedCompanyCode'),
    //                 created_by: sessionStorage.getItem('selectedUserCode'),
    //                 customer_code: headerRowData[0].billTo,
    //                 bill_no: bill_no,
    //                 sales_type: salesType,
    //                 bill_date: bill_date,
    //                 pay_type: payType,
    //                 bill_date: bill_date,
    //                 SNo: row.serialNumber,
    //                 code: row.productItemCode,
    //                 name: row.productItemName,
    //                 Description: row.productDescription,
    //                 bill_qty: row.qty,
    //                 bill_rate: row.totalAmount,
    //                 unit_price: row.unitPrice,
    //                 tax_amt: row.taxAmount,
    //                 hsn_code: row.HSNCode,
    //                 type: row.type
    //             };

    //             const response = await fetch(`${config.apiBaseUrl}/addTaxInvoicedetail_list`, {
    //                 method: "POST",
    //                 headers: {
    //                     "Content-Type": "application/json",
    //                 },
    //                 body: JSON.stringify(Details),
    //             });

    //             if (response.ok) {
    //                 console.log("Tax Invoice Detail Data inserted successfully");
    //             } else {
    //                 const errorResponse = await response.json();
    //                 console.error(errorResponse.message); // Log error message
    //                 toast.error(errorResponse.message);
    //             }
    //         }
    //     } catch (error) {
    //         console.error("Error inserting data:", error);
    //     }
    // };


    // const UpdTaxDetails = async (bill_no) => {
    //     try {
    //         for (const row of rowData) {
    //             const matchingTaxRows = rowDataTax.filter(taxRow => taxRow.Item_code === row.productItemCode);

    //             for (const taxRow of matchingTaxRows) {
    //                 const Details = {
    //                     company_code: sessionStorage.getItem("selectedCompanyCode"),
    //                     item_code: row.productItemCode,
    //                     item_name: row.productItemName,
    //                     pay_type: payType,
    //                     bill_date: bill_date,
    //                     bill_no: bill_no,
    //                     ItemSNo: taxRow.ItemSNO,
    //                     TaxSNo: taxRow.TaxSNO,
    //                     tax_type: row.taxType,
    //                     tax_name_details: taxRow.taxDetail,
    //                     tax_amt: taxRow.TaxAmount,
    //                     tax_per: taxRow.TaxPercentage,
    //                     created_by: sessionStorage.getItem('selectedUserCode')
    //                 };

    //                 const response = await fetch(`${config.apiBaseUrl}/addTaxInvoiceTaxdetail`, {
    //                     method: "POST",
    //                     headers: {
    //                         "Content-Type": "application/json",
    //                     },
    //                     body: JSON.stringify(Details),
    //                 });

    //                 if (response.ok) {
    //                     console.log("Tax Invoice Detail Data inserted successfully");
    //                 } else if (response.status === 400) {
    //                     const errorResponse = await response.json();
    //                     console.error(errorResponse.error);
    //                     toast.warning(errorResponse.message);
    //                 } else {
    //                     console.error("Failed to insert data for row");
    //                 }
    //             }
    //         }
    //     } catch (error) {
    //         console.error("Error inserting data:", error);
    //         toast.error('Error inserting data: ' + error.message);
    //     }
    // };


    const PrintHeaderData = async () => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/TaxInvocieHdrPrint`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ company_code: sessionStorage.getItem('selectedCompanyCode'), transaction_no: new_running_no, invoice_type: invoicetype })
            });

            if (response.ok) {
                const searchData = await response.json();
                return searchData;
            } else if (response.status === 404) {
                console.log("Data not found");
            } else {
                console.log("Bad request"); // Log the message for other errors
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        }
    };

    const PrintDetailData = async () => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/TaxInvocieDetPrint`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ company_code: sessionStorage.getItem('selectedCompanyCode'), transaction_no: new_running_no, invoice_type: invoicetype })
            });

            if (response.ok) {
                const searchData = await response.json();
                return searchData;
            } else if (response.status === 404) {
                console.log("Data not found");
            } else {
                console.log("Bad request"); // Log the message for other errors
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        }
    };

    const PrintSumTax = async () => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/taxinvoicetaxprint`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ company_code: sessionStorage.getItem('selectedCompanyCode'), transaction_no: new_running_no, invoice_type: invoicetype })
            });

            if (response.ok) {
                const searchData = await response.json();
                return searchData;
            } else if (response.status === 404) {
                console.log("Data not found");
            } else {
                console.log("Bad request");
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        }
    };

    const openPrintWindow = (url, headerKey, detailKey, taxKey) => {
        const openWindow = (targetUrl) => {
            const printWindow = window.open(targetUrl, '_blank');
            if (printWindow) {
                printWindow.addEventListener("beforeunload", () => {
                    sessionStorage.removeItem(headerKey);
                    sessionStorage.removeItem(detailKey);
                    sessionStorage.removeItem(taxKey);
                    console.log("Session storage cleared after print window closed.");
                });
            }
        };

        if (url === '/TaxInvoicePrint') {
            for (let i = 1; i <= 3; i++) {
                openWindow(`${url}?page=${i}`);
            }
        } else {
            openWindow(url);
        }
    };


    const generateReport = async () => {
        if (!new_running_no) {
            setDeleteError(" ");
            toast.warning('Error: Missing required fields');
            return;
        }

        if (!templateName) {
            toast.error("Template name not set.");
            return;
        }

        setLoading(true);
        try {
            const headerData = await PrintHeaderData();
            const detailData = await PrintDetailData();
            const taxData = await PrintSumTax();

            if (headerData && detailData && taxData) {
                console.log("All API calls completed successfully");

                let headerKey, detailKey, taxKey;
                const url = `/${templateName}`; // 🔁 Dynamically use templateName

                if (invoicetype === "Tax Invoice") {
                    headerKey = 'TaxInvoiceheaderData';
                    detailKey = 'TaxInvoicedetailData';
                    taxKey = 'TaxInvoicetaxData';
                } else if (invoicetype === "Proforma Invoice") {
                    headerKey = 'PerformaInvoiceheaderData';
                    detailKey = 'PerformaInvoicedetailData';
                    taxKey = 'PerformaInvoicetaxData';
                } else {
                    toast.error("Transaction Number Does Not Exist");
                    return;
                }

                // Save data to sessionStorage
                sessionStorage.setItem(headerKey, LZString.compress(JSON.stringify(headerData)));
                sessionStorage.setItem(detailKey, LZString.compress(JSON.stringify(detailData)));
                sessionStorage.setItem(taxKey, LZString.compress(JSON.stringify(taxData)));

                // 🔁 Apply print logic from your 1st code
                if (printOption === "Print Preview") {
                    window.open(url, '_blank');
                } else if (printOption === "Print") {
                    for (let i = 0; i < printCopies; i++) {
                        const printWindow = window.open(`${url}?print=true`, '_blank', 'width=800,height=600,top=100,left=100');
                        if (printWindow) {
                            printWindow.onload = () => {
                                printWindow.focus();
                                printWindow.print();
                                // Optionally don't close so user can view it
                                // printWindow.close();
                            };
                            printWindow.addEventListener("beforeunload", () => {
                                sessionStorage.removeItem(headerKey);
                                sessionStorage.removeItem(detailKey);
                                sessionStorage.removeItem(taxKey);
                                console.log("Session storage cleared after print window closed.");
                            });
                        }
                    }
                }
            }
        } catch (error) {
            console.error("Error executing API calls:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleRowClicked = (event) => {
        const clickedRowIndex = event.rowIndex;
        setClickedRowIndex(clickedRowIndex)
    };

    const handleTransactionDateChange = (e) => {
        const date = e.target.value;
        if (date >= financialYearStart && date <= financialYearEnd) {
            setbill_date(date);
        } else {
            toast.warning('Transaction date must be between April 1st, 2024 and March 31st, 2025.');
        }
    };

    const onGridReady = (params) => {
        console.log("Grid is ready");
        const columnState = localStorage.getItem('myColumnState');
        if (columnState) {
            params.columnApi.applyColumnState({ state: JSON.parse(columnState) });
        }
    };

    const onColumnMoved = (params) => {
        const columnState = JSON.stringify(params.columnApi.getColumnState());
        localStorage.setItem('myColumnState', columnState);
    };

    const handleChangeNo = (e) => {
        const refNo = e.target.value;
        setNew_running_no(refNo);
    }

    const formatDate = (value) => {
        if (!value) return ''; // if null, undefined, '', etc.

        const date = new Date(value);

        // Optional: handle invalid date explicitly
        if (isNaN(date.getTime())) return '';

        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        // Final check: avoid showing 1900-01-01
        if (year === 1900 && month === '01' && day === '01') return '';

        return `${year}-${month}-${day}`;
    };

    const formatToTwoDecimalPoints = (number) => {
        return parseFloat(number).toFixed(2);
    };

    const handleKeyPressRef = (e) => {
        if (e.key === 'Enter') {
            handleRefNo(new_running_no)
        }
    };

    const formatDateForDisplay = (dateString) => {
        if (!dateString) return "";
        const dateObj = new Date(dateString);
        const day = String(dateObj.getDate()).padStart(2, "0");
        const month = String(dateObj.getMonth() + 1).padStart(2, "0");
        const year = dateObj.getFullYear();
        return `${day}-${month}-${year}`; // Returns dd-mm-yyyy format
    };

    const formatDateForSend = (dateString) => {
        if (!dateString) return null;

        const parts = dateString.split('-');

        if (parts.length === 3) {
            const day = parts[0].padStart(2, '0');  // Ensuring day has two digits
            const month = parts[1].padStart(2, '0');  // Ensuring month has two digits
            const year = parts[2];

            return `${year}-${month}-${day}`;
        } else {
            console.error("Invalid date format");
            return null;
        }
    };

    const handleRefNo = async (code) => {
        setLoading(true)
        try {
            const tempstr1Value = isChecked ? "Proforma Invoice" : invoicetype;
            const response = await fetch(`${config.apiBaseUrl}/getTaxInvoiceNo`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ transaction_no: code, company_code: sessionStorage.getItem('selectedCompanyCode'), tempstr1: tempstr1Value })
            });
            if (response.ok) {
                if (!isChecked) {
                    setButtonsVisible(false);
                    setDelButtonVisible(true)
                    setPrintButtonVisible(true)
                    setShowExcelButton(true);
                    setShowUpdateButton(true);
                }

                setIsDeleteVisible(true);
                setShowAsterisk(true);
                setShowDropdown(true);
                const searchData = await response.json();
                if (searchData.Header && searchData.Header.length > 0) {
                    const item = searchData.Header[0];
                    setNew_running_no(item.bill_no)
                    setTotalTax(item.tax_amount)
                    setTotalBill(item.bill_amt)
                    setRoundDifference(item.roff_amt)
                    setTotalAmt(item.sale_amt)
                    setAdvanceAmount(item.Advance_Amount)
                    setBalanceAmount(item.bal_amt)
                    setbill_date(formatDate(item.bill_date));

                    const selectedOption = filteredOptionSales.find(option => option.value === item.sales_type);
                    setSelectedSales(selectedOption);
                    setSalesType(selectedOption.value)

                    const selected = filteredOptionPay.find(option => option.value === item.pay_type);
                    setSelectedPay(selected);
                    setPayType(selected.value)

                    setHeaderRowData([
                        { fieldName: 'Customer Code', billTo: item.customer_code, shipTo: item.shipTo_customer_code },
                        { fieldName: 'Customer Name', billTo: item.billTo_customer_name, shipTo: item.shipTo_customer_name },
                        { fieldName: 'Address 1', billTo: item.billTo_customer_addr_1, shipTo: item.shipTo_customer_addr_1 },
                        { fieldName: 'Address 2', billTo: item.billTo_customer_addr_2, shipTo: item.shipTo_customer_addr_2 },
                        { fieldName: 'Address 3', billTo: item.billTo_customer_addr_3, shipTo: item.shipTo_customer_addr_3 },
                        { fieldName: 'Address 4', billTo: item.billTo_customer_addr_4, shipTo: item.shipTo_customer_addr_4 },
                        { fieldName: 'State', billTo: item.billTo_customer_state, shipTo: item.shipTo_customer_state },
                        { fieldName: 'Country', billTo: item.billTo_customer_country, shipTo: item.shipTo_customer_country },
                        { fieldName: 'Mobile No', billTo: item.billTo_customer_mobile_no, shipTo: item.shipTo_customer_mobile_no },
                        { fieldName: 'GST No', billTo: item.billTo_customer_gst_no, shipTo: item.ShipTo_customer_gst_no },
                        { fieldName: 'Contact Person', billTo: item.billTo_contact_person, shipTo: item.shipTo_contact_person },
                    ]);

                    if (invoicetype === "Tax Invoice") {
                        setNotesRowData([
                            { fieldName: "PO No", notes: item.po_no },
                            { fieldName: "PO Date", notes: formatDate(item.po_date) }, // Display as dd-mm-yyyy
                            { fieldName: "Document Type", notes: item.document_type },
                            { fieldName: "Supplier Ref", notes: item.supplier_ref },
                            { fieldName: "E-Way Bill No", notes: item.Eway_bill_no },
                            { fieldName: "Delivered Through", notes: item.delivered_through },
                        ]);
                    } else {
                        setPINotesRowData([
                            { fieldName: "Delivery Note", PInotes: item.delivery_note },
                            { fieldName: "Dispatched Through", PInotes: item.dispatched_through },
                            { fieldName: "Destination", PInotes: item.Destination },
                        ]);
                    }

                } else {
                    console.log("Header Data is empty or not found");
                    setNew_running_no('');
                    setTotalAmt('');
                    setTotalBill('');
                    setRoundDifference('');
                    setTotalTax('');
                    setbill_date('')
                    setNotesRowData([]);
                }

                if (searchData.Detail && searchData.Detail.length > 0) {
                    const updatedRowData = searchData.Detail.map(item => {
                        const matchingDetails = searchData.TaxDetail.filter(
                            (detailItem) => detailItem.ItemSNo === item.SNo
                        );
                        const taxDetail = matchingDetails.map((detail) => detail.tax_name_details).join(', ');
                        const taxPercentage = matchingDetails.map((detail) => detail.tax_per).join(', ');

                        const taxType = matchingDetails.length > 0 ? matchingDetails[0].tax_type : '';

                        return {
                            serialNumber: item.SNo,
                            productItemCode: item.code,
                            productItemName: item.name,
                            productDescription: item.Description,
                            HSNCode: item.hsn_code,
                            qty: item.bill_qty,
                            unitPrice: item.unit_price,
                            type: item.type,
                            taxAmount: item.tax_amt,
                            totalAmount: item.bill_rate,
                            taxType,
                            taxDetail,
                            taxPercentage,
                            keyField: `${item.SNo}-${item.code || ''}`,
                        };
                    });

                    setRowData(updatedRowData);
                } else {
                    console.log("Detail Data is empty or not found");
                    setRowData([])
                }
                if (searchData.TaxDetail && searchData.TaxDetail.length > 0) {

                    const updatedRowDataTax = searchData.TaxDetail.map(item => {

                        return {
                            ItemSNO: item.ItemSNo,
                            TaxSNO: item.TaxSNo,
                            Item_code: item.item_code,
                            taxDetail: item.tax_name_details,
                            TaxPercentage: item.tax_per,
                            TaxAmount: item.tax_amt,
                            keyfield: `${item.ItemSNo}-${item.item_code || ''}`,
                        };
                    });

                    console.log(updatedRowDataTax);
                    setRowDataTax(updatedRowDataTax);
                }

                if (searchData.Terms && searchData.Terms.length > 0) {
                    const updatedRowData = searchData.Terms.map(item => {

                        return {
                            Terms_conditions: item.Terms_conditions,

                        };
                    });
                    setrowDataTerms(updatedRowData);
                } else {
                    console.log("Tax Data is empty or not found");
                    setRowDataTax([])
                }

                console.log("data fetched successfully")
            } else if (response.status === 404) {
                toast.warning('Data not found');


                setPayType('');
                setNew_running_no('');
                setbill_date('');
                setTotalAmt('');
                setTotalTax('');
                setRoundDifference('');
                setTotalBill('')
                setAdvanceAmount('')
                setBalanceAmount('')
                setRowData([])
                setRowDataTax([])
            } else {
                const errorResponse = await response.json();
                console.error(errorResponse.message);
                toast.error(errorResponse.message);
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }

    };

    const handletaxinvoice = async (data) => {
        if (data && data.length > 0) {
            if (!isChecked) {
                setButtonsVisible(false);
                setShowUpdateButton(true)
                setPrintButtonVisible(true)
                setDelButtonVisible(true)
                setShowExcelButton(true)
            }

            setIsDeleteVisible(true)
            setShowAsterisk(true);
            const [{ adAmount, BillToGSTNo, ShipToGSTNo, balAmount, billtocustomercode, Shiptocustomercode, billno, billtocustomername, salestype, Shiptocustomername, Paytype, Saleamt,
                Taxamt, RoffAmt, Billamt, BillTo_customer_addr_1, BillTo_customer_addr_2, BillTo_customer_addr_3, BillTo_customer_addr_4, ShipTo_customer_addr_1, ShipTo_customer_addr_2,
                ShipTo_customer_addr_3, billdate, ShipTo_customer_addr_4, BillTo_customer_state, ShipTo_customer_state, BillTo_customer_country, ShipTo_customer_country,
                BillTo_customer_mobile_no, ShipTo_customer_mobile_no, BillTo_contact_person, ShipTo_contact_person, po_no, po_date, document_type, delivery_note,
                dispatched_through, Destination, supplier_ref, Eway_bill_no, delivered_through }] = data;


            const AdAmount = document.getElementById('adAmount');
            if (AdAmount) {
                AdAmount.value = adAmount;
                setAdvanceAmount(adAmount);
            } else {
                console.error('Invoice No element not found');
            }

            const BalAmount = document.getElementById('balAmount');
            if (BalAmount) {
                BalAmount.value = balAmount;
                setBalanceAmount(balAmount);
            } else {
                console.error('Invoice No element not found');
            }

            const Billno = document.getElementById('RefNo');
            if (Billno) {
                Billno.value = billno;
                setNew_running_no(billno);
            } else {
                console.error('Invoice No element not found');
            }

            const Billdate = document.getElementById('transactionDate');
            if (Billdate) {
                Billdate.value = billdate;
                setbill_date(formatDate(billdate));
            } else {
                console.error('entry element not found');
            }


            const SalesType = document.getElementById('salesType');
            if (SalesType) {
                const selectedOption = filteredOptionSales.find(option => option.value === salestype);
                setSelectedSales(selectedOption);
                setSalesType(selectedOption.value)
            } else {
                console.error('entry element not found');
            }

            const paytype = document.getElementById('payType');
            if (paytype) {
                const selectedOptionPay = filteredOptionPay.find(option => option.value === Paytype);
                setSelectedPay(selectedOptionPay);
                setPayType(selectedOptionPay.value)
            } else {
                console.error('entry element not found');
            }

            const saleamt = document.getElementById('totalPurchaseAmount');
            if (saleamt) {
                saleamt.value = Saleamt;
                setTotalAmt(formatToTwoDecimalPoints(Saleamt));
            } else {
                console.error('transactionNumber element not found');
            }

            const TaxAmt = document.getElementById('totalTaxAmount');
            if (TaxAmt) {
                TaxAmt.value = Taxamt;
                setTotalTax(formatToTwoDecimalPoints(Taxamt));
            } else {
                console.error('transactionNumber element not found');
            }

            const billamt = document.getElementById('totalBillAmount');
            if (billamt) {
                billamt.value = Billamt;
                setTotalBill(formatToTwoDecimalPoints(Billamt));
            } else {
                console.error('transactionNumber element not found');
            }

            const roff = document.getElementById('roundOff');
            if (roff) {
                roff.value = RoffAmt;
                setRoundDifference(formatToTwoDecimalPoints(RoffAmt));
            } else {
                console.error('transactionNumber element not found');
            }

            console.log(delivered_through)

            if (invoicetype === "Tax Invoice") {
                setNotesRowData([
                    { fieldName: "PO No", notes: po_no },
                    { fieldName: "PO Date", notes: formatDate(po_date) },
                    { fieldName: "Document Type", notes: document_type },
                    { fieldName: "Supplier Ref", notes: supplier_ref },
                    { fieldName: "E-Way Bill No", notes: Eway_bill_no },
                    { fieldName: "Delivered Through", notes: delivered_through },
                ]);
            } else {
                setPINotesRowData([
                    { fieldName: "Delivery Note", PInotes: delivery_note },
                    { fieldName: "Dispatched Through", PInotes: dispatched_through },
                    { fieldName: "Destination", PInotes: Destination },
                ]);
            }

            // await TaxInvocieDetails(billno)
            await TaxInvoiceTax(billno)

            setHeaderRowData([
                { fieldName: 'Customer Code', billTo: billtocustomercode, shipTo: Shiptocustomercode },
                { fieldName: 'Customer Name', billTo: billtocustomername, shipTo: Shiptocustomername },
                { fieldName: 'Address 1', billTo: BillTo_customer_addr_1, shipTo: ShipTo_customer_addr_1 },
                { fieldName: 'Address 2', billTo: BillTo_customer_addr_2, shipTo: ShipTo_customer_addr_2 },
                { fieldName: 'Address 3', billTo: BillTo_customer_addr_3, shipTo: ShipTo_customer_addr_3 },
                { fieldName: 'Address 4', billTo: BillTo_customer_addr_4, shipTo: ShipTo_customer_addr_4 },
                { fieldName: 'State', billTo: BillTo_customer_state, shipTo: ShipTo_customer_state },
                { fieldName: 'Country', billTo: BillTo_customer_country, shipTo: ShipTo_customer_country },
                { fieldName: 'Mobile No', billTo: BillTo_customer_mobile_no, shipTo: ShipTo_customer_mobile_no },
                { fieldName: 'GST No', billTo: BillToGSTNo, shipTo: ShipToGSTNo },
                { fieldName: 'Contact Person', billTo: BillTo_contact_person, shipTo: ShipTo_contact_person },
            ]);

        } else {
            console.log("Data not fetched...!");
        }
        console.log(data);
    };

    const TaxInvoiceTax = async (billno) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getTaxInvoiceTax`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    transaction_no: billno,
                    invoice_type: isChecked ? "Proforma Invoice" : invoicetype,
                    company_code: sessionStorage.getItem("selectedCompanyCode"),
                }),
            });

            if (response.ok) {
                const searchData = await response.json();
                const newRowData = [];
                const taxDataMap = {};

                searchData.forEach(({ ItemSNo, TaxSNo, item_code, tax_type, tax_per, tax_amt, tax_name_details }) => {
                    newRowData.push({
                        ItemSNO: ItemSNo,
                        TaxSNO: TaxSNo,
                        Item_code: item_code,
                        taxDetail: tax_name_details,
                        TaxPercentage: tax_per,
                        TaxAmount: tax_amt,
                        taxType: tax_type,
                        keyfield: `${ItemSNo}-${item_code || ''}`,
                    });

                    if (!taxDataMap[ItemSNo]) {
                        taxDataMap[ItemSNo] = {
                            tax_type: tax_type,
                            tax_names: [],
                            tax_percents: [],
                        };
                    }

                    taxDataMap[ItemSNo].tax_names.push(tax_name_details);
                    taxDataMap[ItemSNo].tax_percents.push(tax_per);
                });


                TaxInvocieDetails(billno, taxDataMap);

                setRowDataTax(newRowData);

                console.log("Data fetched and processed successfully", newRowData);
            } else if (response.status === 404) {
                console.log("Data not found");
                setRowDataTax([]);
            } else {
                console.log("Bad request");
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        }
    };

    const TaxInvocieDetails = async (billno, taxDataMap) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/gettaxinvoiceDetail`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ transaction_no: billno, invoice_type: isChecked ? "Proforma Invoice" : invoicetype, company_code: sessionStorage.getItem("selectedCompanyCode") })
            });

            if (response.ok) {
                const searchData = await response.json();
                console.log(searchData)

                const newRowData = [];
                searchData.forEach(item => {
                    const {
                        SNo,
                        code,
                        Description,
                        bill_qty,
                        bill_rate,
                        unit_price,
                        tax_amt,
                        type,
                        hsn_code,
                        name
                    } = item;

                    const taxInfo = taxDataMap[SNo] || {
                        tax_type: '',
                        tax_names: [],
                        tax_percents: [],
                    };

                    newRowData.push({
                        serialNumber: SNo,
                        productItemCode: code,
                        productItemName: name,
                        productDescription: Description,
                        HSNCode: hsn_code,
                        qty: bill_qty,
                        unitPrice: unit_price,
                        type: type,
                        taxAmount: tax_amt,
                        totalAmount: bill_rate,
                        taxType: taxInfo.tax_type,
                        taxPercentage: taxInfo.tax_percents.join(", "),
                        taxDetail: taxInfo.tax_names.join(", "),
                        keyField: `${SNo}-${code || ''}`,
                    });
                });
                await TermsTITerms(billno);
                setRowData(newRowData);
            } else if (response.status === 404) {
                console.log("Data not found");
                setRowData([]);
            } else {
                console.log("Bad request");
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }

    };

    const TermsTITerms = async (billno) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getTITerms`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ transaction_no: billno, invoice_type: isChecked ? "Proforma Invoice" : invoicetype, company_code: sessionStorage.getItem("selectedCompanyCode") })
            });

            if (response.ok) {
                const searchData = await response.json();
                console.log(searchData)

                const newRowData = [];
                searchData.forEach(item => {
                    const {

                        Terms_conditions

                    } = item;

                    newRowData.push({
                        Terms_conditions: Terms_conditions,

                    });

                });

                setrowDataTerms(newRowData);

            } else if (response.status === 404) {
                console.log("Data not found");
                setrowDataTerms([]);
            } else {
                console.log("Bad request");
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }

    };


    const handleDeleteHeader = async () => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/TaxInvoicehdrDelteData`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    bill_no: new_running_no,
                    invoice_type: invoicetype,
                    company_code: sessionStorage.getItem("selectedCompanyCode"),
                    Location_Code,
                    modified_by: sessionStorage.getItem("selectedUserCode")
                })
            });
            if (response.ok) {
                console.log("Rows deleted successfully:", new_running_no);
                return true
            } else {
                const errorResponse = await response.json();
                return errorResponse.details || errorResponse.message || "Failed to delete header.";
            }
        } catch (error) {
            return "Error deleting header: " + error.message;
        }
    };
    const handleDeleteDetail = async () => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/TaxInvoiceDelteData`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ bill_no: new_running_no, Location_Code, invoice_type: invoicetype, company_code: sessionStorage.getItem("selectedCompanyCode") })
            });
            if (response.ok) {
                console.log("Rows deleted successfully:", new_running_no);
                return true
            } else {
                const errorResponse = await response.json();
                return errorResponse.details || errorResponse.message || "Failed to delete detail.";
            }
        } catch (error) {
            return "Error deleting detail: " + error.message;
        }
    };

    const handleDeleteTaxDetail = async () => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/TaxInvoicetaxDelteData`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ bill_no: new_running_no, Location_Code, invoice_type: invoicetype, company_code: sessionStorage.getItem("selectedCompanyCode") })
            });
            if (response.ok) {
                console.log("Rows deleted successfully:", new_running_no);
                return true
            } else {
                const errorResponse = await response.json();
                return errorResponse.details || errorResponse.message || "Failed to delete tax detail.";
            }
        } catch (error) {
            return "Error deleting tax detail: " + error.message;
        }
    };

    const handleDeleteTerms = async () => {
        try {
            const response = await fetch(`${config.apiBaseUrl}/TITermsandConditionsDelete`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ bill_no: new_running_no.toString(), Location_Code, invoice_type: invoicetype, company_code: sessionStorage.getItem("selectedCompanyCode") })
            });
            if (response.ok) {
                console.log("Rows deleted successfully:", new_running_no);
                return true
            } else {
                const errorResponse = await response.json();
                return errorResponse.details || errorResponse.message || "Failed to delete terms and conditions.";
            }
        } catch (error) {
            return "Error deleting terms and conditions: " + error.message;
        }
    };

    const handleDeleteButtonClick = async () => {
        if (!new_running_no) {
            setDeleteError(" ");
            toast.warning('Error: Missing required fields');
            return;
        }

        showConfirmationToast(
            "Are you sure you want to delete the data ?",
            async () => {
                setLoading(true)
                try {
                    const taxDetailResult = await handleDeleteTaxDetail();
                    const detailResult = await handleDeleteDetail();
                    const TermsResult = await handleDeleteTerms();
                    const headerResult = await handleDeleteHeader();

                    if (headerResult === true && detailResult === true && taxDetailResult === true && TermsResult === true) {
                        console.log("All API calls completed successfully");
                        toast.success("Data Deleted Successfully", {
                            autoClose: true,
                            onClose: () => {
                                window.location.reload();
                            }
                        });
                    } else {
                        const errorMessage =
                            headerResult !== true
                                ? headerResult
                                : detailResult !== true
                                    ? detailResult
                                    : taxDetailResult !== true
                                        ? taxDetailResult
                                        : TermsResult !== true
                                            ? TermsResult
                                            : "An unknown error occurred.";

                        toast.error(errorMessage);
                    }
                } catch (error) {
                    console.error("Error executing API calls:", error);
                    toast.warning(error.message || "An Error occured while Deleting Data");
                } finally {
                    setLoading(false);
                }

            },
            () => {
                toast.info("Data deleted cancelled.");
            }
        );
    };

    const handleReload = () => {
        setLoading(true)
        window.location.reload();
    };

    useEffect(() => {
        const today = new Date();
        const currentYear = today.getFullYear();
        const currentMonth = today.getMonth() + 1;

        let startYear, endYear;
        if (currentMonth >= 4) {
            startYear = currentYear;
            endYear = currentYear + 1;
        } else {
            startYear = currentYear - 1;
            endYear = currentYear;
        }

        const financialYearStartDate = new Date(startYear, 3, 1).toISOString().split('T')[0]; // April 1
        const financialYearEndDate = new Date(endYear, 2, 31).toISOString().split('T')[0]; // March 31

        setFinancialYearStart(financialYearStartDate);
        setFinancialYearEnd(financialYearEndDate);
    }, []);


    const handleExcelDownload = () => {
        // Prepare Header Data
        const headerData = [
            {
                'Bill Date': bill_date,
                'Bill No': new_running_no,
                'Company Code': sessionStorage.getItem('selectedCompanyCode'),
                'BillTo Customer Code': headerRowData[0].billTo,
                'BillTo Customer Name': headerRowData[1].billTo,
                'BillTo Customer Addr 1': headerRowData[2].billTo,
                'BillTo Customer Addr 2': headerRowData[3].billTo,
                'BillTo Customer Addr 3': headerRowData[4].billTo,
                'BillTo Customer Addr 4': headerRowData[5].billTo,
                'BillTo Customer State': headerRowData[6].billTo,
                'BillTo Customer Country': headerRowData[7].billTo,
                'BillTo Customer Mobile No': headerRowData[8].billTo,
                'BillTo Customer GST No': headerRowData[9].billTo,
                'BillTo Contact Person': headerRowData[10].billTo,

                'ShipTo Customer Code': headerRowData[0].shipTo,
                'ShipTo Customer Name': headerRowData[1].shipTo,
                'ShipTo Customer Addr 1': headerRowData[2].shipTo,
                'ShipTo Customer Addr 2': headerRowData[3].shipTo,
                'ShipTo Customer Addr 3': headerRowData[4].shipTo,
                'ShipTo Customer Addr 4': headerRowData[5].shipTo,
                'ShipTo Customer State': headerRowData[6].shipTo,
                'ShipTo Customer Country': headerRowData[7].shipTo,
                'ShipTo Customer Mobile No': headerRowData[8].shipTo,
                'ShipTo Customer GST No': headerRowData[9].shipTo,
                'ShipTo Contact Person': headerRowData[10].shipTo,
                'Tax Amount': TotalTax,
                'Rounded Off': round_difference,
                'Total Amount': TotalBill,
            }
        ];

        const itemData = rowData.filter(row =>
            row.productItemCode && row.productItemName && row.qty > 0
        ).map(row => ({
            'Bill Date': bill_date,
            'Bill No': new_running_no,
            'Customer Name': headerRowData[0].billTo,
            'S.No': row.serialNumber,
            'Product / Item Code': row.productItemCode,
            'Product / Item Name': row.productItemName,
            'Product Description': row.productDescription,
            'HSN Code': row.HSNCode,
            'Qty': row.qty,
            'unitPrice': row.unitPrice,
            'Total': row.totalAmount,
        }));

        const taxDetailsData = rowDataTax.map(taxRow => {
            const matchedItem = rowData.find(row => Number(row.serialNumber) === Number(taxRow.ItemSNO));

            return {
                'Transaction No': new_running_no.toString(),
                'Entry Date': bill_date,
                'Item SNo': taxRow.ItemSNO,
                'Tax SNo': taxRow.TaxSNO,
                'Item Code': matchedItem ? matchedItem.productItemCode : '',
                'Item Name': matchedItem ? matchedItem.productItemName : '',
                'Tax Type': taxRow.taxDetail,
                'Tax Amount': taxRow.TaxAmount,
                'Tax Percentage': taxRow.TaxPercentage,
            };
        });

        const headerWorksheet = XLSX.utils.json_to_sheet(headerData);

        const itemWorksheet = XLSX.utils.json_to_sheet(itemData);

        const taxDetailsWorksheet = XLSX.utils.json_to_sheet(taxDetailsData);

        const workbook = XLSX.utils.book_new();

        XLSX.utils.book_append_sheet(workbook, headerWorksheet, "Header Data");
        XLSX.utils.book_append_sheet(workbook, itemWorksheet, "Details Data");
        XLSX.utils.book_append_sheet(workbook, taxDetailsWorksheet, "Tax Details");

        XLSX.writeFile(workbook, 'Invoice.xlsx');
    };

    //Deleted Screen
    const [deletedRowData, setDeletedRowData] = useState([]);
    const [deletedRowDataTerms, setDeletedRowDataTerms] = useState([]);
    const [deletedRowDataTax, setDeletedRowDataTax] = useState([]);
    const [TransactionNo, setTransactionNo] = useState("");
    const [TransactionDate, setTransactionDate] = useState("");
    const [PayType, setPaytype] = useState("");
    const [SalesType, setSalestype] = useState("");
    const [Total, setTotal] = useState("");
    const [Tax, setTax] = useState("");
    const [RoundOff, setRoundOff] = useState("");
    const [GrandTotal, setGrandTotal] = useState("");

    const deletedColumnDetail = [
        {
            headerName: 'S.No',
            field: 'deletedSerialNumber',
            maxWidth: 80,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Product / Item Code',
            field: 'deletedProductItemCode',
            editable: false,
            filter: true,
            sortable: false
        },
        {
            headerName: 'Product / Item Name',
            field: 'deletedProductItemName',
            editable: true,
            filter: true,
            sortable: false
        },
        {
            headerName: 'Product Description',
            field: 'deletedProductDescription',
            editable: true,
            filter: true,
            sortable: false,
            wrapText: true,
            // minWidth: 400,
            // maxWidth: 400,
            autoHeight: true,
            wrapHeaderText: true,
            autoHeaderHeight: true,
        },
        {
            headerName: 'HSN Code',
            field: 'deletedHSNCode',
            editable: false,
            filter: true
        },
        {
            headerName: 'Qty',
            field: 'deletedQty',
            editable: true,
            filter: true,
            sortable: false,
            valueSetter: qtyValueSetter,
        },
        {
            headerName: 'Unit Price',
            field: 'deletedUnitPrice',
            editable: true,
            filter: true,
            sortable: false
        },
        {
            headerName: 'Type',
            field: 'deletedType',
            editable: false,
            filter: true,
            hide: true
        },
        {
            headerName: 'Tax Amount',
            field: 'deletedTaxAmount',
            editable: false,
            hide: false
        },
        {
            headerName: 'Total',
            field: 'deletedTotalAmount',
            editable: false,
            filter: true,
            sortable: false,
        }
    ];

    const deletedColumnTax = [
        {
            headerName: 'S.No',
            field: 'deletedItemSNO',
            maxWidth: 250,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Tax S.No',
            field: 'deletedTaxSNO',
            maxWidth: 120,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Product / Item Code',
            field: 'deletedItem_code',
            // minWidth: 315,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Tax Type',
            field: 'deletedTaxDetail',
            // minWidth: 201,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Tax %',
            field: 'deletedTaxPercentage',
            // minWidth: 201,
            sortable: false,
            editable: false
        },
        {
            headerName: 'Tax Amount',
            field: 'deletedTaxAmount',
            // minWidth: 301,
            sortable: false,
            editable: false
        },
    ];
    const deletedColumnTerms = [
        {
            headerName: 'S.No',
            field: 'deletedSerialNumber',
            maxWidth: 70,
            valueGetter: (params) => params.node.rowIndex + 1,
            sortable: false,
            minHeight: 50,
            maxHeight: 50,
            editable: false,
        },
        {
            headerName: 'Terms & Conditions',
            field: 'deletedTermsConditions',
            // minWidth: 1000,
            // maxWidth: 1000,
            minHeight: 50,
            maxHeight: 50,
            sortable: false,
            editable: false,
        },
    ];


    const deletedColumnHeader = [
        {
            headerName: 'Field',
            field: 'fieldName',
            // maxWidth: 240, 
            editable: false
        },
        {
            headerName: 'Bill To',
            field: 'deletedBillTo',
            editable: false
        },
        {
            headerName: 'Ship To',
            field: 'deletedShipTo',
            editable: false
        }
    ];

    const columnDeletedNotes = [
        { headerName: 'Field', field: 'fieldName', editable: false },
        {
            headerName: "Notes",
            field: "deletedNotes",
            editable: true,
        },
    ];

    const columnDeletedPINotes = [
        { headerName: 'Field', field: 'fieldName', editable: false },
        {
            headerName: "Notes",
            field: "deletedPInotes",
            editable: true,
        },
    ];

    const [deletedNotesRowData, setDeletedNotesRowData] = useState([
        { fieldName: 'PO No', deletedNotes: '', },
        { fieldName: 'PO Date', deletedNotes: '', },
        { fieldName: 'Document Type', deletedNotes: '', },
        { fieldName: 'Supplier Ref', notes: '', },
        { fieldName: 'E-Way Bill No', notes: '', },
        { fieldName: 'Delivered Through', notes: '', },
    ]);

    const [deletedPINotesRowData, setDeletedPINotesRowData] = useState([
        { fieldName: 'Delivery Note', deletedPInotes: '', },
        { fieldName: 'Dispatched Through', deletedPInotes: '', },
        { fieldName: 'Destination', deletedPInotes: '', },
    ]);

    const [deletedHeaderRowData, setDeletedHeaderRowData] = useState([
        { fieldName: 'Customer Code', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'Customer Name', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'Address 1', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'Address 2', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'Address 3', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'Address 4', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'State', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'Country', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'Mobile No', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'GST No', deletedBillTo: '', deletedShipTo: '' },
        { fieldName: 'Contact Person', deletedBillTo: '', deletedShipTo: '' },
    ]);

    const handleDeleteKeyPress = (e) => {
        if (e.key === 'Enter') {
            handleDeletedTransaction(TransactionNo)
        }
    };

    const handleDeletedTransaction = async (code) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getDeletedTaxInvoice`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ transaction_no: code, company_code: sessionStorage.getItem('selectedCompanyCode'), tempstr1: invoicetype })
            });
            if (response.ok) {
                const searchData = await response.json();
                if (searchData.Header && searchData.Header.length > 0) {
                    const item = searchData.Header[0];
                    setTransactionNo(item.bill_no)
                    setTax(item.tax_amount)
                    setGrandTotal(item.bill_amt)
                    setRoundOff(item.roff_amt)
                    setTotal(item.sale_amt)
                    setPaytype(item.pay_type)
                    setSalestype(item.sales_type)
                    setTransactionDate(formatDate(item.bill_date))

                    setDeletedNotesRowData([
                        { fieldName: "PO No", deletedNotes: item.po_no },
                        { fieldName: "PO Date", deletedNotes: formatDate(item.po_date) },
                        { fieldName: "Document Type", deletedNotes: item.document_type },
                        { fieldName: "Supplier Ref", deletedNotes: item.document_type },
                        { fieldName: "E-Way Bill No", deletedNotes: item.document_type },
                        { fieldName: "Delivered Through", deletedNotes: item.delivered_through },
                    ]);

                    setDeletedPINotesRowData([
                        { fieldName: "Delivery Note", deletedPInotes: item.delivery_note },
                        { fieldName: "Dispatched Through", deletedPInotes: item.dispatched_through },
                        { fieldName: "Destination", deletedPInotes: item.Destination },
                    ]);

                    setDeletedHeaderRowData([
                        { fieldName: 'Customer Code', deletedBillTo: item.customer_code, deletedShipTo: item.shipTo_customer_code },
                        { fieldName: 'Customer Name', deletedBillTo: item.billTo_customer_name, deletedShipTo: item.shipTo_customer_name },
                        { fieldName: 'Address 1', deletedBillTo: item.billTo_customer_addr_1, deletedShipTo: item.shipTo_customer_addr_1 },
                        { fieldName: 'Address 2', deletedBillTo: item.billTo_customer_addr_2, deletedShipTo: item.shipTo_customer_addr_2 },
                        { fieldName: 'Address 3', deletedBillTo: item.billTo_customer_addr_3, deletedShipTo: item.shipTo_customer_addr_3 },
                        { fieldName: 'Address 4', deletedBillTo: item.billTo_customer_addr_4, deletedShipTo: item.shipTo_customer_addr_4 },
                        { fieldName: 'State', deletedBillTo: item.billTo_customer_state, deletedShipTo: item.shipTo_customer_state },
                        { fieldName: 'Country', deletedBillTo: item.billTo_customer_country, deletedShipTo: item.shipTo_customer_country },
                        { fieldName: 'Mobile No', deletedBillTo: item.billTo_customer_mobile_no, deletedShipTo: item.shipTo_customer_mobile_no },
                        { fieldName: 'GST No', deletedBillTo: item.billTo_customer_gst_no, deletedShipTo: item.ShipTo_customer_gst_no },
                        { fieldName: 'Contact Person', deletedBillTo: item.billTo_contact_person, deletedShipTo: item.shipTo_contact_person },
                    ]);

                } else {
                    console.log("Header Data is empty or not found");
                    setPaytype('');
                    setTransactionNo('');
                    setTransactionDate('');
                    setTax('');
                    setTotal('');
                    setRoundOff('');
                    setGrandTotal('');
                    setDeletedHeaderRowData([]);
                }

                if (searchData.Detail && searchData.Detail.length > 0) {
                    const updatedRowData = searchData.Detail.map(item => {
                        const matchingDetails = searchData.TaxDetail.filter(
                            (detailItem) => detailItem.ItemSNo === item.SNo
                        );
                        const taxDetail = matchingDetails.map((detail) => detail.tax_name_details).join(', ');
                        const taxPercentage = matchingDetails.map((detail) => detail.tax_per).join(', ');

                        const taxType = matchingDetails.length > 0 ? matchingDetails[0].tax_type : '';

                        return {
                            deletedSerialNumber: item.SNo,
                            deletedProductItemCode: item.code,
                            deletedProductItemName: item.name,
                            deletedProductDescription: item.Description,
                            deletedHSNCode: item.hsn_code,
                            deletedQty: item.bill_qty,
                            deletedUnitPrice: item.unit_price,
                            deletedType: item.type,
                            deletedTaxAmount: item.tax_amt,
                            deletedTotalAmount: item.bill_rate,
                        };
                    });

                    setDeletedRowData(updatedRowData);
                } else {
                    console.log("Detail Data is empty or not found");
                    setDeletedRowData([])
                }

                if (searchData.TaxDetail && searchData.TaxDetail.length > 0) {

                    const updatedRowDataTax = searchData.TaxDetail.map(item => {

                        return {
                            deletedItemSNO: item.ItemSNo,
                            deletedTaxSNO: item.TaxSNo,
                            deletedItem_code: item.item_code,
                            deletedTaxDetail: item.tax_name_details,
                            deletedTaxPercentage: item.tax_per,
                            deletedTaxAmount: parseFloat(item.tax_amt).toFixed(2)
                        };
                    });

                    console.log(updatedRowDataTax);
                    setDeletedRowDataTax(updatedRowDataTax);
                } else {
                    console.log("Tax Data is empty or not found");
                    setDeletedRowDataTax([])
                }

                if (searchData.Terms && searchData.Terms.length > 0) {
                    const updatedRowData = searchData.Terms.map(item => {
                        return {
                            deletedTermsConditions: item.Terms_conditions,
                        };
                    });
                    setDeletedRowDataTerms(updatedRowData);
                } else {
                    console.log("Tax Data is empty or not found");
                    setDeletedRowDataTerms([])
                }

                console.log("data fetched successfully")
            } else if (response.status === 404) {
                toast.warning('Data not found');
                setPaytype('');
                setTransactionNo('');
                setTransactionDate('');
                setTax('');
                setTotal('');
                setRoundOff('');
                setGrandTotal('')
                setDeletedRowData([])
                setDeletedRowDataTax([])
                setDeletedRowDataTerms([])
                setDeletedHeaderRowData([])
            } else {
                const errorResponse = await response.json();
                console.error(errorResponse.message);
                toast.error(errorResponse.message);
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }
    };

    const [open3, setOpen3] = React.useState(false);

    const handleDeletedTaxInvoice = () => {
        setOpen3(true);
    };

    const handleDeletedTaxInvoiceData = async (data) => {
        if (data && data.length > 0) {
            const [{ adAmount, balAmount, BillToGSTNo, ShipToGSTNo, billtocustomercode, Shiptocustomercode, billno, billtocustomername, salestype, Shiptocustomername, Paytype, Saleamt, Taxamt, RoffAmt, Billamt, BillTo_customer_addr_1,
                BillTo_customer_addr_2, BillTo_customer_addr_3, BillTo_customer_addr_4, ShipTo_customer_addr_1, ShipTo_customer_addr_2, ShipTo_customer_addr_3, billdate, ShipTo_customer_addr_4, BillTo_customer_state,
                ShipTo_customer_state, BillTo_customer_country, ShipTo_customer_country, BillTo_customer_mobile_no, ShipTo_customer_mobile_no, BillTo_contact_person, ShipTo_contact_person,
                po_no, po_date, document_type, delivery_note, dispatched_through, Destination, delivered_through,
            supplier_ref, Eway_bill_no }] = data;

            // const AdAmount = document.getElementById('adAmount');
            // if (AdAmount) {
            //     AdAmount.value = adAmount;
            //     setAdvanceAmount(adAmount);
            // } else {
            //     console.error('Invoice No element not found');
            // }

            // const BalAmount = document.getElementById('balAmount');
            // if (BalAmount) {
            //     BalAmount.value = balAmount;
            //     setBalanceAmount(balAmount);
            // } else {
            //     console.error('Invoice No element not found');
            // }

            const transactionno = document.getElementById('TransactionNo');
            if (transactionno) {
                transactionno.value = billno;
                setTransactionNo(billno);
            } else {
                console.error('Invoice No element not found');
            }

            const transactiondate = document.getElementById('TransactionDate');
            if (transactiondate) {
                transactiondate.value = billdate;
                setTransactionDate(formatDate(billdate));
            } else {
                console.error('entry element not found');
            }

            const SalesType = document.getElementById('SalesType');
            if (SalesType) {
                SalesType.value = salestype;
                setSalestype(salestype);
            } else {
                console.error('salestype element not found');
            }

            const paytype = document.getElementById('PayType');
            if (paytype) {
                paytype.value = Paytype;
                setPaytype(Paytype);
            } else {
                console.error('Paytype element not found');
            }

            const total = document.getElementById('Total');
            if (total) {
                total.value = Saleamt;
                setTotal(formatToTwoDecimalPoints(Saleamt));
            } else {
                console.error('Saleamt element not found');
            }

            const TaxAmt = document.getElementById('Tax');
            if (TaxAmt) {
                TaxAmt.value = Taxamt;
                setTax(formatToTwoDecimalPoints(Taxamt));
            } else {
                console.error('Taxamt element not found');
            }

            const grandTotal = document.getElementById('GrandTotal');
            if (grandTotal) {
                grandTotal.value = Billamt;
                setGrandTotal(formatToTwoDecimalPoints(Billamt));
            } else {
                console.error('GrandTotal element not found');
            }

            const roff = document.getElementById('RoundOff');
            if (roff) {
                roff.value = RoffAmt;
                setRoundOff(formatToTwoDecimalPoints(RoffAmt));
            } else {
                console.error('RoffAmt element not found');
            }

            setDeletedNotesRowData([
                { fieldName: "PO No", deletedNotes: po_no },
                { fieldName: "PO Date", deletedNotes: formatDate(po_date) },
                { fieldName: "Document Type", deletedNotes: document_type },
                { fieldName: "Supplier Ref", deletedNotes: supplier_ref },
                { fieldName: "E-Way Bill No", deletedNotes: Eway_bill_no },
                { fieldName: "Delivered Through", deletedNotes: delivered_through },
            ]);

            setDeletedPINotesRowData([
                { fieldName: "Delivery Note", deletedPInotes: delivery_note },
                { fieldName: "Dispatched Through", deletedPInotes: dispatched_through },
                { fieldName: "Destination", deletedPInotes: Destination },
            ]);

            await DeletedTaxInvoiceTax(billno)

            setDeletedHeaderRowData([
                { fieldName: 'Customer Code', deletedBillTo: billtocustomercode, deletedShipTo: Shiptocustomercode },
                { fieldName: 'Customer Name', deletedBillTo: billtocustomername, deletedShipTo: Shiptocustomername },
                { fieldName: 'Address 1', deletedBillTo: BillTo_customer_addr_1, deletedShipTo: ShipTo_customer_addr_1 },
                { fieldName: 'Address 2', deletedBillTo: BillTo_customer_addr_2, deletedShipTo: ShipTo_customer_addr_2 },
                { fieldName: 'Address 3', deletedBillTo: BillTo_customer_addr_3, deletedShipTo: ShipTo_customer_addr_3 },
                { fieldName: 'Address 4', deletedBillTo: BillTo_customer_addr_4, deletedShipTo: ShipTo_customer_addr_4 },
                { fieldName: 'State', deletedBillTo: BillTo_customer_state, deletedShipTo: ShipTo_customer_state },
                { fieldName: 'Country', deletedBillTo: BillTo_customer_country, deletedShipTo: ShipTo_customer_country },
                { fieldName: 'Mobile No', deletedBillTo: BillTo_customer_mobile_no, deletedShipTo: ShipTo_customer_mobile_no },
                { fieldName: 'GST No', deletedBillTo: BillToGSTNo, deletedShipTo: ShipToGSTNo },
                { fieldName: 'Contact Person', deletedBillTo: BillTo_contact_person, deletedShipTo: ShipTo_contact_person },
            ]);

        } else {
            console.log("Data not fetched...!");
        }
        console.log(data);
    };

    const DeletedTaxInvoiceTax = async (billno) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getDeletedTaxInvoiceTax`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ transaction_no: billno, company_code: sessionStorage.getItem('selectedCompanyCode'), invoice_type: invoicetype }),
            });

            if (response.ok) {
                const searchData = await response.json();
                const newRowData = [];
                const uniqueTaxDetails = new Set();

                searchData.forEach(({ ItemSNo, TaxSNo, item_code, tax_per, tax_amt, tax_name_details }) => {
                    newRowData.push({
                        deletedItemSNO: ItemSNo,
                        deletedTaxSNO: TaxSNo,
                        deletedItem_code: item_code,
                        deletedTaxDetail: tax_name_details,
                        deletedTaxPercentage: tax_per,
                        deletedTaxAmount: tax_amt,
                    });

                    uniqueTaxDetails.add(`${tax_name_details}:${tax_per}`);
                });

                DeletedTaxInvocieDetails(billno);

                setDeletedRowDataTax(newRowData);

            } else if (response.status === 404) {
                console.log("Data not found");
                setDeletedRowDataTax([]);
            } else {
                const errorResponse = await response.json();
                console.error(errorResponse.message);
                toast.error(errorResponse.message);
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }

    };

    const DeletedTaxInvocieDetails = async (billno) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getDeletedTaxinvoiceDetail`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ transaction_no: billno, company_code: sessionStorage.getItem('selectedCompanyCode'), invoice_type: invoicetype })
            });

            if (response.ok) {
                const searchData = await response.json();
                console.log(searchData)

                const newRowData = [];
                searchData.forEach(item => {
                    const {
                        SNo,
                        code,
                        Description,
                        bill_qty,
                        bill_rate,
                        unit_price,
                        tax_amt,
                        type,
                        hsn_code,
                        name
                    } = item;

                    newRowData.push({
                        deletedSerialNumber: SNo,
                        deletedProductItemCode: code,
                        deletedProductItemName: name,
                        deletedProductDescription: Description,
                        deletedHSNCode: hsn_code,
                        deletedQty: bill_qty,
                        deletedUnitPrice: unit_price,
                        deletedType: type,
                        deletedTaxAmount: tax_amt,
                        deletedTotalAmount: bill_rate
                    });
                });
                await DeletedTaxInvoiceTerms(billno);
                setDeletedRowData(newRowData);
            } else if (response.status === 404) {
                console.log("Data not found");
                setDeletedRowData([]);
            } else {
                const errorResponse = await response.json();
                console.error(errorResponse.message);
                toast.error(errorResponse.message);
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }

    };

    const DeletedTaxInvoiceTerms = async (billno) => {
        setLoading(true)
        try {
            const response = await fetch(`${config.apiBaseUrl}/getDeletedTaxIvoiceTerms`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ transaction_no: billno, invoice_type: invoicetype, company_code: sessionStorage.getItem("selectedCompanyCode") })
            });

            if (response.ok) {
                const searchData = await response.json();
                console.log(searchData)

                const newRowData = [];
                searchData.forEach(item => {
                    const { Terms_conditions } = item;

                    newRowData.push({
                        deletedTermsConditions: Terms_conditions,
                    });
                });

                setDeletedRowDataTerms(newRowData);

            } else if (response.status === 404) {
                console.log("Data not found");
                setDeletedRowDataTerms([]);
            } else {
                const errorResponse = await response.json();
                console.error(errorResponse.message);
                toast.error(errorResponse.message);
            }
        } catch (error) {
            console.error("Error fetching search data:", error);
        } finally {
            setLoading(false);
        }

    };

    //Default Date functionality
    const currentDate = new Date().toISOString().split('T')[0];

    useEffect(() => {
        setbill_date(currentDate);
    }, [currentDate]);

    const handleDateChange = (e) => {
        const selectedDate = e.target.value;

        if (selectedDate >= financialYearStart && selectedDate <= financialYearEnd) {
            if (selectedDate !== currentDate) {
                console.log("Date has been changed.");
            }
            setbill_date(selectedDate);
        } else {
            toast.warning('Transaction date must be between April 1st, 2024 and March 31st, 2025.');
        }
    };

    const navigateToSalesSettings = () => {
        if (Type) {
            const formattedType = Type.replace(/\s/g, '');
            navigate('/InvoiceSettings', { state: { type: formattedType } });
        } else {
            toast.warning("Type is not selected");
        }
    };

    useEffect(() => {
        fetch(`${config.apiBaseUrl}/getDefaultoptions`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                company_code: sessionStorage.getItem("selectedCompanyCode"),
                Screen_Type: Type.replace(/\s/g, '')

            }),
        })
            .then((response) => response.json())
            .then((data) => {
                if (!data || data.length === 0) return;

                const { pay_type, Transaction_type, Print_templates, Print_options, Print_copies } = data[0];

                const setDefault = (type, setType, options, setSelected) => {
                    if (type) {
                        setType(type);
                        setSelected(options.find((opt) => opt.value === type) || null);
                    }
                };

                setDefault(pay_type, setPayType, filteredOptionPay, setSelectedPay);
                setDefault(Transaction_type, setSalesType, filteredOptionSales, setSelectedSales);

                if (Print_templates) setTemplateName(Print_templates);
                if (Print_options) setPrintOption(Print_options);
                if (Print_copies) setPrintCopies(Print_copies);
            })
            .catch((error) => console.error("Error fetching data:", error));
    }, [paydrop, salesdrop, Type]);

    const handleCheckboxChange = (e) => {
        setIsChecked(e.target.checked);
    };

    const handleKeyPress = (e) => {
        if (e.key === "Enter") {
            if (round_difference !== "0") {
                toast.warning("Only '0' is allowed in this field!");
                setRoundDifference("");
                return;
            }
            // Total calculation and update TotalBill
            const grandTotal = parseFloat(totalamt) + parseFloat(TotalTax);
            setTotalBill(grandTotal.toFixed(2));
        }
    };

    return (
        <div className="">
            {Screens === 'Add' ? (
                <div className="container-fluid Topnav-screen">
                    <div>
                        {loading && <LoadingScreen />}
                        <ToastContainer position="top-right" className="toast-design" theme="colored" />
                        <div className="shadow-lg p-1 bg-body-tertiary rounded  mb-2 mt-2">
                            <div class="d-flex justify-content-between">
                                <div className="d-flex justify-content-start">
                                    <h1 align="left" className="purbut me-5"> Invoice</h1>
                                </div>
                                <div className="d-flex justify-content-end purbut me-3">
                                    <div class="exp-form-floating">
                                        <Select
                                            id="returnType"
                                            className="exp-input-field col-md-6 mt-2"
                                            placeholder=""
                                            required
                                            value={selectedPendingStatus}
                                            onChange={handleChangeStatus}
                                            options={filteredOptionStatus}
                                            data-tip="Please select a default warehouse"
                                        />
                                    </div>
                                    <div class="exp-form-floating">
                                        <Select
                                            id="returnType"
                                            className="exp-input-field col-md-6 mt-2"
                                            placeholder=""
                                            required
                                            value={selectedscreens}
                                            onChange={handleChangeScreens}
                                            options={filteredOptionScreens}
                                            data-tip="Please select a default warehouse"
                                        />
                                    </div>
                                    <div class="exp-form-floating mt-2 me-4">
                                        <Select
                                            id="InvoiceType"
                                            className="exp-input-field"
                                            placeholder="Select a Invoice Type  "
                                            options={filteredOptionInvoice}
                                            value={selectedInvoice}
                                            onChange={handleChangeInvoice}
                                        />
                                    </div>
                                    {buttonsVisible && ['add', 'all permission'].some(permission => purchasePermission.includes(permission)) && (
                                        <savebutton className="purbut" onClick={handleSaveButtonClick} title='save' >
                                            <i class="fa-regular fa-floppy-disk"></i>
                                        </savebutton>
                                    )}
                                    {showUpdateButton && ['update', 'all permission'].some(permission => purchasePermission.includes(permission)) && (
                                        <savebutton className="purbut" onClick={handleUpdateButtonClick} title='Update' >
                                            <i class="fa-solid fa-floppy-disk"></i>
                                        </savebutton>
                                    )}
                                    {delButtonVisible && ['delete', 'all permission'].some(permission => purchasePermission.includes(permission)) && (
                                        <delbutton className="purbut" onClick={handleDeleteButtonClick} title='delete' >
                                            <i class="fa-solid fa-trash"></i>
                                        </delbutton>
                                    )}
                                    {printButtonVisible && ['all permission', 'view'].some(permission => purchasePermission.includes(permission)) && (
                                        <printbutton className="purbut" title="print" onClick={generateReport} >
                                            <i class="fa-solid fa-file-pdf"></i>
                                        </printbutton>
                                    )}
                                    <printbutton className="purbut" title='excel' onClick={handleExcelDownload} style={{ display: showExcelButton ? 'block' : 'none' }}>
                                        <i class="fa-solid fa-file-excel"></i>
                                    </printbutton>
                                    <printbutton className="purbut" onClick={handleReload} title='reload'>
                                        <i class="fa-solid fa-arrow-rotate-right"></i>
                                    </printbutton>
                                    <button className="purbut" onClick={navigateToSalesSettings}>
                                        <i className="fa-solid fa-cog"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="mobileview">
                                <div class="d-flex justify-content-between ">
                                    <div className="d-flex justify-content-start">
                                        <h1 align="left" className="h1">Tax Invoice</h1>
                                    </div>
                                    <div class="dropdown mt-1 ms-4" style={{ paddingLeft: 0 }}>
                                        <button class="btn btn-primary dropdown-toggle p-1 ms-3" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="fa-solid fa-list"></i>
                                        </button>
                                        <ul class="dropdown-menu menu">

                                            {buttonsVisible && (
                                                <li class="iconbutton d-flex justify-content-center text-success">
                                                    {['add', 'all permission'].some(permission => purchasePermission.includes(permission)) && (
                                                        <icon class="icon" onClick={handleSaveButtonClick}>
                                                            <i class="fa-regular fa-floppy-disk"></i>
                                                        </icon>
                                                    )}
                                                </li>
                                            )}
                                            {showUpdateButton && (
                                                <li class="iconbutton d-flex justify-content-center text-success">
                                                    {['update', 'all permission'].some(permission => purchasePermission.includes(permission)) && (
                                                        <icon class="icon" onClick={handleUpdateButtonClick}>
                                                            <i class="fa-solid fa-floppy-disk"></i>
                                                        </icon>
                                                    )}
                                                </li>
                                            )}
                                            <li class="iconbutton  d-flex justify-content-center text-danger">
                                                {['delete', 'all permission'].some(permission => purchasePermission.includes(permission)) && (
                                                    <icon class="icon" onClick={handleDeleteButtonClick}>
                                                        <i class="fa-solid fa-trash"></i>
                                                    </icon>
                                                )}
                                            </li>
                                            <li class="iconbutton  d-flex justify-content-center text-warning">
                                                {['all permission', 'view'].some(permission => purchasePermission.includes(permission)) && (
                                                    <icon class="icon" onClick={generateReport}>
                                                        <i class="fa-solid fa-file-pdf"></i>
                                                    </icon>
                                                )}
                                            </li>
                                            <li class="iconbutton  d-flex justify-content-center text-success">
                                                <icon class="icon" onClick={handleExcelDownload}>
                                                    <i class="fa-solid fa-file-excel"></i>
                                                </icon>
                                            </li>
                                            <li class="iconbutton  d-flex justify-content-center">
                                                <icon class="icon" onClick={handleReload} title='reload'>
                                                    <i class="fa-solid fa-arrow-rotate-right"></i>
                                                </icon>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="shadow-lg p-1 bg-body-tertiary rounded  pt-3 pb-4" align="left">
                            <div className="row ms-4 me-3 mb-3">
                                <div className="col-md-3 form-group mb-2">
                                    <label htmlFor="party_code" className={`${deleteError && !new_running_no ? 'red' : ''}`}>Transaction No</label>
                                    {showAsterisk && <span className="text-danger">*</span>}
                                    <div className="exp-form-floating">
                                        <div className="d-flex justify-content-between align-items-center position-relative">
                                            <input
                                                id="RefNo"
                                                className="exp-input-field form-control"
                                                type="text"
                                                placeholder=""
                                                required
                                                value={new_running_no}
                                                onChange={handleChangeNo}
                                                maxLength={50}
                                                onKeyPress={handleKeyPressRef}
                                                autoComplete="off"
                                            />
                                            <span className="position-absolute mt-0 me-5 end-0 pe-3 searchIcon" onClick={handlePurchase}>
                                                <i className="fa fa-search" style={{ marginLeft: "15px" }}></i>
                                            </span>
                                            {selectedInvoice?.label === "Tax Invoice" && (
                                                <div className="form-check ms-2">
                                                    <input className="form-check-input" type="checkbox" id="checkboxId" checked={isChecked} onChange={handleCheckboxChange} />
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2">
                                    <div className="exp-form-floating">
                                        <label htmlFor="" className={`${error && !bill_date ? 'red' : ''}`}>Transaction Date</label>
                                        {!showAsterisk && <span className="text-danger">*</span>}
                                        <input
                                            name="transactionDate"
                                            id="transactionDate"
                                            className="exp-input-field form-control"
                                            type="date"
                                            placeholder=""
                                            required
                                            min={financialYearStart}
                                            max={financialYearEnd}
                                            value={bill_date}
                                            onChange={handleDateChange}
                                        />
                                    </div>
                                </div>

                                <div className="col-md-3 form-group mb-2">
                                    <div className="exp-form-floating">
                                        <label htmlFor="" className={`${error && !payType ? 'red' : ''}`}>Pay Type</label>
                                        {!showAsterisk && <span className="text-danger">*</span>}
                                        <Select
                                            id="payType"
                                            value={selectedPay}
                                            onChange={handleChangePay}
                                            options={filteredOptionPay}
                                            className="exp-input-field"
                                            placeholder=""
                                            required
                                            data-tip="Please select a payment type"
                                            autoComplete="off"
                                        />
                                    </div>
                                </div>

                                <div className="col-md-3 form-group mb-2">
                                    <div className="exp-form-floating">
                                        <label htmlFor="" className={`${error && !salesType ? 'red' : ''}`}>Sales Type {!showAsterisk && <span className="text-danger">*</span>}</label>
                                        <Select
                                            id="salesType"
                                            value={selectedSales}
                                            onChange={handleChangeSales}
                                            options={filteredOptionSales}
                                            className="exp-input-field"
                                            placeholder=""
                                            required
                                            data-tip="Please select a sales type"
                                            autoComplete="off"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className='row'>
                                <div className="col-md-6 mb-2">
                                    <div className="ag-theme-alpine" style={{ height: 285, width: "100%" }}>
                                        <AgGridReact
                                            columnDefs={columnDefsTermsConditions}
                                            rowData={rowDataTerms}
                                            defaultColDef={{ editable: true, resizable: true }}
                                            onGridReady={onGridReady}
                                            rowHeight={28}
                                            onRowClicked={handleRowClicked}
                                            onColumnMoved={onColumnMoved}
                                        />
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="ag-theme-alpine" style={{ height: 285, width: "100%" }}>
                                        {selectedInvoice?.label === "Proforma Invoice" ? (
                                            <AgGridReact
                                                columnDefs={columnPINotes}
                                                rowData={PINotesRowData}
                                                defaultColDef={{ editable: true, resizable: true }}
                                                rowHeight={28}
                                            />
                                        ) : (
                                            <AgGridReact
                                                columnDefs={columnNotes}
                                                rowData={notesRowData}
                                                defaultColDef={{ editable: true, resizable: true }}
                                                rowHeight={28}
                                            />
                                        )}
                                    </div>
                                </div>
                            </div>
                            <div className='purbut Desktop'>
                                <div class="d-flex justify-content-between ms-3" style={{ marginBlock: "", marginTop: "10px" }} >
                                    <div align="left" class="d-flex justify-content-start" style={{ marginLeft: "22px" }}>
                                        <purButton type="button" onClick={handleSwiftButtonClick} >
                                            Copy
                                        </purButton>
                                    </div>
                                </div>
                            </div>
                            <div className='mobile-only mobileview'>
                                <div class="d-flex justify-content-between " style={{ marginBlock: "", marginTop: "10px" }} >
                                    <div align="left" class="d-flex justify-content-start" style={{ marginLeft: "6px" }}>
                                        <purButton type="button" onClick={handleSwiftButtonClick} >
                                            Copy
                                        </purButton>
                                    </div>
                                </div>
                            </div>
                            <div className="ag-theme-alpine" style={{ height: 380, width: '100%' }}>
                                <AgGridReact
                                    columnDefs={columnHeader}
                                    rowData={headerRowData}
                                    defaultColDef={{ flex: 1 }}
                                    rowHeight={30}
                                />
                            </div>
                        </div>
                        <div className="shadow-lg p-1 bg-body-tertiary rounded mt-2 pt-3 pb-4" align="left">
                            <div className='row ms-4 me-3'>
                                <div className="col-md-3 form-group mb-2">
                                    <div class="exp-form-floating">
                                        <label>Total Amount</label>
                                        <input
                                            id="totalPurchaseAmount"
                                            class="exp-input-field form-control input"
                                            type="text"
                                            placeholder=""
                                            required
                                            value={totalamt}
                                            onChange={(e) => setTotalAmt(e.target.value)}
                                            readOnly
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2">
                                    <div class="exp-form-floating">
                                        <label>Total Tax</label>
                                        <input
                                            name="totalTaxAmount"
                                            id="totalTaxAmount"
                                            text="text"
                                            className="exp-input-field form-control input"
                                            placeholder=""
                                            required
                                            value={TotalTax}
                                            onChange={(e) => setTotalTax(e.target.value)}
                                            readOnly
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2">
                                    <div class="exp-form-floating">
                                        <label>Round Off</label>
                                        <input
                                            name=""
                                            id="roundOff"
                                            type="text"
                                            className="exp-input-field form-control input"
                                            placeholder=""
                                            required
                                            value={round_difference}
                                            onChange={(e) => {
                                                if (e.target.value === "0" || e.target.value === "") {
                                                    setRoundDifference(e.target.value);
                                                }
                                            }}
                                            autoComplete='off'
                                            onKeyPress={handleKeyPress}
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2">
                                    <div class="exp-form-floating">
                                        <label>Grand Total</label>
                                        <input
                                            name=""
                                            id="totalBillAmount"
                                            type="text"
                                            className="exp-input-field form-control"
                                            placeholder=""
                                            required
                                            value={TotalBill}
                                            onChange={(e) => setTotalBill(e.target.value)}
                                            readOnly
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2" style={{ justifyContent: "center" }}>
                                    <label htmlFor="party_code">Product/Items Filter</label>
                                    <div className="exp-form-floating">
                                        <div class="d-flex justify-content-between">
                                            <Select
                                                id="Product"
                                                value={selectedProduct}
                                                onChange={handleChangecode}
                                                options={filteredOptionProduct}
                                                className="exp-input-field"
                                                placeholder=""
                                                required

                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2" style={{ justifyContent: "center" }}>
                                    <label htmlFor="party_code">Product/Items Name</label>
                                    <div className="exp-form-floating">
                                        <div class="d-flex justify-content-between">
                                            <Select
                                                className="exp-input-field"
                                                id='itemCode'
                                                required
                                                placeholder=""
                                                maxLength={18}
                                                autoComplete='off'
                                                options={dynamicOptions}
                                                onChange={handleItemCode}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2" style={{ display: "none" }}>
                                    <div className="exp-form-floating">
                                        <label id="customer">Screen Type</label>
                                        <input
                                            className="exp-input-field form-control"
                                            id="customername"
                                            required
                                            value={Type}
                                            onChange={(e) => setType(e.target.value)}
                                        />
                                    </div>
                                </div>


                                {/* <div className="col-md-3 form-group mb-2" style={{ justifyContent: "center" }}>
    <label htmlFor="party_code">
        Advance Amount
    </label>
    <div className="exp-form-floating">
        <div className="d-flex justify-content-between">
            <input
                className="exp-input-field form-control"
                id="adAmount"
                required
                placeholder=""
                autoComplete="off"
                value={advanceAmount}
                onChange={(e) => {
                    const numericValue = e.target.value.replace(/[^0-9]/g, ''); // Remove non-numeric characters
                    setAdvanceAmount(numericValue); // Update state with numeric value
                }}
            />
        </div>
    </div>
</div>

                        <div className="col-md-3 form-group mb-2" style={{ justifyContent: "center" }}>
                            <label htmlFor="party_code">
                                Balance Amount
                            </label>
                            <div className="exp-form-floating">
                                <div class="d-flex justify-content-between">
                                    <input
                                        className="exp-input-field form-control"
                                        id="balAmount"
                                        required
                                        placeholder=""
                                        autoComplete="off"
                                        value={balanceAmount}
                                        readOnly
                                        onChange={(e) => setBalanceAmount(e.target.value)}  // Update state on input change
                                    />
                                </div>
                            </div>
                        </div> */}
                            </div>
                            <div className='purbut Desktop'>
                                <div class="d-flex justify-content-between me-5 ms-3 " style={{ marginBlock: "", marginTop: "10px" }} >
                                    <div align="left" class="d-flex justify-content-start" style={{ marginLeft: "21px", }}>
                                        <purButton
                                            type="button"
                                            className={`"toggle-btn"  ${activeTable === 'myTable' ? 'active' : ''}`}
                                            onClick={() => handleToggleTable('myTable')}>
                                            Product / Item Details
                                        </purButton>
                                        <purButton
                                            type="button"
                                            className={`"toggle-btn" ${activeTable === 'tax' ? 'active' : ''}`}
                                            onClick={() => handleToggleTable('tax')}>
                                            Tax Details
                                        </purButton>
                                    </div>
                                </div>
                            </div>
                            <div className='mobile-only mobileview'>
                                <div class="d-flex justify-content-between me-5 " style={{ marginBlock: "", marginTop: "10px" }} >
                                    <div align="left" class="d-flex justify-content-start" style={{ marginLeft: "3px", }}>
                                        <purButton
                                            type="button"
                                            className={`"toggle-btn"  ${activeTable === 'myTable' ? 'active' : ''}`}
                                            onClick={() => handleToggleTable('myTable')}>
                                            Product / Item Details
                                        </purButton>
                                        <purButton
                                            type="button"
                                            className={`"toggle-btn" ${activeTable === 'tax' ? 'active' : ''}`}
                                            onClick={() => handleToggleTable('tax')}>
                                            Tax Details
                                        </purButton>
                                    </div>
                                </div>
                            </div>
                            <div className="ag-theme-alpine" style={{ height: 437, width: "100%" }}>
                                <AgGridReact
                                    columnDefs={activeTable === 'myTable' ? columnDefs : columnDefsTax}
                                    rowData={activeTable === 'myTable' ? rowData : rowDataTax}
                                    defaultColDef={{ editable: true, resizable: true }}
                                    onCellValueChanged={async (event) => {
                                        if (event.colDef.field === 'qty' || event.colDef.field === 'unitPrice') {
                                            await TaxInvoiceItemAmountCalculation(event);
                                        }
                                        handleCellValueChanged(event);
                                    }}
                                    onGridReady={onGridReady}
                                    onRowClicked={handleRowClicked}
                                    onColumnMoved={onColumnMoved}
                                />
                            </div>
                        </div>
                    </div>
                    <div>
                        <TaxInvoicePopup open={open} handleClose={handleClose} handletaxinvoice={handletaxinvoice} invoicetype={isChecked ? "Proforma Invoice" : invoicetype} />
                        <TaxInvoiceCustomerPopup open={open1} handleClose={handleClose} handleVendor={handleCustomerBillTo} />
                        <TaxInvoiceCustomerPopup open={open2} handleClose={handleClose} handleVendor={handleCustomerShipTo} />
                    </div>
                    <div className="shadow-lg p-2 bg-body-tertiary rounded mt-2 mb-2">
                        <div className="row ms-2">
                            <div className="d-flex justify-content-start">
                                <p className="col-md-6">{labels.createdBy}: {additionalData.created_by}</p>
                                <p className="col-md-6">{labels.createdDate}: {additionalData.created_date}</p>
                            </div>
                            <div className="d-flex justify-content-start">
                                <p className="col-md-6">{labels.modifiedBy}: {additionalData.modified_by}</p>
                                <p className="col-md-6"> {labels.modifiedDate}: {additionalData.modified_date}</p>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="container-fluid Topnav-screen">
                    <div>
                        <ToastContainer position="top-right" className="toast-design" theme="colored" />
                        <div className="shadow-lg p-1 bg-body-tertiary rounded  mb-2 mt-2">
                            <div class="d-flex justify-content-between">
                                <div className="d-flex justify-content-start">
                                    <h1 align="left" className="purbut me-5">Deleted Invoice</h1>
                                </div>
                                <div className="d-flex justify-content-end purbut me-3">
                                    <div class="exp-form-floating">
                                        <Select
                                            id="returnType"
                                            className="exp-input-field col-md-6 mt-2"
                                            placeholder=""
                                            required
                                            value={selectedscreens}
                                            onChange={handleChangeScreens}
                                            options={filteredOptionScreens}
                                            data-tip="Please select a default warehouse"
                                        />
                                    </div>
                                    <div class="exp-form-floating mt-2 me-4">
                                        <Select
                                            id="InvoiceType"
                                            className="exp-input-field"
                                            placeholder="Select a Invoice Type  "
                                            options={filteredOptionInvoice}
                                            value={selectedInvoice}
                                            onChange={handleChangeInvoice}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div class="mobileview">
                                <div class="d-flex justify-content-between ">
                                    <div className="d-flex justify-content-start">
                                        <h1 align="left" className="h1">Deleted Invoice</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="shadow-lg p-1 bg-body-tertiary rounded  pt-3 pb-4" align="left">

                            <div className="row ms-4 me-3">
                                <div className="col-md-3">
                                    <div className="col-md-12 form-group mb-2">
                                        <label htmlFor="party_code">Transaction No</label>
                                        <div className="exp-form-floating">
                                            <div className="d-flex justify-content-end">
                                                <input
                                                    id="TransactionNo"
                                                    className="exp-input-field form-control justify-content-start"
                                                    type="text"
                                                    placeholder=""
                                                    required
                                                    value={TransactionNo}
                                                    onChange={(e) => setTransactionNo(e.target.value)}
                                                    maxLength={50}
                                                    onKeyPress={handleDeleteKeyPress}
                                                    autoComplete='off'
                                                />
                                                <div className='position-absolute mt-1 me-2'>
                                                    <span className="icon searchIcon" onClick={handleDeletedTaxInvoice}>
                                                        <i className="fa fa-search"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-12 form-group mb-2">
                                        <div className="exp-form-floating">
                                            <label htmlFor="">Transaction Date</label>
                                            <input
                                                name="transactionDate"
                                                id="TransactionDate"
                                                className="exp-input-field form-control"
                                                type="date"
                                                placeholder=""
                                                required
                                                value={TransactionDate}
                                                onChange={(e) => setTransactionDate(e.target.value)}
                                            />
                                        </div>
                                    </div>

                                    <div className="col-md-12 form-group mb-2">
                                        <div className="exp-form-floating">
                                            <label htmlFor="">Pay Type</label>                                    
                                            <input
                                                id="PayType"
                                                value={PayType}
                                                onChange={(e) => setPaytype(e.target.value)}
                                                className="exp-input-field form-control"
                                                placeholder=""
                                                required
                                                data-tip="Please select a payment type"
                                                autoComplete="off"
                                            />
                                        </div>
                                    </div>

                                    <div className="col-md-12 form-group mb-2">
                                        <div className="exp-form-floating">
                                            <label htmlFor="">Sales Type</label>
                                            <input
                                                id="SalesType"
                                                value={SalesType}
                                                onChange={(e) => setSalestype(e.target.value)}
                                                className="exp-input-field form-control"
                                                placeholder=""
                                                required
                                                data-tip="Please select a sales type"
                                                autoComplete="off"
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* Right side: Ag-Grid */}
                                <div className="col-md-5">
                                    <div className="ag-theme-alpine" style={{ height: 285, width: "100%" }}>
                                        <AgGridReact
                                            columnDefs={deletedColumnTerms}
                                            rowData={deletedRowDataTerms}
                                            defaultColDef={{ editable: true, resizable: true }}
                                            onGridReady={onGridReady}
                                            rowHeight={28}
                                            onRowClicked={handleRowClicked}
                                            onColumnMoved={onColumnMoved}
                                        />
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="ag-theme-alpine" style={{ height: 285, width: "100%" }}>
                                        {selectedInvoice?.label === "Proforma Invoice" ? (
                                            <AgGridReact
                                                columnDefs={columnDeletedPINotes}
                                                rowData={deletedPINotesRowData}
                                                defaultColDef={{ editable: true, resizable: true }}
                                                rowHeight={28}
                                            />
                                        ) : (
                                            <AgGridReact
                                                columnDefs={columnDeletedNotes}
                                                rowData={deletedNotesRowData}
                                                defaultColDef={{ editable: true, resizable: true }}
                                                rowHeight={28}
                                            />
                                        )}
                                    </div>
                                </div>
                            </div>
                            <div className='purbut Desktop'>
                                <div class="d-flex justify-content-between ms-3" style={{ marginBlock: "", marginTop: "10px" }} >
                                    <div align="left" class="d-flex justify-content-start" style={{ marginLeft: "22px" }}>
                                        <purButton type="button" onClick={handleSwiftButtonClick} >
                                            Copy
                                        </purButton>
                                    </div>
                                </div>
                            </div>
                            <div className='mobile-only mobileview'>
                                <div class="d-flex justify-content-between " style={{ marginBlock: "", marginTop: "10px" }} >
                                    <div align="left" class="d-flex justify-content-start" style={{ marginLeft: "6px" }}>
                                        <purButton type="button" onClick={handleSwiftButtonClick} >
                                            Copy
                                        </purButton>
                                    </div>
                                </div>
                            </div>
                            <div className="ag-theme-alpine" style={{ height: 380, width: '100%' }}>
                                <AgGridReact
                                    columnDefs={deletedColumnHeader}
                                    rowData={deletedHeaderRowData}
                                    defaultColDef={{ flex: 1 }}
                                />
                            </div>
                        </div>
                        <div className="shadow-lg p-1 bg-body-tertiary rounded mt-2 pt-3 pb-4" align="left">
                            <div className='row ms-4 me-3'>
                                <div className="col-md-3 form-group mb-2">
                                    <div class="exp-form-floating">
                                        <label>Total Amount</label>
                                        <input
                                            id="Total"
                                            class="exp-input-field form-control input"
                                            type="text"
                                            placeholder=""
                                            required
                                            value={Total}
                                            onChange={(e) => setTotal(e.target.value)}
                                            readOnly
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2">
                                    <div class="exp-form-floating">
                                        <label>Total Tax</label>
                                        <input
                                            name="totalTaxAmount"
                                            id="Tax"
                                            text="text"
                                            className="exp-input-field form-control input"
                                            placeholder=""
                                            required
                                            value={Tax}
                                            onChange={(e) => setTax(e.target.value)}
                                            readOnly
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2">
                                    <div class="exp-form-floating">
                                        <label>Round Off</label>
                                        <input
                                            name=""
                                            id="RoundOff"
                                            type="text"
                                            className="exp-input-field form-control input"
                                            placeholder=""
                                            required
                                            value={RoundOff}
                                            onChange={(e) => setRoundOff(e.target.value)}
                                            readOnly
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3 form-group mb-2">
                                    <div class="exp-form-floating">
                                        <label>Grand Total</label>
                                        <input
                                            name=""
                                            id="GrandTotal"
                                            type="text"
                                            className="exp-input-field form-control"
                                            placeholder=""
                                            required
                                            value={GrandTotal}
                                            onChange={(e) => setGrandTotal(e.target.value)}
                                            readOnly
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className='purbut Desktop'>
                                <div class="d-flex justify-content-between me-5 ms-3 " style={{ marginBlock: "", marginTop: "10px" }} >
                                    <div align="left" class="d-flex justify-content-start" style={{ marginLeft: "21px", }}>
                                        <purButton
                                            type="button"
                                            className={`"toggle-btn"  ${activeTable === 'myTable' ? 'active' : ''}`}
                                            onClick={() => handleToggleTable('myTable')}>
                                            Product / Item Details
                                        </purButton>
                                        <purButton
                                            type="button"
                                            className={`"toggle-btn" ${activeTable === 'tax' ? 'active' : ''}`}
                                            onClick={() => handleToggleTable('tax')}>
                                            Tax Details
                                        </purButton>
                                    </div>
                                </div>
                            </div>
                            <div className='mobile-only mobileview'>
                                <div class="d-flex justify-content-between me-5 " style={{ marginBlock: "", marginTop: "10px" }} >
                                    <div align="left" class="d-flex justify-content-start" style={{ marginLeft: "3px", }}>
                                        <purButton
                                            type="button"
                                            className={`"toggle-btn"  ${activeTable === 'myTable' ? 'active' : ''}`}
                                            onClick={() => handleToggleTable('myTable')}>
                                            Product / Item Details
                                        </purButton>
                                        <purButton
                                            type="button"
                                            className={`"toggle-btn" ${activeTable === 'tax' ? 'active' : ''}`}
                                            onClick={() => handleToggleTable('tax')}>
                                            Tax Details
                                        </purButton>
                                    </div>
                                </div>
                            </div>
                            <div className="ag-theme-alpine" style={{ height: 437, width: "100%" }}>
                                <AgGridReact
                                    columnDefs={activeTable === 'myTable' ? deletedColumnDetail : deletedColumnTax}
                                    rowData={activeTable === 'myTable' ? deletedRowData : deletedRowDataTax}
                                    defaultColDef={{ editable: true, resizable: true }}
                                    onGridReady={onGridReady}
                                    onRowClicked={handleRowClicked}
                                    onColumnMoved={onColumnMoved}
                                />
                            </div>
                        </div>
                    </div>
                    <div>
                        <DeletedTaxInvoicePopup open={open3} handleClose={handleClose} handleDeletedTaxInvoiceData={handleDeletedTaxInvoiceData} invoicetype={invoicetype} />
                    </div>
                    <div className="shadow-lg p-2 bg-body-tertiary rounded mt-2 mb-2">
                        <div className="row ms-2">
                            <div className="d-flex justify-content-start">
                                <p className="col-md-6">{labels.createdBy}: {additionalData.created_by}</p>
                                <p className="col-md-6">{labels.createdDate}: {additionalData.created_date}</p>
                            </div>
                            <div className="d-flex justify-content-start">
                                <p className="col-md-6">{labels.modifiedBy}: {additionalData.modified_by}</p>
                                <p className="col-md-6"> {labels.modifiedDate}: {additionalData.modified_date}</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default TaxInvoice; 